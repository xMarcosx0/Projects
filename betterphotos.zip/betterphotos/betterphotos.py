import tkinter as tk
from tkinter import filedialog, Toplevel, messagebox
from PIL import Image, ImageTk
import cv2
import numpy as np
import os

def enhance_image(image_path):
    """Aplica cuatro mejoras diferentes a la imagen y devuelve las versiones mejoradas."""
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Mejora 1: Aumento de contraste
    lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
    l = clahe.apply(l)
    enhanced_1 = cv2.merge((l, a, b))
    enhanced_1 = cv2.cvtColor(enhanced_1, cv2.COLOR_LAB2RGB)
    
    # Mejora 2: Corrección Gamma
    gamma = 1.5
    gamma_table = np.array([((i / 255.0) ** gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
    enhanced_2 = cv2.LUT(img, gamma_table)
    
    # Mejora 3: Enfoque con filtro Laplaciano
    laplacian = cv2.Laplacian(img, cv2.CV_64F)
    sharp = cv2.subtract(img, laplacian.astype(np.uint8))
    
    # Mejora 4: Filtro bilateral para suavizado
    enhanced_4 = cv2.bilateralFilter(img, 9, 75, 75)
    
    return [enhanced_1, enhanced_2, sharp, enhanced_4]

def detect_faces(image_path):
    """Detecta rostros en la imagen y mejora su nitidez."""
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5, minSize=(30, 30))
    
    for (x, y, w, h) in faces:
        face = img[y:y+h, x:x+w]
        sharpen_kernel = np.array([[0, -1, 0], [-1, 5,-1], [0, -1, 0]])
        img[y:y+h, x:x+w] = cv2.filter2D(face, -1, sharpen_kernel)
    
    return [cv2.cvtColor(img, cv2.COLOR_BGR2RGB)]

def open_image():
    global img_path, img_original, img_options, mode
    img_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
    if img_path:
        img_original = Image.open(img_path)
        img_original.thumbnail((400, 400))
        img_tk = ImageTk.PhotoImage(img_original)
        label_original.config(image=img_tk)
        label_original.image = img_tk
        
        if mode == "Fotos":
            img_options = enhance_image(img_path)
        else:
            img_options = detect_faces(img_path)
        
        display_results()

def display_results():
    for i, img in enumerate(img_options):
        img_pil = Image.fromarray(img)
        img_pil.thumbnail((400, 400))
        img_tk = ImageTk.PhotoImage(img_pil)
        label_results[i].config(image=img_tk)
        label_results[i].image = img_tk
        label_results[i].bind("<Button-1>", lambda event, idx=i: open_preview_window(idx))

def save_image(custom_name=None, img_to_save=None):
    if img_path and img_to_save is not None:
        base_name = custom_name if custom_name else os.path.splitext(os.path.basename(img_path))[0]
        save_dir = os.path.dirname(img_path)
        save_path = os.path.join(save_dir, f"{base_name}_Better.png")
        cv2.imwrite(save_path, cv2.cvtColor(img_to_save, cv2.COLOR_RGB2BGR))

def open_preview_window(index):
    preview_window = Toplevel(root)
    preview_window.title("Vista Previa")
    
    img_pil = Image.fromarray(img_options[index])
    img_pil.thumbnail((500, 500))
    img_tk = ImageTk.PhotoImage(img_pil)
    
    label_preview = tk.Label(preview_window, image=img_tk)
    label_preview.image = img_tk
    label_preview.pack()
    
    def save_from_preview():
        save_image(None, img_options[index])
    
    btn_save = tk.Button(preview_window, text="Guardar", command=save_from_preview)
    btn_save.pack()

def choose_mode():
    global mode
    mode_window = Toplevel(root)
    mode_window.title("Seleccionar Modo")
    
    def set_mode(selected_mode):
        global mode
        mode = selected_mode
        mode_window.destroy()
    
    tk.Label(mode_window, text="Elige el modo de mejora:").pack()
    tk.Button(mode_window, text="Mejorar Fotos", command=lambda: set_mode("Fotos")).pack()
    tk.Button(mode_window, text="Mejorar Rostros", command=lambda: set_mode("Rostros")).pack()

def create_gui():
    global root, label_original, label_results, mode
    
    root = tk.Tk()
    root.title("Mejorador de Fotos y Rostros")
    
    choose_mode()
    
    frame_top = tk.Frame(root)
    frame_top.pack()
    btn_select = tk.Button(frame_top, text="Seleccionar Imagen", command=open_image)
    btn_select.pack()
    
    frame_images = tk.Frame(root)
    frame_images.pack()
    label_original = tk.Label(frame_images)
    label_original.pack(side=tk.LEFT, padx=10)
    
    frame_results = tk.Frame(root)
    frame_results.pack()
    label_results = [tk.Label(frame_results) for _ in range(4)]
    for label in label_results:
        label.pack(side=tk.LEFT, padx=10)
    
    root.mainloop()

create_gui()
