import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox
from PIL import Image, ImageTk, ImageOps
import cv2
import numpy as np
import os
from skimage import exposure
from skimage.filters import unsharp_mask

class AdvancedPhotoEnhancer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Mejorador de Fotos Avanzado")
        self.root.geometry("1200x800")
        self.root.minsize(800, 600)
        
        # Variables de estado
        self.img_path = None
        self.img_original = None
        self.img_options = []
        
        # Configuración de estilos
        self.setup_styles()
        self.create_widgets()
        self.setup_responsive_grid()
        
        # Manejar redimensionamiento
        self.root.bind("<Configure>", self.on_window_resize)
    
    def setup_styles(self):
        """Configura los estilos visuales de la aplicación"""
        self.bg_color = "#f5f5f5"
        self.button_style = {
            'bg': '#5D6D7E', 
            'fg': 'white', 
            'padx': 12, 
            'pady': 6,
            'font': ('Segoe UI', 10),
            'relief': tk.GROOVE,
            'borderwidth': 2
        }
        self.frame_style = {'padx': 10, 'pady': 10, 'bg': self.bg_color}
        self.label_frame_style = {
            'font': ('Segoe UI', 10, 'bold'),
            'bd': 2,
            'relief': tk.GROOVE,
            'bg': self.bg_color
        }
        self.root.configure(bg=self.bg_color)
    
    def create_widgets(self):
        """Crea y organiza los widgets en la interfaz"""
        # Frame superior para controles
        self.control_frame = tk.Frame(self.root, **self.frame_style)
        self.control_frame.pack(fill=tk.X)
        
        tk.Button(self.control_frame, text="📁 Seleccionar Imagen", 
                 command=self.open_image, **self.button_style).pack(side=tk.LEFT, padx=5)
        tk.Button(self.control_frame, text="🔄 Procesar", 
                 command=self.process_image, **self.button_style).pack(side=tk.LEFT, padx=5)
        
        # Frame principal para imágenes
        self.main_frame = tk.Frame(self.root, **self.frame_style)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Frame para imagen original
        self.original_frame = tk.LabelFrame(self.main_frame, **self.label_frame_style)
        self.original_frame.configure(text="Imagen Original")
        self.original_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        self.label_original = tk.Label(self.original_frame, bg='white', bd=2, relief=tk.SUNKEN)
        self.label_original.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # Frame para resultados
        self.results_frame = tk.LabelFrame(self.main_frame, **self.label_frame_style)
        self.results_frame.configure(text="Opciones Mejoradas")
        self.results_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        
        # Crear frames para las imágenes mejoradas
        self.setup_result_frames()
    
    def setup_responsive_grid(self):
        """Configura el grid para ser responsive"""
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)
        
        self.original_frame.grid_rowconfigure(0, weight=1)
        self.original_frame.grid_columnconfigure(0, weight=1)
        
        self.results_frame.grid_rowconfigure(0, weight=1)
        for i in range(4):
            self.results_frame.grid_columnconfigure(i, weight=1)
    
    def setup_result_frames(self):
        """Configura los frames para las imágenes mejoradas"""
        self.result_frames = []
        self.label_results = []
        
        for i in range(4):
            frame = tk.Frame(self.results_frame, bg=self.bg_color)
            frame.grid(row=0, column=i, padx=5, pady=5, sticky="nsew")
            self.result_frames.append(frame)
            
            # Configurar grid interno
            frame.grid_rowconfigure(0, weight=1)
            frame.grid_columnconfigure(0, weight=1)
            
            # Label para la imagen
            img_label = tk.Label(frame, bg='white', bd=2, relief=tk.SUNKEN)
            img_label.grid(row=0, column=0, sticky="nsew")
            img_label.bind("<Button-1>", lambda e, idx=i: self.open_preview_window(idx))
            self.label_results.append(img_label)
            
            # Frame para controles
            ctrl_frame = tk.Frame(frame, bg=self.bg_color)
            ctrl_frame.grid(row=1, column=0, sticky="ew")
            
            # Descripción
            desc_label = tk.Label(
                ctrl_frame, 
                text=self.get_enhancement_description(i),
                bg=self.bg_color,
                font=('Segoe UI', 8)
            )
            desc_label.pack(side=tk.LEFT)
            
            # Botón de guardado
            save_btn = tk.Button(
                ctrl_frame, 
                text="💾 Guardar", 
                command=lambda idx=i: self.save_image(idx),
                bg='#27AE60', 
                fg='white',
                font=('Segoe UI', 8),
                padx=5
            )
            save_btn.pack(side=tk.RIGHT)
    
    def on_window_resize(self, event):
        """Maneja el redimensionamiento de la ventana"""
        if hasattr(self, 'img_original') and self.img_original:
            self.display_original_image()
            self.display_processed_images()
    
    def get_enhancement_description(self, index):
        """Devuelve la descripción de cada técnica de mejora"""
        descriptions = [
            "Contraste mejorado (CLAHE avanzado)",
            "Corrección Gamma adaptativa",
            "Enfoque inteligente",
            "Mejora de color y detalle"
        ]
        return descriptions[index]
    
    def open_image(self):
        """Abre y carga la imagen seleccionada"""
        filetypes = [
            ("Imágenes", "*.png;*.jpg;*.jpeg;*.bmp;*.tiff"), 
            ("Todos los archivos", "*.*")
        ]
        img_path = filedialog.askopenfilename(filetypes=filetypes)
        
        if img_path:
            try:
                self.img_path = img_path
                self.img_original = Image.open(img_path)
                self.display_original_image()
                self.process_image()
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo cargar la imagen:\n{str(e)}")
    
    def display_original_image(self):
        """Muestra la imagen original con bordes y tamaño responsive"""
        if self.img_original:
            try:
                img = self.img_original.copy()
                
                # Calcular tamaño basado en el espacio disponible
                frame_width = self.original_frame.winfo_width() - 20
                frame_height = self.original_frame.winfo_height() - 20
                
                if frame_width > 1 and frame_height > 1:
                    img.thumbnail((frame_width, frame_height), Image.LANCZOS)
                
                # Añadir bordes decorativos
                img = ImageOps.expand(img, border=2, fill='white')
                img = ImageOps.expand(img, border=1, fill='#34495E')
                
                # Convertir para Tkinter
                img_tk = ImageTk.PhotoImage(img)
                
                # Actualizar label
                self.label_original.config(image=img_tk)
                self.label_original.image = img_tk
                
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo mostrar la imagen:\n{str(e)}")
    
    def process_image(self):
        """Procesa la imagen con los algoritmos mejorados"""
        if not self.img_path:
            messagebox.showwarning("Advertencia", "Primero seleccione una imagen")
            return
        
        try:
            # Procesar con los nuevos algoritmos mejorados
            self.img_options = self.enhance_image_advanced(self.img_path)
            self.display_processed_images()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al procesar la imagen:\n{str(e)}")
    
    def display_processed_images(self):
        """Muestra las imágenes procesadas con tamaño responsive"""
        if not self.img_options:
            return
            
        for i, img in enumerate(self.img_options):
            try:
                img_pil = Image.fromarray(img)
                
                # Calcular tamaño basado en el espacio disponible
                frame_width = self.result_frames[i].winfo_width() - 20
                frame_height = self.result_frames[i].winfo_height() - 40
                
                if frame_width > 1 and frame_height > 1:
                    img_pil.thumbnail((frame_width, frame_height), Image.LANCZOS)
                
                # Añadir bordes decorativos
                img_pil = ImageOps.expand(img_pil, border=2, fill='white')
                img_pil = ImageOps.expand(img_pil, border=1, fill='#34495E')
                
                # Convertir para Tkinter
                img_tk = ImageTk.PhotoImage(img_pil)
                
                # Actualizar label
                self.label_results[i].config(image=img_tk)
                self.label_results[i].image = img_tk
                
            except Exception as e:
                print(f"Error mostrando imagen {i}: {str(e)}")
    
    def enhance_image_advanced(self, image_path):
        """Implementación mejorada de los algoritmos de mejora"""
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError("No se pudo cargar la imagen")
        
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        enhanced_images = []
        
        # 1. CLAHE mejorado con pre y post procesamiento
        enhanced_images.append(self.apply_advanced_clahe(img))
        
        # 2. Corrección Gamma adaptativa
        enhanced_images.append(self.apply_adaptive_gamma(img))
        
        # 3. Enfoque inteligente
        enhanced_images.append(self.apply_smart_sharpening(img))
        
        # 4. Mejora de color y detalle
        enhanced_images.append(self.apply_color_detail_enhancement(img))
        
        return enhanced_images
    
    def apply_advanced_clahe(self, img):
        """CLAHE mejorado con pre y post procesamiento"""
        # Convertir a LAB
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Suavizado previo para reducir ruido
        l_smooth = cv2.bilateralFilter(l, 9, 75, 75)
        
        # CLAHE con parámetros optimizados
        clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(12, 12))
        l_clahe = clahe.apply(l_smooth)
        
        # Mezcla controlada para mantener detalles
        alpha = 0.7
        l_enhanced = cv2.addWeighted(l_clahe, alpha, l, 1-alpha, 0)
        
        # Mejorar contraste local
        l_enhanced = exposure.equalize_adapthist(l_enhanced.astype(np.float32)/255.0)
        l_enhanced = (l_enhanced * 255).astype(np.uint8)
        
        # Recombinar canales
        enhanced = cv2.merge((l_enhanced, a, b))
        enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB)
        
        return enhanced
    
    def apply_adaptive_gamma(self, img):
        """Corrección gamma adaptativa basada en histograma"""
        # Calcular gamma basado en el brillo medio
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        mean_brightness = np.mean(gray)
        
        # Ajuste adaptativo
        if mean_brightness < 60:  # Imagen oscura
            gamma = 0.6
        elif mean_brightness > 200:  # Imagen muy clara
            gamma = 1.8
        else:  # Rango medio
            gamma = 1.2
        
        # Aplicar corrección gamma
        inv_gamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
        enhanced = cv2.LUT(img, table)
        
        # Mejorar saturación
        hsv = cv2.cvtColor(enhanced, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], 1.2)
        enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        
        return enhanced
    
    def apply_smart_sharpening(self, img):
        """Enfoque inteligente con múltiples técnicas"""
        # Suavizado inicial para reducir ruido
        smooth = cv2.bilateralFilter(img, 9, 75, 75)
        
        # Enfoque con máscara de enfoque (unsharp masking)
        sharpened = unsharp_mask(smooth.astype(np.float32)/255.0, radius=2, amount=1.5)
        sharpened = (sharpened * 255).astype(np.uint8)
        
        # Enfoque local adaptativo
        gray = cv2.cvtColor(sharpened, cv2.COLOR_RGB2GRAY)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        laplacian = cv2.normalize(laplacian, None, 0, 1, cv2.NORM_MINMAX)
        
        # Mezcla controlada
        alpha = 0.5
        enhanced = cv2.addWeighted(sharpened, 1 + alpha, img, -alpha, 0)
        
        return enhanced
    
    def apply_color_detail_enhancement(self, img):
        """Mejora combinada de color y detalle"""
        # Mejora de color en LAB
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Ecualización adaptativa del canal L
        l_enhanced = exposure.equalize_adapthist(l.astype(np.float32)/255.0, clip_limit=0.03)
        l_enhanced = (l_enhanced * 255).astype(np.uint8)
        
        # Mejora de saturación en HSV
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], 1.3)
        
        # Mezcla de resultados
        color_enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        lab_color = cv2.cvtColor(color_enhanced, cv2.COLOR_RGB2LAB)
        _, a_color, b_color = cv2.split(lab_color)
        
        # Recombinar
        enhanced_lab = cv2.merge((l_enhanced, a_color, b_color))
        enhanced = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2RGB)
        
        # Enfoque selectivo
        enhanced = unsharp_mask(enhanced.astype(np.float32)/255.0, radius=1, amount=0.8)
        enhanced = (enhanced * 255).astype(np.uint8)
        
        return enhanced
    
    def open_preview_window(self, index):
        """Abre una ventana de vista previa ampliada"""
        if not self.img_options or index >= len(self.img_options):
            return
        
        preview_window = tk.Toplevel(self.root)
        preview_window.title(f"Vista Previa - Opción {index+1}")
        preview_window.geometry("800x700")
        
        # Frame para imagen
        img_frame = tk.Frame(preview_window)
        img_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Mostrar imagen en tamaño completo
        img_pil = Image.fromarray(self.img_options[index])
        img_tk = ImageTk.PhotoImage(img_pil)
        
        canvas = tk.Canvas(img_frame, bg='white', bd=2, relief=tk.SUNKEN)
        canvas.pack(fill=tk.BOTH, expand=True)
        canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
        canvas.image = img_tk
        
        # Frame para controles
        ctrl_frame = tk.Frame(preview_window, bg=self.bg_color)
        ctrl_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # Botones
        tk.Button(ctrl_frame, text="💾 Guardar Imagen", 
                 command=lambda: self.save_image(index), **self.button_style).pack(side=tk.LEFT, padx=5)
        
        tk.Button(ctrl_frame, text="✕ Cerrar", 
                 command=preview_window.destroy,
                 bg='#E74C3C', fg='white',
                 font=('Segoe UI', 10), padx=12).pack(side=tk.RIGHT, padx=5)
        
        # Descripción
        desc_label = tk.Label(
            ctrl_frame, 
            text=self.get_enhancement_description(index),
            bg=self.bg_color,
            font=('Segoe UI', 10)
        )
        desc_label.pack(side=tk.LEFT, padx=10)
    
    def save_image(self, index):
        """Guarda la imagen mejorada seleccionada"""
        if not self.img_path or index >= len(self.img_options):
            return
        
        default_name = os.path.splitext(os.path.basename(self.img_path))[0]
        enhancement_type = self.get_enhancement_description(index).split("(")[0].strip().lower()
        
        save_path = filedialog.asksaveasfilename(
            initialfile=f"{default_name}_{enhancement_type}",
            defaultextension=".png",
            filetypes=[
                ("PNG", "*.png"),
                ("JPEG", "*.jpg"),
                ("TIFF", "*.tiff"),
                ("Todos los archivos", "*.*")
            ],
            title="Guardar imagen como"
        )
        
        if save_path:
            try:
                # Convertir de RGB a BGR para OpenCV
                img_to_save = cv2.cvtColor(self.img_options[index], cv2.COLOR_RGB2BGR)
                cv2.imwrite(save_path, img_to_save)
                messagebox.showinfo("Éxito", f"Imagen guardada exitosamente en:\n{save_path}")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo guardar la imagen:\n{str(e)}")
    
    def run(self):
        """Inicia la aplicación"""
        self.root.mainloop()

if __name__ == "__main__":
    app = AdvancedPhotoEnhancer()
    app.run()