import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk, ImageOps, ImageFilter, ImageEnhance
import cv2
import numpy as np
import os
import random
from skimage import exposure, filters, restoration

class PhotoEnhancerPro:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Mejorador de Fotos Pro - 15+ Filtros")
        self.root.geometry("1400x900")
        self.root.minsize(1000, 700)
        
        # Variables de estado
        self.img_path = None
        self.img_original = None
        self.img_options = []
        self.available_filters = self.setup_filters()
        self.current_filters = random.sample(list(self.available_filters.keys()), 4)
        self.filter_params = {}
        
        # Configuración de estilos
        self.setup_styles()
        self.create_widgets()
        
        # Configurar grid responsive
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)
        
        self.original_frame.grid_rowconfigure(0, weight=1)
        self.original_frame.grid_columnconfigure(0, weight=1)
        
        self.results_frame.grid_rowconfigure(0, weight=1)
        for i in range(4):
            self.results_frame.grid_columnconfigure(i, weight=1)
        
        # Manejar redimensionamiento
        self.root.bind("<Configure>", self.on_window_resize)
    
    def setup_filters(self):
        """Define los 15+ filtros disponibles con sus parámetros"""
        return {
            "clahe_avanzado": {
                "name": "CLAHE Avanzado",
                "function": self.apply_clahe_advanced,
                "params": {"clip_limit": (1.0, 4.0), "tile_size": (4, 16), "blend": (0.3, 0.8)}
            },
            "gamma_adaptativo": {
                "name": "Gamma Adaptativo", 
                "function": self.apply_adaptive_gamma,
                "params": {"gamma": (0.5, 2.0), "saturation": (0.8, 1.5)}
            },
            "enfoque_inteligente": {
                "name": "Enfoque Inteligente",
                "function": self.apply_smart_sharpening,
                "params": {"radius": (1, 3), "amount": (0.5, 2.0), "alpha": (0.3, 0.8)}
            },
            "mejora_color": {
                "name": "Mejora de Color",
                "function": self.apply_color_enhancement,
                "params": {"saturation": (1.0, 1.8), "vibrance": (1.0, 1.5)}
            },
            "estilo_artistico": {
                "name": "Estilo Artístico",
                "function": self.apply_artistic_style,
                "params": {"intensity": (0.5, 1.5)}
            },
            "blanco_y_negro": {
                "name": "Blanco y Negro Premium",
                "function": self.apply_premium_bw,
                "params": {"contrast": (0.8, 1.5)}
            },
            "efecto_pelicula": {
                "name": "Efecto Película",
                "function": self.apply_film_effect,
                "params": {"grain": (0.1, 0.5), "fade": (0.0, 0.3)}
            },
            "mejora_retrato": {
                "name": "Mejora de Retrato",
                "function": self.apply_portrait_enhancement,
                "params": {"skin_softness": (0.5, 1.5), "eye_enhance": (1.0, 2.0)}
            },
            "hdr_effect": {
                "name": "Efecto HDR",
                "function": self.apply_hdr_effect,
                "params": {"intensity": (0.5, 1.5)}
            },
            "tono_sepia": {
                "name": "Tono Sepia Avanzado",
                "function": self.apply_advanced_sepia,
                "params": {"intensity": (0.5, 1.5)}
            },
            "reduccion_ruido": {
                "name": "Reducción de Ruido",
                "function": self.apply_noise_reduction,
                "params": {"strength": (0.5, 1.5)}
            },
            "mejora_paisaje": {
                "name": "Mejora de Paisaje",
                "function": self.apply_landscape_enhancement,
                "params": {"sky_enhance": (1.0, 2.0), "greenery_boost": (1.0, 1.8)}
            },
            "efecto_lomo": {
                "name": "Efecto Lomo",
                "function": self.apply_lomo_effect,
                "params": {"vignette": (0.3, 0.8), "saturation": (1.0, 1.8)}
            },
            "mejora_nocturna": {
                "name": "Mejora Nocturna",
                "function": self.apply_night_enhancement,
                "params": {"brightness": (1.0, 2.0), "contrast": (1.0, 1.8)}
            },
            "estilo_sketch": {
                "name": "Estilo Sketch",
                "function": self.apply_sketch_effect,
                "params": {"intensity": (0.5, 1.5)}
            },
            "mejora_alimentos": {
                "name": "Mejora de Alimentos",
                "function": self.apply_food_enhancement,
                "params": {"warmth": (0.8, 1.5), "saturation": (1.2, 2.0)}
            },
            "efecto_vintage": {
                "name": "Efecto Vintage",
                "function": self.apply_vintage_effect,
                "params": {"intensity": (0.5, 1.5)}
            }
        }
    
    def setup_styles(self):
        """Configura los estilos visuales de la aplicación"""
        self.bg_color = "#f5f5f5"
        self.button_style = {
            'bg': '#5D6D7E', 
            'fg': 'white', 
            'padx': 12, 
            'pady': 6,
            'font': ('Segoe UI', 10),
            'relief': tk.GROOVE,
            'borderwidth': 2
        }
        self.small_button_style = {
            'bg': '#5D6D7E', 
            'fg': 'white', 
            'padx': 8, 
            'pady': 3,
            'font': ('Segoe UI', 8),
            'relief': tk.GROOVE,
            'borderwidth': 1
        }
        self.frame_style = {'padx': 10, 'pady': 10, 'bg': self.bg_color}
        self.label_frame_style = {
            'font': ('Segoe UI', 10, 'bold'),
            'bd': 2,
            'relief': tk.GROOVE,
            'bg': self.bg_color
        }
        self.root.configure(bg=self.bg_color)
    
    def create_widgets(self):
        """Crea y organiza los widgets en la interfaz"""
        # Frame superior para controles
        self.control_frame = tk.Frame(self.root, **self.frame_style)
        self.control_frame.pack(fill=tk.X)
        
        # Botón para seleccionar imagen
        tk.Button(self.control_frame, text="📁 Seleccionar Imagen", 
                 command=self.open_image, **self.button_style).pack(side=tk.LEFT, padx=5)
        
        # Botón para rehacer con nuevos filtros aleatorios
        self.redo_button = tk.Button(self.control_frame, text="🎲 Rehacer con Filtros Aleatorios", 
                                   command=self.apply_random_filters, **self.button_style)
        self.redo_button.pack(side=tk.LEFT, padx=5)
        self.redo_button.config(state=tk.DISABLED)
        
        # Frame principal para imágenes
        self.main_frame = tk.Frame(self.root, **self.frame_style)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Frame para imagen original
        self.original_frame = tk.LabelFrame(self.main_frame, **self.label_frame_style)
        self.original_frame.configure(text="Imagen Original")
        self.original_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        self.label_original = tk.Label(self.original_frame, bg='white', bd=2, relief=tk.SUNKEN)
        self.label_original.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # Frame para resultados
        self.results_frame = tk.LabelFrame(self.main_frame, **self.label_frame_style)
        self.results_frame.configure(text="Opciones Mejoradas")
        self.results_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        
        # Crear frames para las imágenes mejoradas
        self.setup_result_frames()
    
    def setup_result_frames(self):
        """Configura los frames para las imágenes mejoradas"""
        self.result_frames = []
        self.label_results = []
        
        for i in range(4):
            frame = tk.Frame(self.results_frame, bg=self.bg_color)
            frame.grid(row=0, column=i, padx=5, pady=5, sticky="nsew")
            self.result_frames.append(frame)
            
            # Configurar grid interno
            frame.grid_rowconfigure(0, weight=1)
            frame.grid_columnconfigure(0, weight=1)
            
            # Label para la imagen
            img_label = tk.Label(frame, bg='white', bd=2, relief=tk.SUNKEN)
            img_label.grid(row=0, column=0, sticky="nsew")
            img_label.bind("<Button-1>", lambda e, idx=i: self.open_preview_window(idx))
            self.label_results.append(img_label)
            
            # Frame para controles
            ctrl_frame = tk.Frame(frame, bg=self.bg_color)
            ctrl_frame.grid(row=1, column=0, sticky="ew")
            
            # Descripción
            desc_label = tk.Label(
                ctrl_frame, 
                text="Filtro no aplicado",
                bg=self.bg_color,
                font=('Segoe UI', 8)
            )
            desc_label.pack(side=tk.LEFT, padx=2)
            
            # Botón de guardado
            save_btn = tk.Button(
                ctrl_frame, 
                text="💾", 
                command=lambda idx=i: self.save_image(idx),
                **self.small_button_style
            )
            save_btn.pack(side=tk.RIGHT, padx=2)
    
    def apply_random_filters(self):
        """Aplica 4 filtros aleatorios diferentes"""
        if not self.img_path:
            return
        
        # Seleccionar 4 filtros aleatorios diferentes
        self.current_filters = random.sample(list(self.available_filters.keys()), 4)
        
        # Generar parámetros aleatorios para cada filtro
        self.filter_params = {}
        for filter_id in self.current_filters:
            self.filter_params[filter_id] = self.generate_random_params(filter_id)
        
        self.process_image()
    
    def generate_random_params(self, filter_id):
        """Genera parámetros aleatorios para un filtro específico"""
        params = {}
        filter_info = self.available_filters[filter_id]
        
        for param_name, (min_val, max_val) in filter_info["params"].items():
            # Generar valor aleatorio entre min y max
            if isinstance(min_val, int) and isinstance(max_val, int):
                params[param_name] = random.randint(min_val, max_val)
            else:
                params[param_name] = random.uniform(min_val, max_val)
        
        return params
    
    def on_window_resize(self, event):
        """Maneja el redimensionamiento de la ventana"""
        if hasattr(self, 'img_original') and self.img_original:
            self.display_original_image()
            self.display_processed_images()
    
    def open_image(self):
        """Abre y carga la imagen seleccionada"""
        filetypes = [
            ("Imágenes", "*.png;*.jpg;*.jpeg;*.bmp;*.tiff"), 
            ("Todos los archivos", "*.*")
        ]
        img_path = filedialog.askopenfilename(filetypes=filetypes)
        
        if img_path:
            try:
                self.img_path = img_path
                self.img_original = Image.open(img_path)
                self.display_original_image()
                self.apply_random_filters()  # Aplicar filtros aleatorios al cargar
                self.redo_button.config(state=tk.NORMAL)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo cargar la imagen:\n{str(e)}")
    
    def display_original_image(self):
        """Muestra la imagen original con bordes y tamaño responsive"""
        if self.img_original:
            try:
                img = self.img_original.copy()
                
                # Calcular tamaño basado en el espacio disponible
                frame_width = self.original_frame.winfo_width() - 20
                frame_height = self.original_frame.winfo_height() - 20
                
                if frame_width > 1 and frame_height > 1:
                    img.thumbnail((frame_width, frame_height), Image.LANCZOS)
                
                # Añadir bordes decorativos
                img = ImageOps.expand(img, border=2, fill='white')
                img = ImageOps.expand(img, border=1, fill='#34495E')
                
                # Convertir para Tkinter
                img_tk = ImageTk.PhotoImage(img)
                
                # Actualizar label
                self.label_original.config(image=img_tk)
                self.label_original.image = img_tk
                
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo mostrar la imagen:\n{str(e)}")
    
    def process_image(self):
        """Procesa la imagen con los filtros actuales"""
        if not self.img_path:
            messagebox.showwarning("Advertencia", "Primero seleccione una imagen")
            return
        
        try:
            # Cargar imagen original con OpenCV para procesamiento
            img_cv = cv2.imread(self.img_path)
            img_cv = cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB)
            
            # Aplicar cada filtro
            self.img_options = []
            for filter_id in self.current_filters:
                filter_func = self.available_filters[filter_id]["function"]
                params = self.filter_params[filter_id]
                filtered_img = filter_func(img_cv.copy(), **params)
                self.img_options.append(filtered_img)
            
            self.display_processed_images()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al procesar la imagen:\n{str(e)}")
    
    def display_processed_images(self):
        """Muestra las imágenes procesadas con tamaño responsive"""
        if not self.img_options:
            return
            
        for i, (img, filter_id) in enumerate(zip(self.img_options, self.current_filters)):
            try:
                img_pil = Image.fromarray(img)
                
                # Calcular tamaño basado en el espacio disponible
                frame_width = self.result_frames[i].winfo_width() - 20
                frame_height = self.result_frames[i].winfo_height() - 40
                
                if frame_width > 1 and frame_height > 1:
                    img_pil.thumbnail((frame_width, frame_height), Image.LANCZOS)
                
                # Añadir bordes decorativos
                img_pil = ImageOps.expand(img_pil, border=2, fill='white')
                img_pil = ImageOps.expand(img_pil, border=1, fill='#34495E')
                
                # Convertir para Tkinter
                img_tk = ImageTk.PhotoImage(img_pil)
                
                # Actualizar label
                self.label_results[i].config(image=img_tk)
                self.label_results[i].image = img_tk
                
                # Actualizar descripción
                filter_name = self.available_filters[filter_id]["name"]
                for widget in self.result_frames[i].winfo_children():
                    if isinstance(widget, tk.Frame):
                        for child in widget.winfo_children():
                            if isinstance(child, tk.Label) and child['text'] != "💾":
                                child.config(text=filter_name)
                
            except Exception as e:
                print(f"Error mostrando imagen {i}: {str(e)}")
    
    # --------------------------------------------------
    # IMPLEMENTACIÓN DE LOS 15+ FILTROS
    # --------------------------------------------------
    
    def apply_clahe_advanced(self, img, clip_limit=2.0, tile_size=8, blend=0.6):
        """CLAHE avanzado con control de mezcla"""
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Suavizado previo
        l_smooth = cv2.bilateralFilter(l, 9, 75, 75)
        
        # CLAHE
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(tile_size, tile_size))
        l_clahe = clahe.apply(l_smooth)
        
        # Mezcla controlada
        l_enhanced = cv2.addWeighted(l_clahe, blend, l, 1-blend, 0)
        
        # Mejorar contraste local
        l_enhanced = exposure.equalize_adapthist(l_enhanced.astype(np.float32)/255.0)
        l_enhanced = (l_enhanced * 255).astype(np.uint8)
        
        # Recombinar canales
        enhanced = cv2.merge((l_enhanced, a, b))
        return cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB)
    
    def apply_adaptive_gamma(self, img, gamma=1.2, saturation=1.2):
        """Corrección gamma adaptativa"""
        inv_gamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
        enhanced = cv2.LUT(img, table)
        
        # Ajustar saturación
        hsv = cv2.cvtColor(enhanced, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], saturation)
        return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    
    def apply_smart_sharpening(self, img, radius=1.5, amount=1.2, alpha=0.5):
        """Enfoque inteligente con múltiples técnicas"""
        # Suavizado inicial
        smooth = cv2.bilateralFilter(img, 9, 75, 75)
        
        # Enfoque con máscara de enfoque
        sharpened = unsharp_mask(smooth.astype(np.float32)/255.0, radius=radius, amount=amount)
        sharpened = (sharpened * 255).astype(np.uint8)
        
        # Mezcla controlada
        return cv2.addWeighted(sharpened, 1 + alpha, img, -alpha, 0)
    
    def apply_color_enhancement(self, img, saturation=1.3, vibrance=1.2):
        """Mejora de color y vibrance"""
        # Convertir a HSV para ajustar saturación
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], saturation)
        enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        
        # Ajustar vibrance (protegiendo tonos piel)
        lab = cv2.cvtColor(enhanced, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        a = cv2.multiply(a, vibrance)
        b = cv2.multiply(b, vibrance)
        enhanced_lab = cv2.merge((l, a, b))
        return cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2RGB)
    
    def apply_artistic_style(self, img, intensity=1.0):
        """Estilo artístico con efecto pintura"""
        # Reducir detalles para efecto pintura
        smoothed = cv2.stylization(img, sigma_s=60*intensity, sigma_r=0.45)
        
        # Aumentar contraste
        lab = cv2.cvtColor(smoothed, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        l = clahe.apply(l)
        enhanced = cv2.merge((l, a, b))
        return cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB)
    
    def apply_premium_bw(self, img, contrast=1.2):
        """Blanco y negro premium con control de contraste"""
        # Convertir a LAB y usar solo canal L
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Ajustar contraste
        l = exposure.rescale_intensity(l, in_range=(0, 255*contrast))
        
        # Convertir de vuelta a RGB (escala de grises)
        return cv2.cvtColor(cv2.merge((l, l, l)), cv2.COLOR_LAB2RGB)
    
    def apply_film_effect(self, img, grain=0.3, fade=0.1):
        """Efecto de película con grano y fade"""
        # Añadir grano
        noise = np.random.normal(0, grain*25, img.shape)
        noisy = cv2.add(img, noise.astype(np.uint8))
        
        # Añadir fade (levemente sepia)
        fade_color = np.array([[[200, 190, 180]]], dtype=np.uint8)
        faded = cv2.addWeighted(noisy, 1-fade, fade_color, fade, 0)
        
        # Reducir ligeramente la saturación
        hsv = cv2.cvtColor(faded, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], 0.9)
        return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    
    def apply_portrait_enhancement(self, img, skin_softness=1.0, eye_enhance=1.5):
        """Mejora de retratos con suavizado de piel y realce de ojos"""
        # Suavizado de piel (bilateral filter)
        soft = cv2.bilateralFilter(img, 9, skin_softness*75, skin_softness*75)
        
        # Detección de bordes para realzar ojos/boca
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        edges = cv2.Laplacian(gray, cv2.CV_64F)
        edges = cv2.normalize(edges, None, 0, 1, cv2.NORM_MINMAX)
        
        # Mezcla controlada
        alpha = 0.3 * eye_enhance
        enhanced = cv2.addWeighted(soft, 1 + alpha, img, -alpha, 0)
        return enhanced
    
    def apply_hdr_effect(self, img, intensity=1.0):
        """Efecto HDR con tonemapping"""
        # Convertir a LAB para procesamiento
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Tonemapping en el canal L
        l_float = l.astype(np.float32) / 255.0
        l_tone = exposure.adjust_log(l_float, gain=intensity)
        l_tone = (l_tone * 255).astype(np.uint8)
        
        # Mezclar con el original para controlar intensidad
        l_enhanced = cv2.addWeighted(l_tone, intensity, l, 1-intensity, 0)
        
        # Recombinar canales
        enhanced = cv2.merge((l_enhanced, a, b))
        return cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB)
    
    def apply_advanced_sepia(self, img, intensity=1.0):
        """Tono sepia avanzado con control de intensidad"""
        # Matriz de transformación sepia
        sepia_matrix = np.array([
            [0.393, 0.769, 0.189],
            [0.349, 0.686, 0.168],
            [0.272, 0.534, 0.131]
        ])
        
        # Aplicar con intensidad controlada
        sepia = cv2.transform(img, sepia_matrix * intensity)
        
        # Mezclar con el original
        return cv2.addWeighted(sepia, intensity, img, 1-intensity, 0)
    
    def apply_noise_reduction(self, img, strength=1.0):
        """Reducción avanzada de ruido"""
        # Aplicar denoising (non-local means)
        denoised = cv2.fastNlMeansDenoisingColored(img, None, strength*10, strength*10, 7, 21)
        
        # Suavizado adicional bilateral
        return cv2.bilateralFilter(denoised, 9, strength*75, strength*75)
    
    def apply_landscape_enhancement(self, img, sky_enhance=1.5, greenery_boost=1.3):
        """Mejora de paisajes con énfasis en cielo y vegetación"""
        # Convertir a HSV
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        
        # Mejorar saturación selectivamente basada en tono
        hue = hsv[:,:,0]
        saturation = hsv[:,:,1]
        
        # Aumentar saturación en verdes (tonos 30-90)
        green_mask = cv2.inRange(hue, 30, 90)
        saturation = cv2.addWeighted(
            saturation, 1, 
            cv2.multiply(saturation, greenery_boost), 
            0.5, 0
        )
        
        # Aumentar contraste en azules (tonos 90-120, cielo)
        blue_mask = cv2.inRange(hue, 90, 120)
        hsv[:,:,2] = cv2.addWeighted(
            hsv[:,:,2], 1, 
            cv2.multiply(hsv[:,:,2], sky_enhance), 
            0.3, 0
        )
        
        hsv[:,:,1] = saturation
        return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    
    def apply_lomo_effect(self, img, vignette=0.5, saturation=1.5):
        """Efecto Lomo con viñeta y saturación aumentada"""
        rows, cols = img.shape[:2]
        
        # Crear máscara de viñeta (elíptica)
        x = np.linspace(-1, 1, cols)
        y = np.linspace(-1, 1, rows)
        X, Y = np.meshgrid(x, y)
        mask = 1 - np.sqrt(X**2 + Y**2) * vignette
        mask = exposure.rescale_intensity(mask, in_range=(0,1))
        mask = np.dstack([mask]*3)
        
        # Aplicar viñeta
        vignetted = cv2.multiply(img.astype(np.float32), mask.astype(np.float32)).astype(np.uint8)
        
        # Aumentar saturación
        hsv = cv2.cvtColor(vignetted, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], saturation)
        return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    
    def apply_night_enhancement(self, img, brightness=1.5, contrast=1.3):
        """Mejora de imágenes nocturnas"""
        # Aumentar brillo y contraste
        enhanced = cv2.convertScaleAbs(img, alpha=contrast, beta=(brightness-1)*50)
        
        # Reducir ruido
        return cv2.fastNlMeansDenoisingColored(enhanced, None, 10, 10, 7, 21)
    
    def apply_sketch_effect(self, img, intensity=1.0):
        """Efecto de dibujo a lápiz"""
        # Convertir a escala de grises
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        
        # Invertir y aplicar blur
        inverted = 255 - gray
        blurred = cv2.GaussianBlur(inverted, (21, 21), 0)
        
        # Dodge blend (divide)
        sketch = cv2.divide(gray, 255-blurred, scale=256)
        sketch = cv2.multiply(sketch, intensity)
        
        # Convertir de vuelta a RGB
        return cv2.cvtColor(sketch, cv2.COLOR_GRAY2RGB)
    
    def apply_food_enhancement(self, img, warmth=1.2, saturation=1.5):
        """Mejora de fotos de alimentos"""
        # Aumentar temperatura (shift hacia rojos/amarillos)
        enhanced = img.astype(np.float32)
        enhanced[:,:,0] = np.minimum(enhanced[:,:,0] * warmth, 255)
        enhanced = enhanced.astype(np.uint8)
        
        # Aumentar saturación
        hsv = cv2.cvtColor(enhanced, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], saturation)
        return cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    
    def apply_vintage_effect(self, img, intensity=1.0):
        """Efecto vintage con tonos cálidos y contraste reducido"""
        # Añadir tono sepia
        sepia = self.apply_advanced_sepia(img, intensity*0.7)
        
        # Reducir contraste
        lab = cv2.cvtColor(sepia, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        l = exposure.rescale_intensity(l, in_range=(50, 200))
        enhanced = cv2.merge((l, a, b))
        
        # Añadir viñeta
        return self.apply_lomo_effect(
            cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB),
            vignette=intensity*0.5,
            saturation=0.9
        )
    
    # --------------------------------------------------
    # VENTANA DE PREVISUALIZACIÓN Y PERSONALIZACIÓN
    # --------------------------------------------------
    
    def open_preview_window(self, index):
        """Abre una ventana de vista previa con opciones de personalización"""
        if not self.img_options or index >= len(self.img_options):
            return
        
        preview_window = tk.Toplevel(self.root)
        preview_window.title(f"Vista Previa - {self.available_filters[self.current_filters[index]]['name']}")
        preview_window.geometry("900x800")
        
        # Frame principal
        main_frame = tk.Frame(preview_window)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Frame para imagen
        img_frame = tk.Frame(main_frame)
        img_frame.pack(fill=tk.BOTH, expand=True)
        
        # Mostrar imagen en tamaño completo con scrollbars si es necesario
        canvas = tk.Canvas(img_frame, bg='white', bd=2, relief=tk.SUNKEN)
        scroll_y = tk.Scrollbar(img_frame, orient="vertical", command=canvas.yview)
        scroll_x = tk.Scrollbar(img_frame, orient="horizontal", command=canvas.xview)
        
        canvas.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Actualizar imagen en el canvas
        img_pil = Image.fromarray(self.img_options[index])
        img_tk = ImageTk.PhotoImage(img_pil)
        
        canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
        canvas.image = img_tk
        canvas.config(scrollregion=canvas.bbox("all"))
        
        # Frame para controles de personalización
        control_frame = tk.LabelFrame(
            main_frame, 
            text="Personalizar Filtro",
            font=('Segoe UI', 10, 'bold'),
            bd=2,
            relief=tk.GROOVE
        )
        control_frame.pack(fill=tk.X, pady=10)
        
        # Crear controles para los parámetros del filtro actual
        filter_id = self.current_filters[index]
        filter_info = self.available_filters[filter_id]
        params = self.filter_params[filter_id]
        
        self.preview_sliders = {}
        
        for param_name, (min_val, max_val) in filter_info["params"].items():
            frame = tk.Frame(control_frame, pady=5)
            frame.pack(fill=tk.X, padx=5)
            
            # Etiqueta del parámetro
            label = tk.Label(
                frame, 
                text=param_name.capitalize() + ":",
                width=15,
                anchor=tk.W
            )
            label.pack(side=tk.LEFT)
            
            # Escala para ajustar el parámetro
            current_val = params[param_name]
            
            if isinstance(min_val, int) and isinstance(max_val, int):
                slider = tk.Scale(
                    frame,
                    from_=min_val,
                    to=max_val,
                    orient=tk.HORIZONTAL,
                    resolution=1,
                    length=200
                )
            else:
                slider = tk.Scale(
                    frame,
                    from_=min_val,
                    to=max_val,
                    orient=tk.HORIZONTAL,
                    resolution=0.1,
                    length=200
                )
            
            slider.set(current_val)
            slider.pack(side=tk.LEFT, fill=tk.X, expand=True)
            self.preview_sliders[param_name] = slider
            
            # Valor actual
            value_label = tk.Label(frame, text=f"{current_val:.2f}", width=6)
            value_label.pack(side=tk.LEFT, padx=5)
            slider.config(command=lambda v, lbl=value_label, s=slider: lbl.config(text=f"{s.get():.2f}"))
        
        # Frame para botones
        button_frame = tk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Botón para aplicar cambios
        tk.Button(
            button_frame,
            text="🔄 Aplicar Cambios",
            command=lambda: self.update_filter_params(index, filter_id, preview_window),
            **self.button_style
        ).pack(side=tk.LEFT, padx=5)
        
        # Botón para guardar imagen
        tk.Button(
            button_frame,
            text="💾 Guardar Imagen",
            command=lambda: self.save_image(index),
            **self.button_style
        ).pack(side=tk.LEFT, padx=5)
        
        # Botón para cerrar
        tk.Button(
            button_frame,
            text="✕ Cerrar",
            command=preview_window.destroy,
            bg='#E74C3C',
            fg='white',
            font=('Segoe UI', 10),
            padx=12
        ).pack(side=tk.RIGHT, padx=5)
    
    def update_filter_params(self, index, filter_id, window):
        """Actualiza los parámetros del filtro y reprocesa la imagen"""
        # Obtener nuevos valores de los sliders
        for param_name, slider in self.preview_sliders.items():
            self.filter_params[filter_id][param_name] = slider.get()
        
        # Reprocesar solo esta imagen
        img_cv = cv2.imread(self.img_path)
        img_cv = cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB)
        
        filter_func = self.available_filters[filter_id]["function"]
        params = self.filter_params[filter_id]
        self.img_options[index] = filter_func(img_cv.copy(), **params)
        
        # Actualizar vista previa
        self.display_processed_images()
        window.destroy()
        messagebox.showinfo("Actualizado", "Los parámetros del filtro han sido actualizados")
    
    def save_image(self, index):
        """Guarda la imagen mejorada seleccionada"""
        if not self.img_path or index >= len(self.img_options):
            return
        
        default_name = os.path.splitext(os.path.basename(self.img_path))[0]
        filter_name = self.available_filters[self.current_filters[index]]["name"].replace(" ", "_")
        
        save_path = filedialog.asksaveasfilename(
            initialfile=f"{default_name}_{filter_name}",
            defaultextension=".png",
            filetypes=[
                ("PNG", "*.png"),
                ("JPEG", "*.jpg"),
                ("TIFF", "*.tiff"),
                ("Todos los archivos", "*.*")
            ],
            title="Guardar imagen como"
        )
        
        if save_path:
            try:
                # Convertir de RGB a BGR para OpenCV
                img_to_save = cv2.cvtColor(self.img_options[index], cv2.COLOR_RGB2BGR)
                cv2.imwrite(save_path, img_to_save)
                messagebox.showinfo("Éxito", f"Imagen guardada exitosamente en:\n{save_path}")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo guardar la imagen:\n{str(e)}")
    
    def run(self):
        """Inicia la aplicación"""
        self.root.mainloop()

if __name__ == "__main__":
    app = PhotoEnhancerPro()
    app.run()