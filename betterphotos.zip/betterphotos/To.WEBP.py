import tkinter as tk
from tkinter import filedialog
from PIL import Image

# Crear ventana oculta de Tkinter
root = tk.Tk()
root.withdraw()

# Abrir explorador de archivos para seleccionar imagen JPG
file_path = filedialog.askopenfilename(filetypes=[("JPG Images", "*.jpg, .png")])

if file_path:  # Si el usuario seleccionó un archivo
    image = Image.open(file_path)  # Abrir la imagen
    save_path = file_path.rsplit(".", 1)[0] + ".webp"  # Cambiar extensión a .webp
    image.save(save_path, "WEBP")  # Guardar la imagen en formato WebP
    print(f"Imagen guardada como: {save_path}")
else:
    print("No se seleccionó ninguna imagen.")
# Eliminar ventana oculta de Tkinter
root.destroy()  
