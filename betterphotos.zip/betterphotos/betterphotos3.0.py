import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox, ttk
from PIL import Image, ImageTk, ImageOps
import cv2
import numpy as np
import os
from skimage import exposure
from skimage.filters import unsharp_mask

class AdvancedPhotoEnhancer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Mejorador de Fotos con Filtros Personalizables")
        self.root.geometry("1300x900")
        self.root.minsize(1000, 700)
        
        # Variables de estado
        self.img_path = None
        self.img_original = None
        self.img_options = []
        self.current_filters = [
            "advanced_clahe", 
            "adaptive_gamma", 
            "smart_sharpening", 
            "color_detail"
        ]
        self.filter_params = {
            "advanced_clahe": {"clip_limit": 2.5, "tile_size": 12, "blend_alpha": 0.7},
            "adaptive_gamma": {"gamma": 1.2, "saturation": 1.2},
            "smart_sharpening": {"radius": 2, "amount": 1.5, "alpha": 0.5},
            "color_detail": {"saturation": 1.3, "sharp_amount": 0.8}
        }
        
        # Configuración de estilos
        self.setup_styles()
        self.create_widgets()
        self.setup_responsive_grid()
        
        # Manejar redimensionamiento
        self.root.bind("<Configure>", self.on_window_resize)
    
    def setup_styles(self):
        """Configura los estilos visuales de la aplicación"""
        self.bg_color = "#f5f5f5"
        self.button_style = {
            'bg': '#5D6D7E', 
            'fg': 'white', 
            'padx': 12, 
            'pady': 6,
            'font': ('Segoe UI', 10),
            'relief': tk.GROOVE,
            'borderwidth': 2
        }
        self.small_button_style = {
            'bg': '#5D6D7E', 
            'fg': 'white', 
            'padx': 8, 
            'pady': 3,
            'font': ('Segoe UI', 8),
            'relief': tk.GROOVE,
            'borderwidth': 1
        }
        self.frame_style = {'padx': 10, 'pady': 10, 'bg': self.bg_color}
        self.label_frame_style = {
            'font': ('Segoe UI', 10, 'bold'),
            'bd': 2,
            'relief': tk.GROOVE,
            'bg': self.bg_color
        }
        self.root.configure(bg=self.bg_color)
    
    def create_widgets(self):
        """Crea y organiza los widgets en la interfaz"""
        # Frame superior para controles
        self.control_frame = tk.Frame(self.root, **self.frame_style)
        self.control_frame.pack(fill=tk.X)
        
        # Botón para seleccionar imagen
        tk.Button(self.control_frame, text="📁 Seleccionar Imagen", 
                 command=self.open_image, **self.button_style).pack(side=tk.LEFT, padx=5)
        
        # Botón para rehacer procesamiento con nuevos parámetros
        self.redo_button = tk.Button(self.control_frame, text="🔄 Rehacer con Nuevos Filtros", 
                                   command=self.open_filter_settings, **self.button_style)
        self.redo_button.pack(side=tk.LEFT, padx=5)
        self.redo_button.config(state=tk.DISABLED)
        
        # Frame principal para imágenes
        self.main_frame = tk.Frame(self.root, **self.frame_style)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Frame para imagen original
        self.original_frame = tk.LabelFrame(self.main_frame, **self.label_frame_style)
        self.original_frame.configure(text="Imagen Original")
        self.original_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        self.label_original = tk.Label(self.original_frame, bg='white', bd=2, relief=tk.SUNKEN)
        self.label_original.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # Frame para resultados
        self.results_frame = tk.LabelFrame(self.main_frame, **self.label_frame_style)
        self.results_frame.configure(text="Opciones Mejoradas")
        self.results_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        
        # Crear frames para las imágenes mejoradas
        self.setup_result_frames()
    
    def setup_responsive_grid(self):
        """Configura el grid para ser responsive"""
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)
        
        self.original_frame.grid_rowconfigure(0, weight=1)
        self.original_frame.grid_columnconfigure(0, weight=1)
        
        self.results_frame.grid_rowconfigure(0, weight=1)
        for i in range(4):
            self.results_frame.grid_columnconfigure(i, weight=1)
    
    def setup_result_frames(self):
        """Configura los frames para las imágenes mejoradas"""
        self.result_frames = []
        self.label_results = []
        self.filter_buttons = []
        
        for i in range(4):
            frame = tk.Frame(self.results_frame, bg=self.bg_color)
            frame.grid(row=0, column=i, padx=5, pady=5, sticky="nsew")
            self.result_frames.append(frame)
            
            # Configurar grid interno
            frame.grid_rowconfigure(0, weight=1)
            frame.grid_columnconfigure(0, weight=1)
            
            # Label para la imagen
            img_label = tk.Label(frame, bg='white', bd=2, relief=tk.SUNKEN)
            img_label.grid(row=0, column=0, sticky="nsew")
            img_label.bind("<Button-1>", lambda e, idx=i: self.open_preview_window(idx))
            self.label_results.append(img_label)
            
            # Frame para controles
            ctrl_frame = tk.Frame(frame, bg=self.bg_color)
            ctrl_frame.grid(row=1, column=0, sticky="ew")
            
            # Descripción
            desc_label = tk.Label(
                ctrl_frame, 
                text=self.get_enhancement_description(i),
                bg=self.bg_color,
                font=('Segoe UI', 8)
            )
            desc_label.pack(side=tk.LEFT, padx=2)
            
            # Botón para cambiar filtro
            filter_btn = tk.Button(
                ctrl_frame, 
                text="⚙️", 
                command=lambda idx=i: self.change_filter(idx),
                **self.small_button_style
            )
            filter_btn.pack(side=tk.LEFT, padx=2)
            self.filter_buttons.append(filter_btn)
            
            # Botón de guardado
            save_btn = tk.Button(
                ctrl_frame, 
                text="💾", 
                command=lambda idx=i: self.save_image(idx),
                **self.small_button_style
            )
            save_btn.pack(side=tk.RIGHT, padx=2)
    
    def change_filter(self, index):
        """Permite cambiar el filtro aplicado a una posición específica"""
        if not self.img_path:
            return
            
        filter_window = tk.Toplevel(self.root)
        filter_window.title(f"Seleccionar Filtro para Posición {index+1}")
        filter_window.geometry("400x300")
        
        # Lista de filtros disponibles
        available_filters = {
            "advanced_clahe": "CLAHE Avanzado",
            "adaptive_gamma": "Corrección Gamma",
            "smart_sharpening": "Enfoque Inteligente",
            "color_detail": "Mejora Color/Detalle",
            "edge_enhance": "Realce de Bordes",
            "denoise": "Reducción de Ruido"
        }
        
        # Variable para selección actual
        current_filter = tk.StringVar(value=self.current_filters[index])
        
        # Frame para selección
        selection_frame = tk.Frame(filter_window, padx=10, pady=10)
        selection_frame.pack(fill=tk.BOTH, expand=True)
        
        # Lista de filtros
        for i, (filter_id, filter_name) in enumerate(available_filters.items()):
            rb = tk.Radiobutton(
                selection_frame,
                text=filter_name,
                variable=current_filter,
                value=filter_id,
                font=('Segoe UI', 10)
            )
            rb.pack(anchor=tk.W, pady=2)
        
        # Botones
        button_frame = tk.Frame(filter_window, pady=10)
        button_frame.pack(fill=tk.X)
        
        tk.Button(
            button_frame,
            text="Aplicar",
            command=lambda: self.apply_new_filter(index, current_filter.get(), filter_window),
            **self.button_style
        ).pack(side=tk.LEFT, padx=10)
        
        tk.Button(
            button_frame,
            text="Cancelar",
            command=filter_window.destroy,
            bg='#E74C3C',
            fg='white'
        ).pack(side=tk.RIGHT, padx=10)
    
    def apply_new_filter(self, index, new_filter, window):
        """Aplica un nuevo filtro a la posición especificada"""
        self.current_filters[index] = new_filter
        window.destroy()
        self.process_image()
        messagebox.showinfo("Filtro Cambiado", f"Se aplicó {self.get_enhancement_description(index)}")
    
    def open_filter_settings(self):
        """Abre la ventana de configuración de filtros"""
        if not self.img_path:
            return
            
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Configuración de Filtros")
        settings_window.geometry("500x600")
        
        # Notebook para pestañas
        notebook = ttk.Notebook(settings_window)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # Crear una pestaña para cada filtro
        for i, filter_id in enumerate(self.current_filters):
            tab = ttk.Frame(notebook)
            notebook.add(tab, text=f"Filtro {i+1}")
            
            # Título
            title_label = tk.Label(
                tab,
                text=self.get_enhancement_description(i),
                font=('Segoe UI', 10, 'bold'),
                pady=10
            )
            title_label.pack()
            
            # Controles específicos para cada filtro
            if filter_id == "advanced_clahe":
                self.create_clahe_controls(tab, i)
            elif filter_id == "adaptive_gamma":
                self.create_gamma_controls(tab, i)
            elif filter_id == "smart_sharpening":
                self.create_sharpening_controls(tab, i)
            elif filter_id == "color_detail":
                self.create_color_controls(tab, i)
        
        # Botón para aplicar cambios
        button_frame = tk.Frame(settings_window, pady=10)
        button_frame.pack(fill=tk.X)
        
        tk.Button(
            button_frame,
            text="Aplicar Todos los Cambios",
            command=lambda: self.apply_filter_changes(settings_window),
            **self.button_style
        ).pack(pady=5)
    
    def create_clahe_controls(self, parent, index):
        """Crea controles para ajustar CLAHE"""
        params = self.filter_params["advanced_clahe"]
        
        # Clip Limit
        clip_frame = tk.Frame(parent, pady=5)
        clip_frame.pack(fill=tk.X)
        tk.Label(clip_frame, text="Límite de Clip:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        clip_scale = tk.Scale(
            clip_frame,
            from_=1.0,
            to=5.0,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["clip_limit"])
        )
        clip_scale.pack(fill=tk.X, expand=True)
        
        # Tile Size
        tile_frame = tk.Frame(parent, pady=5)
        tile_frame.pack(fill=tk.X)
        tk.Label(tile_frame, text="Tamaño de Tile:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        tile_scale = tk.Scale(
            tile_frame,
            from_=4,
            to=20,
            resolution=2,
            orient=tk.HORIZONTAL,
            variable=tk.IntVar(value=params["tile_size"])
        )    
        tile_scale.pack(fill=tk.X, expand=True)
        
        # Blend Alpha
        alpha_frame = tk.Frame(parent, pady=5)
        alpha_frame.pack(fill=tk.X)
        tk.Label(alpha_frame, text="Mezcla (Alpha):", width=15, anchor=tk.W).pack(side=tk.LEFT)
        alpha_scale = tk.Scale(
            alpha_frame,
            from_=0.1,
            to=1.0,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["blend_alpha"])
            )
        alpha_scale.pack(fill=tk.X, expand=True)
        
        # Guardar referencias para actualización
        self.filter_params["advanced_clahe"]["clip_limit"] = clip_scale
        self.filter_params["advanced_clahe"]["tile_size"] = tile_scale
        self.filter_params["advanced_clahe"]["blend_alpha"] = alpha_scale
    
    def create_gamma_controls(self, parent, index):
        """Crea controles para ajustar Gamma"""
        params = self.filter_params["adaptive_gamma"]
        
        # Gamma
        gamma_frame = tk.Frame(parent, pady=5)
        gamma_frame.pack(fill=tk.X)
        tk.Label(gamma_frame, text="Valor Gamma:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        gamma_scale = tk.Scale(
            gamma_frame,
            from_=0.5,
            to=2.5,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["gamma"])
        )
        gamma_scale.pack(fill=tk.X, expand=True)
        
        # Saturación
        sat_frame = tk.Frame(parent, pady=5)
        sat_frame.pack(fill=tk.X)
        tk.Label(sat_frame, text="Saturación:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        sat_scale = tk.Scale(
            sat_frame,
            from_=0.5,
            to=2.0,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["saturation"])
        )
        sat_scale.pack(fill=tk.X, expand=True)
        
        # Guardar referencias para actualización
        self.filter_params["adaptive_gamma"]["gamma"] = gamma_scale
        self.filter_params["adaptive_gamma"]["saturation"] = sat_scale
    
    def create_sharpening_controls(self, parent, index):
        """Crea controles para ajustar enfoque"""
        params = self.filter_params["smart_sharpening"]
        
        # Radio
        radius_frame = tk.Frame(parent, pady=5)
        radius_frame.pack(fill=tk.X)
        tk.Label(radius_frame, text="Radio:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        radius_scale = tk.Scale(
            radius_frame,
            from_=1,
            to=5,
            resolution=0.5,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["radius"])
        )
        radius_scale.pack(fill=tk.X, expand=True)
        
        # Cantidad
        amount_frame = tk.Frame(parent, pady=5)
        amount_frame.pack(fill=tk.X)
        tk.Label(amount_frame, text="Cantidad:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        amount_scale = tk.Scale(
            amount_frame,
            from_=0.5,
            to=3.0,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["amount"])
            )
        amount_scale.pack(fill=tk.X, expand=True)
        
        # Alpha
        alpha_frame = tk.Frame(parent, pady=5)
        alpha_frame.pack(fill=tk.X)
        tk.Label(alpha_frame, text="Mezcla (Alpha):", width=15, anchor=tk.W).pack(side=tk.LEFT)
        alpha_scale = tk.Scale(
            alpha_frame,
            from_=0.1,
            to=1.0,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["alpha"])
        )
        alpha_scale.pack(fill=tk.X, expand=True)
        
        # Guardar referencias para actualización
        self.filter_params["smart_sharpening"]["radius"] = radius_scale
        self.filter_params["smart_sharpening"]["amount"] = amount_scale
        self.filter_params["smart_sharpening"]["alpha"] = alpha_scale
    
    def create_color_controls(self, parent, index):
        """Crea controles para ajustar color/detalle"""
        params = self.filter_params["color_detail"]
        
        # Saturación
        sat_frame = tk.Frame(parent, pady=5)
        sat_frame.pack(fill=tk.X)
        tk.Label(sat_frame, text="Saturación:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        sat_scale = tk.Scale(
            sat_frame,
            from_=0.5,
            to=2.0,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["saturation"])
            )
        sat_scale.pack(fill=tk.X, expand=True)
        
        # Enfoque
        sharp_frame = tk.Frame(parent, pady=5)
        sharp_frame.pack(fill=tk.X)
        tk.Label(sharp_frame, text="Cantidad de Enfoque:", width=15, anchor=tk.W).pack(side=tk.LEFT)
        sharp_scale = tk.Scale(
            sharp_frame,
            from_=0.1,
            to=1.5,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=tk.DoubleVar(value=params["sharp_amount"])
        )
        sharp_scale.pack(fill=tk.X, expand=True)
        
        # Guardar referencias para actualización
        self.filter_params["color_detail"]["saturation"] = sat_scale
        self.filter_params["color_detail"]["sharp_amount"] = sharp_scale
    
    def apply_filter_changes(self, window):
        """Aplica todos los cambios de parámetros"""
        # Actualizar parámetros de CLAHE
        clahe_params = self.filter_params["advanced_clahe"]
        clahe_params["clip_limit"] = clahe_params["clip_limit"].get()
        clahe_params["tile_size"] = int(clahe_params["tile_size"].get())
        clahe_params["blend_alpha"] = clahe_params["blend_alpha"].get()
        
        # Actualizar parámetros de Gamma
        gamma_params = self.filter_params["adaptive_gamma"]
        gamma_params["gamma"] = gamma_params["gamma"].get()
        gamma_params["saturation"] = gamma_params["saturation"].get()
        
        # Actualizar parámetros de Enfoque
        sharp_params = self.filter_params["smart_sharpening"]
        sharp_params["radius"] = sharp_params["radius"].get()
        sharp_params["amount"] = sharp_params["amount"].get()
        sharp_params["alpha"] = sharp_params["alpha"].get()
        
        # Actualizar parámetros de Color/Detalle
        color_params = self.filter_params["color_detail"]
        color_params["saturation"] = color_params["saturation"].get()
        color_params["sharp_amount"] = color_params["sharp_amount"].get()
        
        window.destroy()
        self.process_image()
        messagebox.showinfo("Cambios Aplicados", "Todos los parámetros han sido actualizados")
    
    def on_window_resize(self, event):
        """Maneja el redimensionamiento de la ventana"""
        if hasattr(self, 'img_original') and self.img_original:
            self.display_original_image()
            self.display_processed_images()
    
    def get_enhancement_description(self, index):
        """Devuelve la descripción de cada técnica de mejora"""
        filter_id = self.current_filters[index]
        descriptions = {
            "advanced_clahe": "CLAHE Avanzado",
            "adaptive_gamma": "Corrección Gamma",
            "smart_sharpening": "Enfoque Inteligente",
            "color_detail": "Mejora Color/Detalle",
            "edge_enhance": "Realce de Bordes",
            "denoise": "Reducción de Ruido"
        }
        return descriptions.get(filter_id, "Filtro Desconocido")
    
    def open_image(self):
        """Abre y carga la imagen seleccionada"""
        filetypes = [
            ("Imágenes", "*.png;*.jpg;*.jpeg;*.bmp;*.tiff"), 
            ("Todos los archivos", "*.*")
        ]
        img_path = filedialog.askopenfilename(filetypes=filetypes)
        
        if img_path:
            try:
                self.img_path = img_path
                self.img_original = Image.open(img_path)
                self.display_original_image()
                self.process_image()
                self.redo_button.config(state=tk.NORMAL)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo cargar la imagen:\n{str(e)}")
    
    def display_original_image(self):
        """Muestra la imagen original con bordes y tamaño responsive"""
        if self.img_original:
            try:
                img = self.img_original.copy()
                
                # Calcular tamaño basado en el espacio disponible
                frame_width = self.original_frame.winfo_width() - 20
                frame_height = self.original_frame.winfo_height() - 20
                
                if frame_width > 1 and frame_height > 1:
                    img.thumbnail((frame_width, frame_height), Image.LANCZOS)
                
                # Añadir bordes decorativos
                img = ImageOps.expand(img, border=2, fill='white')
                img = ImageOps.expand(img, border=1, fill='#34495E')
                
                # Convertir para Tkinter
                img_tk = ImageTk.PhotoImage(img)
                
                # Actualizar label
                self.label_original.config(image=img_tk)
                self.label_original.image = img_tk
                
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo mostrar la imagen:\n{str(e)}")
    
    def process_image(self):
        """Procesa la imagen con los algoritmos mejorados"""
        if not self.img_path:
            messagebox.showwarning("Advertencia", "Primero seleccione una imagen")
            return
        
        try:
            # Procesar con los algoritmos seleccionados
            self.img_options = []
            img = cv2.imread(self.img_path)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            
            for filter_id in self.current_filters:
                if filter_id == "advanced_clahe":
                    self.img_options.append(self.apply_advanced_clahe(img))
                elif filter_id == "adaptive_gamma":
                    self.img_options.append(self.apply_adaptive_gamma(img))
                elif filter_id == "smart_sharpening":
                    self.img_options.append(self.apply_smart_sharpening(img))
                elif filter_id == "color_detail":
                    self.img_options.append(self.apply_color_detail_enhancement(img))
                else:
                    # Filtro por defecto si no se reconoce
                    self.img_options.append(img.copy())
            
            self.display_processed_images()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al procesar la imagen:\n{str(e)}")
    
    def display_processed_images(self):
        """Muestra las imágenes procesadas con tamaño responsive"""
        if not self.img_options:
            return
            
        for i, img in enumerate(self.img_options):
            try:
                img_pil = Image.fromarray(img)
                
                # Calcular tamaño basado en el espacio disponible
                frame_width = self.result_frames[i].winfo_width() - 20
                frame_height = self.result_frames[i].winfo_height() - 40
                
                if frame_width > 1 and frame_height > 1:
                    img_pil.thumbnail((frame_width, frame_height), Image.LANCZOS)
                
                # Añadir bordes decorativos
                img_pil = ImageOps.expand(img_pil, border=2, fill='white')
                img_pil = ImageOps.expand(img_pil, border=1, fill='#34495E')
                
                # Convertir para Tkinter
                img_tk = ImageTk.PhotoImage(img_pil)
                
                # Actualizar label
                self.label_results[i].config(image=img_tk)
                self.label_results[i].image = img_tk
                
                # Actualizar descripción
                for widget in self.result_frames[i].winfo_children():
                    if isinstance(widget, tk.Frame):
                        for child in widget.winfo_children():
                            if isinstance(child, tk.Label) and child['text'] != "💾":
                                child.config(text=self.get_enhancement_description(i))
                
            except Exception as e:
                print(f"Error mostrando imagen {i}: {str(e)}")
    
    def apply_advanced_clahe(self, img):
        """CLAHE mejorado con parámetros configurables"""
        params = self.filter_params["advanced_clahe"]
        
        # Convertir a LAB
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Suavizado previo
        l_smooth = cv2.bilateralFilter(l, 9, 75, 75)
        
        # CLAHE con parámetros configurables
        clahe = cv2.createCLAHE(
            clipLimit=params["clip_limit"],
            tileGridSize=(params["tile_size"], params["tile_size"])
        )
        l_clahe = clahe.apply(l_smooth)
        
        # Mezcla controlada
        l_enhanced = cv2.addWeighted(l_clahe, params["blend_alpha"], l, 1-params["blend_alpha"], 0)
        
        # Mejorar contraste local
        l_enhanced = exposure.equalize_adapthist(l_enhanced.astype(np.float32)/255.0)
        l_enhanced = (l_enhanced * 255).astype(np.uint8)
        
        # Recombinar canales
        enhanced = cv2.merge((l_enhanced, a, b))
        enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB)
        
        return enhanced
    
    def apply_adaptive_gamma(self, img):
        """Corrección gamma con parámetros configurables"""
        params = self.filter_params["adaptive_gamma"]
        
        # Aplicar corrección gamma
        inv_gamma = 1.0 / params["gamma"]
        table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
        enhanced = cv2.LUT(img, table)
        
        # Mejorar saturación
        hsv = cv2.cvtColor(enhanced, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], params["saturation"])
        enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        
        return enhanced
    
    def apply_smart_sharpening(self, img):
        """Enfoque inteligente con parámetros configurables"""
        params = self.filter_params["smart_sharpening"]
        
        # Suavizado inicial
        smooth = cv2.bilateralFilter(img, 9, 75, 75)
        
        # Enfoque con máscara de enfoque
        sharpened = unsharp_mask(
            smooth.astype(np.float32)/255.0,
            radius=params["radius"],
            amount=params["amount"]
        )
        sharpened = (sharpened * 255).astype(np.uint8)
        
        # Mezcla controlada
        enhanced = cv2.addWeighted(sharpened, 1 + params["alpha"], img, -params["alpha"], 0)
        
        return enhanced
    
    def apply_color_detail_enhancement(self, img):
        """Mejora de color y detalle con parámetros configurables"""
        params = self.filter_params["color_detail"]
        
        # Mejora de color en LAB
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        
        # Ecualización adaptativa del canal L
        l_enhanced = exposure.equalize_adapthist(l.astype(np.float32)/255.0, clip_limit=0.03)
        l_enhanced = (l_enhanced * 255).astype(np.uint8)
        
        # Mejora de saturación en HSV
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        hsv[:,:,1] = cv2.multiply(hsv[:,:,1], params["saturation"])
        
        # Mezcla de resultados
        color_enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        lab_color = cv2.cvtColor(color_enhanced, cv2.COLOR_RGB2LAB)
        _, a_color, b_color = cv2.split(lab_color)
        
        # Recombinar
        enhanced_lab = cv2.merge((l_enhanced, a_color, b_color))
        enhanced = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2RGB)
        
        # Enfoque selectivo
        enhanced = unsharp_mask(enhanced.astype(np.float32)/255.0, radius=1, amount=params["sharp_amount"])
        enhanced = (enhanced * 255).astype(np.uint8)
        
        return enhanced
    
    def open_preview_window(self, index):
        """Abre una ventana de vista previa ampliada"""
        if not self.img_options or index >= len(self.img_options):
            return
        
        preview_window = tk.Toplevel(self.root)
        preview_window.title(f"Vista Previa - {self.get_enhancement_description(index)}")
        preview_window.geometry("800x700")
        
        # Frame para imagen
        img_frame = tk.Frame(preview_window)
        img_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Mostrar imagen en tamaño completo
        img_pil = Image.fromarray(self.img_options[index])
        img_tk = ImageTk.PhotoImage(img_pil)
        
        canvas = tk.Canvas(img_frame, bg='white', bd=2, relief=tk.SUNKEN)
        canvas.pack(fill=tk.BOTH, expand=True)
        canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
        canvas.image = img_tk
        
        # Frame para controles
        ctrl_frame = tk.Frame(preview_window, bg=self.bg_color)
        ctrl_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # Botones
        tk.Button(ctrl_frame, text="💾 Guardar Imagen", 
                 command=lambda: self.save_image(index), **self.button_style).pack(side=tk.LEFT, padx=5)
        
        tk.Button(ctrl_frame, text="⚙️ Ajustar Parámetros", 
                 command=lambda: self.open_filter_settings(), **self.button_style).pack(side=tk.LEFT, padx=5)
        
        tk.Button(ctrl_frame, text="✕ Cerrar", 
                 command=preview_window.destroy,
                 bg='#E74C3C', fg='white',
                 font=('Segoe UI', 10), padx=12).pack(side=tk.RIGHT, padx=5)
    
    def save_image(self, index):
        """Guarda la imagen mejorada seleccionada"""
        if not self.img_path or index >= len(self.img_options):
            return
        
        default_name = os.path.splitext(os.path.basename(self.img_path))[0]
        enhancement_type = self.get_enhancement_description(index).replace(" ", "_").lower()
        
        save_path = filedialog.asksaveasfilename(
            initialfile=f"{default_name}_{enhancement_type}",
            defaultextension=".png",
            filetypes=[
                ("PNG", "*.png"),
                ("JPEG", "*.jpg"),
                ("TIFF", "*.tiff"),
                ("Todos los archivos", "*.*")
            ],
            title="Guardar imagen como"
        )
        
        if save_path:
            try:
                # Convertir de RGB a BGR para OpenCV
                img_to_save = cv2.cvtColor(self.img_options[index], cv2.COLOR_RGB2BGR)
                cv2.imwrite(save_path, img_to_save)
                messagebox.showinfo("Éxito", f"Imagen guardada exitosamente en:\n{save_path}")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo guardar la imagen:\n{str(e)}")
    
    def run(self):
        """Inicia la aplicación"""
        self.root.mainloop()

if __name__ == "__main__":
    app = AdvancedPhotoEnhancer()
    app.run()