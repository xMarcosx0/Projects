import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk, ImageEnhance
import os
import random
import threading

def mejorar_imagen(img_path):
    """Genera 4 variaciones suaves de la imagen para evitar la saturación excesiva."""
    img = Image.open(img_path).convert("RGB")
    img = img.resize((250, 250))
    mejoras = []
    
    for _ in range(4):
        new_img = img.copy()
        
        # Mejora 1: Contraste moderado (no excesivo)
        enhancer = ImageEnhance.Contrast(new_img)
        factor = random.uniform(1.0, 1.3)  # Contraste más suave
        new_img = enhancer.enhance(factor)
        
        # Mejora 2: Brillo suave
        enhancer = ImageEnhance.Brightness(new_img)
        factor = random.uniform(1.0, 1.2)  # Brillo moderado
        new_img = enhancer.enhance(factor)
        
        # Mejora 3: Nitidez moderada
        enhancer = ImageEnhance.Sharpness(new_img)
        factor = random.uniform(1.0, 1.3)  # Nitidez no agresiva
        new_img = enhancer.enhance(factor)
        
        # Mejora 4: Saturación ajustada (no exagerada)
        enhancer = ImageEnhance.Color(new_img)
        factor = random.uniform(1.0, 1.2)  # Saturación moderada
        new_img = enhancer.enhance(factor)
        
        mejoras.append(new_img)
    
    return mejoras

def seleccionar_imagen():
    global img_path_actual
    archivo = filedialog.askopenfilename(filetypes=[("Imágenes", "*.png;*.jpg;*.jpeg")])
    if archivo:
        img_path_actual = archivo
        mostrar_imagenes(archivo)

def mostrar_imagenes(img_path):
    global imagen_original, imagenes_mejoradas, mejoras_imgs, img_labels, historial_imgs
    
    for lbl in img_labels:
        lbl.destroy()
    
    if imagen_original:
        historial_imgs.append(imagen_original)
        actualizar_historial()
    
    img = Image.open(img_path).resize((250, 250))
    imagen_original = ImageTk.PhotoImage(img)
    img_label = tk.Label(frame_imagenes, image=imagen_original)
    img_label.grid(row=0, column=0, padx=10, pady=10)
    img_label.bind("<Button-1>", lambda e: abrir_ventana_guardado(img_path))
    img_labels.append(img_label)
    
    generar_mejoras(img_path)

def generar_mejoras(img_path):
    global mejoras_imgs, imagenes_mejoradas
    
    lbl_carga = tk.Label(frame_imagenes, text="Generando mejoras...", font=("Arial", 12))
    lbl_carga.grid(row=1, column=1, padx=10, pady=10)
    
    def procesar():
        nonlocal lbl_carga
        mejoras_imgs = mejorar_imagen(img_path)
        imagenes_mejoradas.clear()
        
        lbl_carga.destroy()
        
        for i, mejora in enumerate(mejoras_imgs):
            img_tk = ImageTk.PhotoImage(mejora)
            imagenes_mejoradas.append(img_tk)
            lbl = tk.Label(frame_imagenes, image=img_tk)
            lbl.grid(row=i//2, column=(i % 2) + 1, padx=10, pady=10)
            lbl.bind("<Button-1>", lambda e, p=mejora: abrir_ventana_guardado(p))
            img_labels.append(lbl)
    
    threading.Thread(target=procesar).start()

def actualizar_historial():
    for widget in frame_historial.winfo_children():
        widget.destroy()
    for img_tk in historial_imgs[-5:]:  # Muestra solo las últimas 5 imágenes previas
        lbl = tk.Label(frame_historial, image=img_tk)
        lbl.pack(padx=5, pady=5)

def abrir_ventana_guardado(imagen):
    ventana = tk.Toplevel(root)
    ventana.title("Guardar Imagen")
    
    img = imagen if isinstance(imagen, Image.Image) else Image.open(imagen)
    img = img.resize((300, 300))
    img_tk = ImageTk.PhotoImage(img)
    
    lbl_img = tk.Label(ventana, image=img_tk)
    lbl_img.image = img_tk
    lbl_img.pack()
    
    def guardar():
        archivo = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("JPG files", "*.jpg")])
        if archivo:
            img.save(archivo)
        ventana.destroy()
    
    btn_guardar = tk.Button(ventana, text="Guardar", command=guardar)
    btn_guardar.pack()
    
    btn_volver = tk.Button(ventana, text="Volver", command=ventana.destroy)
    btn_volver.pack()

def guardar_imagenes():
    for i, mejora in enumerate(mejoras_imgs):
        archivo = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("JPG files", "*.jpg")])
        if archivo:
            mejora.save(archivo)

def rehacer_mejoras():
    if img_path_actual:
        generar_mejoras(img_path_actual)

# Interfaz gráfica
root = tk.Tk()
root.title("BetterPhotos")

frame_imagenes = tk.Frame(root)
frame_imagenes.pack(side=tk.LEFT)

frame_historial = tk.Frame(root)
frame_historial.pack(side=tk.RIGHT)

btn_seleccionar = tk.Button(root, text="Seleccionar Imagen", command=seleccionar_imagen)
btn_seleccionar.pack()

btn_guardar = tk.Button(root, text="Guardar Imágenes", command=guardar_imagenes)
btn_guardar.pack()

btn_rehacer = tk.Button(root, text="Rehacer Mejoras", command=rehacer_mejoras)
btn_rehacer.pack()

img_labels = []
historial_imgs = []
imagen_original = None
imagenes_mejoradas = []
mejoras_imgs = []
img_path_actual = ""

root.mainloop()
