document.addEventListener("DOMContentLoaded", () => {
  // Verificar autenticación de administrador
  if (!checkAdminAuth()) return

  // Referencias a elementos del DOM
  const userNameElement = document.getElementById("user-name")
  const userRoleElement = document.getElementById("user-role")
  const logoutBtn = document.getElementById("logout-btn")
  const searchInput = document.getElementById("search-input")
  const loadingIndicator = document.getElementById("loading-indicator")
  const auditLogsTableContainer = document.getElementById("audit-logs-table-container")
  const auditLogsTableBody = document.getElementById("audit-logs-table-body")
  const noResultsMessage = document.getElementById("no-results-message")

  // Variables globales
  let auditLogs = []

  // Mostrar información del usuario
  userNameElement.textContent = getUserName()
  userRoleElement.textContent = getUserRole() === "admin" ? "Administrador" : "Usuario"

  // Event Listeners
  logoutBtn.addEventListener("click", logout)
  searchInput.addEventListener("input", filterAuditLogs)

  // Cargar logs de auditoría
  loadAuditLogs()

  // Función para cargar logs de auditoría
  function loadAuditLogs() {
    loadingIndicator.classList.remove("d-none")
    auditLogsTableContainer.classList.add("d-none")
    noResultsMessage.classList.add("d-none")

    fetchAuditLogs()
      .then((data) => {
        auditLogs = data
        renderAuditLogs(auditLogs)
        loadingIndicator.classList.add("d-none")

        if (auditLogs.length > 0) {
          auditLogsTableContainer.classList.remove("d-none")
        } else {
          noResultsMessage.classList.remove("d-none")
        }
      })
      .catch((error) => {
        console.error("Error al cargar logs de auditoría:", error)
        loadingIndicator.classList.add("d-none")
        alert("Error al cargar los registros de auditoría. Por favor intente nuevamente.")
      })
  }

  // Función para renderizar logs de auditoría en la tabla
  function renderAuditLogs(logsToRender) {
    auditLogsTableBody.innerHTML = ""

    if (logsToRender.length === 0) {
      auditLogsTableContainer.classList.add("d-none")
      noResultsMessage.classList.remove("d-none")
      return
    }

    auditLogsTableContainer.classList.remove("d-none")
    noResultsMessage.classList.add("d-none")

    logsToRender.forEach((log) => {
      const row = document.createElement("tr")

      // Determinar la clase de badge según la acción
      let badgeClass = ""
      switch (log.action) {
        case "CREATE":
          badgeClass = "badge-create"
          break
        case "UPDATE":
          badgeClass = "badge-update"
          break
        case "DELETE":
          badgeClass = "badge-delete"
          break
        case "VIEW":
          badgeClass = "badge-view"
          break
        default:
          badgeClass = "bg-secondary"
      }

      // Formatear fecha
      const timestamp = new Date(log.timestamp).toLocaleString()

      row.innerHTML = `
                <td>${log.id}</td>
                <td>${log.username}</td>
                <td><span class="badge ${badgeClass}">${log.action}</span></td>
                <td>${log.entityType}</td>
                <td>${log.entityId}</td>
                <td>${log.details}</td>
                <td>${timestamp}</td>
            `

      auditLogsTableBody.appendChild(row)
    })
  }

  // Función para filtrar logs de auditoría
  function filterAuditLogs() {
    const searchTerm = searchInput.value.toLowerCase()

    if (searchTerm === "") {
      renderAuditLogs(auditLogs)
      return
    }

    const filteredLogs = auditLogs.filter(
      (log) =>
        log.username.toLowerCase().includes(searchTerm) ||
        log.action.toLowerCase().includes(searchTerm) ||
        log.entityType.toLowerCase().includes(searchTerm) ||
        log.details.toLowerCase().includes(searchTerm),
    )

    renderAuditLogs(filteredLogs)
  }
})

