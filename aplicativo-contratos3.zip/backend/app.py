from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import json
import os
from datetime import datetime

app = FastAPI(title="API de Contratos PRST", description="API para gestión de contratos PRST")

# Configurar CORS para permitir solicitudes desde el frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # En producción, especifica los orígenes permitidos
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ruta al archivo JSON de datos
DATA_FILE = "data/contracts.json"

# Asegurar que el directorio de datos existe
os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)

# Crear archivo JSON si no existe
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as f:
        json.dump({"contracts": [], "audit_logs": []}, f)

# Modelos de datos
class ContractBase(BaseModel):
    nombrePRST: str
    nombreCorto: str
    responsable: str
    clasificacion: str
    estado: str
    valorContrato: float
    duracionAnios: int
    inicioVigencia: str
    finVigencia: str

class Contract(ContractBase):
    id: int
    ultimoContrato: bool = False
    enviadoDigitalmente: bool = False
    enviadoFisicamente: bool = False
    fisicamenteEnOficina: bool = False
    fechaPreLiquidacion: Optional[str] = None
    fechaRadFactura: Optional[str] = None
    estadoContrato: str = "Vigente"
    proximoVencer: bool = False
    
    # Infraestructura
    cable8M: int = 0
    cable10M: int = 0
    cable12M: int = 0
    cable14M: int = 0
    cable15M: int = 0
    cable16M: int = 0
    cable20M: int = 0
    
    cajaEmpalme8M: int = 0
    cajaEmpalme10M: int = 0
    cajaEmpalme12M: int = 0
    cajaEmpalme14M: int = 0
    cajaEmpalme15M: int = 0
    cajaEmpalme16M: int = 0
    cajaEmpalme20M: int = 0
    
    reserva8M: int = 0
    reserva10M: int = 0
    reserva12M: int = 0
    reserva14M: int = 0
    reserva15M: int = 0
    reserva16M: int = 0
    reserva20M: int = 0
    
    nap8M: int = 0
    nap10M: int = 0
    nap12M: int = 0
    nap14M: int = 0
    nap15M: int = 0
    nap16M: int = 0
    nap20M: int = 0
    
    # Pólizas
    vigenciaAmparoCumplimiento: Optional[str] = None
    inicioVigenciaCumplimiento: Optional[str] = None
    finVigenciaCumplimiento: Optional[str] = None
    valorAseguradoCumplimiento: float = 0
    numeroPolizaCumplimiento: Optional[str] = None
    fechaExpedicionPolizaCumplimiento: Optional[str] = None
    
    vigenciaAmparoRCE: Optional[str] = None
    inicioVigenciaRCE: Optional[str] = None
    finVigenciaRCE: Optional[str] = None
    valorAseguradoRCE: float = 0
    numeroPolizaRCE: Optional[str] = None
    fechaExpedicionPolizaRCE: Optional[str] = None
    
    class Config:
        from_attributes = True

class ContractCreate(ContractBase):
    ultimoContrato: bool = False
    enviadoDigitalmente: bool = False
    enviadoFisicamente: bool = False
    fisicamenteEnOficina: bool = False
    fechaPreLiquidacion: Optional[str] = None
    fechaRadFactura: Optional[str] = None
    
    # Infraestructura
    cable8M: int = 0
    cable10M: int = 0
    cable12M: int = 0
    cable14M: int = 0
    cable15M: int = 0
    cable16M: int = 0
    cable20M: int = 0
    
    cajaEmpalme8M: int = 0
    cajaEmpalme10M: int = 0
    cajaEmpalme12M: int = 0
    cajaEmpalme14M: int = 0
    cajaEmpalme15M: int = 0
    cajaEmpalme16M: int = 0
    cajaEmpalme20M: int = 0
    
    reserva8M: int = 0
    reserva10M: int = 0
    reserva12M: int = 0
    reserva14M: int = 0
    reserva15M: int = 0
    reserva16M: int = 0
    reserva20M: int = 0
    
    nap8M: int = 0
    nap10M: int = 0
    nap12M: int = 0
    nap14M: int = 0
    nap15M: int = 0
    nap16M: int = 0
    nap20M: int = 0
    
    # Pólizas
    vigenciaAmparoCumplimiento: Optional[str] = None
    inicioVigenciaCumplimiento: Optional[str] = None
    finVigenciaCumplimiento: Optional[str] = None
    valorAseguradoCumplimiento: float = 0
    numeroPolizaCumplimiento: Optional[str] = None
    fechaExpedicionPolizaCumplimiento: Optional[str] = None
    
    vigenciaAmparoRCE: Optional[str] = None
    inicioVigenciaRCE: Optional[str] = None
    finVigenciaRCE: Optional[str] = None
    valorAseguradoRCE: float = 0
    numeroPolizaRCE: Optional[str] = None
    fechaExpedicionPolizaRCE: Optional[str] = None

class AuditLog(BaseModel):
    id: int
    userId: int
    username: str
    action: str
    entityType: str
    entityId: int
    details: str
    timestamp: str

class AuditLogCreate(BaseModel):
    userId: int
    username: str
    action: str
    entityType: str
    entityId: int
    details: str

# Funciones auxiliares
def read_data():
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def write_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

def get_next_contract_id():
    data = read_data()
    if not data["contracts"]:
        return 1
    return max(contract["id"] for contract in data["contracts"]) + 1

def get_next_audit_log_id():
    data = read_data()
    if not data["audit_logs"]:
        return 1
    return max(log["id"] for log in data["audit_logs"]) + 1

def create_audit_log(log_create: AuditLogCreate):
    data = read_data()
    new_log = {
        "id": get_next_audit_log_id(),
        "userId": log_create.userId,
        "username": log_create.username,
        "action": log_create.action,
        "entityType": log_create.entityType,
        "entityId": log_create.entityId,
        "details": log_create.details,
        "timestamp": datetime.now().isoformat()
    }
    data["audit_logs"].append(new_log)
    write_data(data)
    return new_log

# Endpoints CRUD para contratos
@app.get("/api/contracts", response_model=List[Contract])
def get_contracts():
    data = read_data()
    return data["contracts"]

@app.get("/api/contracts/{contract_id}", response_model=Contract)
def get_contract(contract_id: int):
    data = read_data()
    for contract in data["contracts"]:
        if contract["id"] == contract_id:
            return contract
    raise HTTPException(status_code=404, detail="Contrato no encontrado")

@app.post("/api/contracts", response_model=Contract, status_code=status.HTTP_201_CREATED)
def create_contract(contract: ContractCreate):
    data = read_data()
    new_contract = contract.dict()
    new_contract["id"] = get_next_contract_id()
    
    # Calcular estado del contrato y proximidad a vencer
    try:
        fin_vigencia = datetime.fromisoformat(new_contract["finVigencia"].replace('Z', '+00:00'))
        now = datetime.now()
        if fin_vigencia < now:
            new_contract["estadoContrato"] = "Vencido"
        else:
            new_contract["estadoContrato"] = "Vigente"
            # Marcar como próximo a vencer si está a menos de 3 meses
            days_to_expiration = (fin_vigencia - now).days
            new_contract["proximoVencer"] = days_to_expiration <= 90
    except (ValueError, TypeError):
        # Si hay un error en el formato de fecha, usar valores predeterminados
        new_contract["estadoContrato"] = "Vigente"
        new_contract["proximoVencer"] = False
    
    data["contracts"].append(new_contract)
    write_data(data)
    
    # Registrar en el log de auditoría
    create_audit_log(AuditLogCreate(
        userId=1,  # ID de usuario predeterminado
        username="sistema",  # Usuario predeterminado
        action="CREATE",
        entityType="Contract",
        entityId=new_contract["id"],
        details=f"Creación de contrato: {new_contract['nombrePRST']}"
    ))
    
    return new_contract

@app.put("/api/contracts/{contract_id}", response_model=Contract)
def update_contract(contract_id: int, contract_update: ContractCreate):
    data = read_data()
    for i, contract in enumerate(data["contracts"]):
        if contract["id"] == contract_id:
            updated_contract = contract_update.dict()
            updated_contract["id"] = contract_id
            
            # Calcular estado del contrato y proximidad a vencer
            try:
                fin_vigencia = datetime.fromisoformat(updated_contract["finVigencia"].replace('Z', '+00:00'))
                now = datetime.now()
                if fin_vigencia < now:
                    updated_contract["estadoContrato"] = "Vencido"
                else:
                    updated_contract["estadoContrato"] = "Vigente"
                    # Marcar como próximo a vencer si está a menos de 3 meses
                    days_to_expiration = (fin_vigencia - now).days
                    updated_contract["proximoVencer"] = days_to_expiration <= 90
            except (ValueError, TypeError):
                # Si hay un error en el formato de fecha, mantener valores existentes
                updated_contract["estadoContrato"] = contract.get("estadoContrato", "Vigente")
                updated_contract["proximoVencer"] = contract.get("proximoVencer", False)
            
            data["contracts"][i] = updated_contract
            write_data(data)
            
            # Registrar en el log de auditoría
            create_audit_log(AuditLogCreate(
                userId=1,  # ID de usuario predeterminado
                username="sistema",  # Usuario predeterminado
                action="UPDATE",
                entityType="Contract",
                entityId=contract_id,
                details=f"Actualización de contrato: {updated_contract['nombrePRST']}"
            ))
            
            return updated_contract
    raise HTTPException(status_code=404, detail="Contrato no encontrado")

@app.delete("/api/contracts/{contract_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_contract(contract_id: int):
    data = read_data()
    for i, contract in enumerate(data["contracts"]):
        if contract["id"] == contract_id:
            deleted_contract = data["contracts"].pop(i)
            write_data(data)
            
            # Registrar en el log de auditoría
            create_audit_log(AuditLogCreate(
                userId=1,  # ID de usuario predeterminado
                username="sistema",  # Usuario predeterminado
                action="DELETE",
                entityType="Contract",
                entityId=contract_id,
                details=f"Eliminación de contrato: {deleted_contract['nombrePRST']}"
            ))
            
            return
    raise HTTPException(status_code=404, detail="Contrato no encontrado")

# Endpoints para logs de auditoría
@app.get("/api/audit-logs", response_model=List[AuditLog])
def get_audit_logs():
    data = read_data()
    return data["audit_logs"]

@app.get("/api/audit-logs/{log_id}", response_model=AuditLog)
def get_audit_log(log_id: int):
    data = read_data()
    for log in data["audit_logs"]:
        if log["id"] == log_id:
            return log
    raise HTTPException(status_code=404, detail="Log de auditoría no encontrado")

# Endpoint para verificar que la API está funcionando
@app.get("/api/health")
def health_check():
    return {"status": "ok", "message": "API funcionando correctamente"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

