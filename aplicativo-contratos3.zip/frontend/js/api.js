// Configuración de la API
const API_BASE_URL = "http://localhost:8000/api"

// Función para manejar errores de la API
function handleApiError(error) {
  console.error("Error en la API:", error)
  if (error.response) {
    // El servidor respondió con un código de estado fuera del rango 2xx
    console.error("Respuesta del servidor:", error.response.data)
    return Promise.reject(error.response.data)
  } else if (error.request) {
    // La solicitud se hizo pero no se recibió respuesta
    console.error("No se recibió respuesta del servidor")
    return Promise.reject({
      message: "Error de conexión: No se pudo conectar con el servidor",
    })
  } else {
    // Algo sucedió al configurar la solicitud que desencadenó un error
    console.error("Error:", error.message)
    return Promise.reject({
      message: "Error: " + error.message,
    })
  }
}

// Funciones para interactuar con la API de contratos
async function fetchContracts() {
  try {
    const response = await fetch(`${API_BASE_URL}/contracts`)
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.json()
  } catch (error) {
    return handleApiError(error)
  }
}

async function fetchContractById(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/contracts/${id}`)
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.json()
  } catch (error) {
    return handleApiError(error)
  }
}

async function createContract(contractData, username) {
  try {
    const response = await fetch(`${API_BASE_URL}/contracts`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(contractData),
    })

    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    return handleApiError(error)
  }
}

async function updateContract(id, contractData, username) {
  try {
    const response = await fetch(`${API_BASE_URL}/contracts/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(contractData),
    })

    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    return handleApiError(error)
  }
}

async function deleteContract(id, username) {
  try {
    const response = await fetch(`${API_BASE_URL}/contracts/${id}`, {
      method: "DELETE",
    })

    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }

    return true
  } catch (error) {
    return handleApiError(error)
  }
}

// Funciones para interactuar con la API de logs de auditoría
async function fetchAuditLogs() {
  try {
    const response = await fetch(`${API_BASE_URL}/audit-logs`)
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.json()
  } catch (error) {
    return handleApiError(error)
  }
}

// Función para verificar el estado de la API
async function checkApiHealth() {
  try {
    const response = await fetch(`${API_BASE_URL}/health`)
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.json()
  } catch (error) {
    return handleApiError(error)
  }
}

// Exportar las funciones para su uso en otros archivos
export {
  fetchContracts,
  fetchContractById,
  createContract,
  updateContract,
  deleteContract,
  fetchAuditLogs,
  checkApiHealth,
}

