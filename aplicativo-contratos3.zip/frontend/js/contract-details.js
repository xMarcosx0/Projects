// Import necessary functions and variables from auth.js and config.js
import { isAuthenticated, getToken } from "./auth.js"
import { API_BASE_URL } from "./config.js"

// Funcionalidad para la vista de detalles de contrato
document.addEventListener("DOMContentLoaded", () => {
  // Verificar autenticación
  if (!isAuthenticated()) {
    window.location.href = "index.html"
    return
  }

  // Obtener ID del contrato de la URL
  const urlParams = new URLSearchParams(window.location.search)
  const contractId = urlParams.get("id")

  if (!contractId) {
    window.location.href = "dashboard.html"
    return
  }

  // Referencias a elementos del DOM
  const contractDetails = document.getElementById("contract-details")
  const editButton = document.getElementById("edit-contract")
  const deleteButton = document.getElementById("delete-contract")
  const backButton = document.getElementById("back-to-dashboard")
  const tabButtons = document.querySelectorAll(".tab-button")
  const tabContents = document.querySelectorAll(".tab-content")

  // Configurar navegación por pestañas
  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      // Remover clase activa de todos los botones y contenidos
      tabButtons.forEach((btn) => btn.classList.remove("active"))
      tabContents.forEach((content) => content.classList.remove("active"))

      // Agregar clase activa al botón clickeado y su contenido correspondiente
      button.classList.add("active")
      const tabId = button.getAttribute("data-tab")
      document.getElementById(tabId).classList.add("active")
    })
  })

  // Cargar datos del contrato
  loadContractDetails(contractId)

  // Configurar botones de acción
  if (editButton) {
    editButton.addEventListener("click", () => {
      window.location.href = `contract-form.html?id=${contractId}`
    })
  }

  if (deleteButton) {
    deleteButton.addEventListener("click", () => {
      if (confirm("¿Está seguro de que desea eliminar este contrato? Esta acción no se puede deshacer.")) {
        deleteContract(contractId)
      }
    })
  }

  if (backButton) {
    backButton.addEventListener("click", () => {
      window.location.href = "dashboard.html"
    })
  }
})

// Cargar detalles del contrato
function loadContractDetails(contractId) {
  fetch(`${API_BASE_URL}/contracts/${contractId}`, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Error al cargar los detalles del contrato")
      }
      return response.json()
    })
    .then((data) => {
      displayContractDetails(data)
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("Error al cargar los detalles del contrato", "error")
    })
}

// Mostrar detalles del contrato en la interfaz
function displayContractDetails(contract) {
  // Sección 1: Información Principal
  document.getElementById("numero_contrato_value").textContent = contract.numero_contrato || "N/A"
  document.getElementById("objeto_value").textContent = contract.objeto || "N/A"
  document.getElementById("tipo_contrato_value").textContent = contract.tipo_contrato || "N/A"
  document.getElementById("contratista_value").textContent = contract.contratista || "N/A"
  document.getElementById("nit_value").textContent = contract.nit || "N/A"
  document.getElementById("fecha_inicio_value").textContent = formatDate(contract.fecha_inicio) || "N/A"
  document.getElementById("fecha_terminacion_value").textContent = formatDate(contract.fecha_terminacion) || "N/A"
  document.getElementById("plazo_value").textContent = contract.plazo || "N/A"

  // Sección 2: Infraestructura
  document.getElementById("departamento_value").textContent = contract.departamento || "N/A"
  document.getElementById("municipio_value").textContent = contract.municipio || "N/A"
  document.getElementById("sector_value").textContent = contract.sector || "N/A"
  document.getElementById("tipo_via_value").textContent = contract.tipo_via || "N/A"
  document.getElementById("codigo_via_value").textContent = contract.codigo_via || "N/A"
  document.getElementById("nombre_via_value").textContent = contract.nombre_via || "N/A"
  document.getElementById("pr_inicial_value").textContent = contract.pr_inicial || "N/A"
  document.getElementById("pr_final_value").textContent = contract.pr_final || "N/A"
  document.getElementById("longitud_value").textContent = contract.longitud ? `${contract.longitud} km` : "N/A"

  // Sección 3: Información Suministrada por adm
  document.getElementById("valor_inicial_value").textContent = formatCurrency(contract.valor_inicial) || "N/A"
  document.getElementById("valor_adiciones_value").textContent = formatCurrency(contract.valor_adiciones) || "N/A"
  document.getElementById("valor_total_value").textContent = formatCurrency(contract.valor_total) || "N/A"
  document.getElementById("valor_ejecutado_value").textContent = formatCurrency(contract.valor_ejecutado) || "N/A"
  document.getElementById("porcentaje_ejecucion_value").textContent = contract.porcentaje_ejecucion
    ? `${contract.porcentaje_ejecucion}%`
    : "N/A"
  document.getElementById("estado_value").textContent = contract.estado || "N/A"

  // Sección 4: Información Tomada de Contrato
  document.getElementById("supervisor_value").textContent = contract.supervisor || "N/A"
  document.getElementById("interventor_value").textContent = contract.interventor || "N/A"
  document.getElementById("numero_contrato_interventoria_value").textContent =
    contract.numero_contrato_interventoria || "N/A"
  document.getElementById("observaciones_value").textContent = contract.observaciones || "N/A"

  // Sección 5: Información de Póliza
  document.getElementById("numero_poliza_value").textContent = contract.numero_poliza || "N/A"
  document.getElementById("aseguradora_value").textContent = contract.aseguradora || "N/A"
  document.getElementById("fecha_expedicion_value").textContent = formatDate(contract.fecha_expedicion) || "N/A"
  document.getElementById("fecha_vencimiento_value").textContent = formatDate(contract.fecha_vencimiento) || "N/A"
  document.getElementById("valor_asegurado_value").textContent = formatCurrency(contract.valor_asegurado) || "N/A"
}

// Eliminar contrato
function deleteContract(contractId) {
  fetch(`${API_BASE_URL}/contracts/${contractId}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Error al eliminar el contrato")
      }
      return response.json()
    })
    .then((data) => {
      showNotification("Contrato eliminado exitosamente", "success")
      setTimeout(() => {
        window.location.href = "dashboard.html"
      }, 1500)
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("Error al eliminar el contrato", "error")
    })
}

// Formatear fecha
function formatDate(dateString) {
  if (!dateString) return ""

  const date = new Date(dateString)
  if (isNaN(date.getTime())) return dateString

  return date.toLocaleDateString("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })
}

// Formatear moneda
function formatCurrency(value) {
  if (!value) return ""

  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

// Mostrar notificación
function showNotification(message, type) {
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.textContent = message

  document.body.appendChild(notification)

  setTimeout(() => {
    notification.classList.add("show")
  }, 10)

  setTimeout(() => {
    notification.classList.remove("show")
    setTimeout(() => {
      document.body.removeChild(notification)
    }, 300)
  }, 3000)
}

