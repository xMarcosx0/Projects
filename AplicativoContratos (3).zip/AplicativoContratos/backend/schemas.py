from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

# Esquemas para Token
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None
    role: Optional[str] = None

# Esquemas para Usuario
class UserBase(BaseModel):
    username: str
    role: str

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

# Esquemas para Contrato
class ContractBase(BaseModel):
    nombrePRST: str
    nombreCorto: str
    responsable: str
    clasificacion: str
    arreglo: Optional[str] = None
    estado: str
    
    # Información administrativa
    ultimoContrato: bool = False
    enviadoDigitalmente: bool = False
    enviadoFisicamente: bool = False
    fisicamenteEnOficina: bool = False
    fechaPreLiquidacion: Optional[str] = None
    fechaRadFactura: Optional[str] = None
    
    # Información de infraestructura - Cable
    cable8M: int = 0
    cable10M: int = 0
    cable12M: int = 0
    cable14M: int = 0
    cable15M: int = 0
    cable16M: int = 0
    cable20M: int = 0
    
    # Información de infraestructura - Caja de Empalme
    cajaEmpalme8M: int = 0
    cajaEmpalme10M: int = 0
    cajaEmpalme12M: int = 0
    cajaEmpalme14M: int = 0
    cajaEmpalme15M: int = 0
    cajaEmpalme16M: int = 0
    cajaEmpalme20M: int = 0
    
    # Información de infraestructura - Reserva
    reserva8M: int = 0
    reserva10M: int = 0
    reserva12M: int = 0
    reserva14M: int = 0
    reserva15M: int = 0
    reserva16M: int = 0
    reserva20M: int = 0
    
    # Información de infraestructura - NAP
    nap8M: int = 0
    nap10M: int = 0
    nap12M: int = 0
    nap14M: int = 0
    nap15M: int = 0
    nap16M: int = 0
    nap20M: int = 0
    
    # Información contractual
    valorContrato: float = 0
    duracionAnios: int = 1
    inicioVigencia: str
    finVigencia: str
    estadoContrato: str = "Vigente"
    proximoVencer: bool = False
    garantiasRequeridas: Optional[str] = None
    
    # Información de póliza de cumplimiento
    vigenciaAmparoCumplimiento: Optional[str] = None
    inicioVigenciaCumplimiento: Optional[str] = None
    finVigenciaCumplimiento: Optional[str] = None
    valorAseguradoCumplimiento: float = 0
    valorAseguradoTextoCumplimiento: Optional[str] = None
    numeroPolizaCumplimiento: Optional[str] = None
    inicioAmparoCumplimiento: Optional[str] = None
    finAmparoCumplimiento: Optional[str] = None
    fechaExpedicionPolizaCumplimiento: Optional[str] = None
    tomadorCumplimiento: Optional[str] = None
    aseguradoBeneficiarioCumplimiento: Optional[str] = None
    fechaPolizaConforme: Optional[str] = None
    valorAseguradoConforme: Optional[str] = None
    
    # Información de póliza de RCE
    vigenciaAmparoRCE: Optional[str] = None
    inicioVigenciaRCE: Optional[str] = None
    finVigenciaRCE: Optional[str] = None
    valorAseguradoRCE: float = 0
    valorAseguradoTextoRCE: Optional[str] = None
    numeroPolizaRCE: Optional[str] = None
    inicioAmparoRCE: Optional[str] = None
    finAmparoRCE: Optional[str] = None
    fechaExpedicionPolizaRCE: Optional[str] = None
    tomadorRCE: Optional[str] = None
    aseguradoBeneficiarioRCE: Optional[str] = None
    fechaPolizaConformeRCE: Optional[str] = None
    valorAseguradoConformeRCE: Optional[str] = None

class ContractCreate(ContractBase):
    pass

class ContractUpdate(ContractBase):
    pass

class ContractResponse(ContractBase):
    id: int
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str] = None
    updated_by: Optional[str] = None

    class Config:
        orm_mode = True

# Esquemas para Log de Auditoría
class AuditLogBase(BaseModel):
    user_id: int
    username: str
    action: str
    entity_type: str
    entity_id: int
    details: Optional[str] = None

class AuditLogCreate(AuditLogBase):
    pass

class AuditLogResponse(AuditLogBase):
    id: int
    timestamp: datetime

    class Config:
        orm_mode = True