from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True)
    password = Column(String(100))
    role = Column(String(20))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    audit_logs = relationship("AuditLog", back_populates="user")

class Contract(Base):
    __tablename__ = "contracts"
    
    id = Column(Integer, primary_key=True, index=True)
    nombrePRST = Column(String(100), index=True)
    nombreCorto = Column(String(50), index=True)
    responsable = Column(String(100), index=True)
    clasificacion = Column(String(100))
    arreglo = Column(String(100), nullable=True)
    estado = Column(String(50))
    
    # Información administrativa
    ultimoContrato = Column(Boolean, default=False)
    enviadoDigitalmente = Column(Boolean, default=False)
    enviadoFisicamente = Column(Boolean, default=False)
    fisicamenteEnOficina = Column(Boolean, default=False)
    fechaPreLiquidacion = Column(String(50), nullable=True)
    fechaRadFactura = Column(String(50), nullable=True)
    
    # Información de infraestructura - Cable
    cable8M = Column(Integer, default=0)
    cable10M = Column(Integer, default=0)
    cable12M = Column(Integer, default=0)
    cable14M = Column(Integer, default=0)
    cable15M = Column(Integer, default=0)
    cable16M = Column(Integer, default=0)
    cable20M = Column(Integer, default=0)
    
    # Información de infraestructura - Caja de Empalme
    cajaEmpalme8M = Column(Integer, default=0)
    cajaEmpalme10M = Column(Integer, default=0)
    cajaEmpalme12M = Column(Integer, default=0)
    cajaEmpalme14M = Column(Integer, default=0)
    cajaEmpalme15M = Column(Integer, default=0)
    cajaEmpalme16M = Column(Integer, default=0)
    cajaEmpalme20M = Column(Integer, default=0)
    
    # Información de infraestructura - Reserva
    reserva8M = Column(Integer, default=0)
    reserva10M = Column(Integer, default=0)
    reserva12M = Column(Integer, default=0)
    reserva14M = Column(Integer, default=0)
    reserva15M = Column(Integer, default=0)
    reserva16M = Column(Integer, default=0)
    reserva20M = Column(Integer, default=0)
    
    # Información de infraestructura - NAP
    nap8M = Column(Integer, default=0)
    nap10M = Column(Integer, default=0)
    nap12M = Column(Integer, default=0)
    nap14M = Column(Integer, default=0)
    nap15M = Column(Integer, default=0)
    nap16M = Column(Integer, default=0)
    nap20M = Column(Integer, default=0)
    
    # Información contractual
    valorContrato = Column(Float, default=0)
    duracionAnios = Column(Integer, default=1)
    inicioVigencia = Column(String(50))
    finVigencia = Column(String(50))
    estadoContrato = Column(String(50), default="Vigente")
    proximoVencer = Column(Boolean, default=False)
    garantiasRequeridas = Column(String(100), nullable=True)
    
    # Información de póliza de cumplimiento
    vigenciaAmparoCumplimiento = Column(String(100), nullable=True)
    inicioVigenciaCumplimiento = Column(String(50), nullable=True)
    finVigenciaCumplimiento = Column(String(50), nullable=True)
    valorAseguradoCumplimiento = Column(Float, default=0)
    valorAseguradoTextoCumplimiento = Column(String(200), nullable=True)
    numeroPolizaCumplimiento = Column(String(50), nullable=True)
    inicioAmparoCumplimiento = Column(String(50), nullable=True)
    finAmparoCumplimiento = Column(String(50), nullable=True)
    fechaExpedicionPolizaCumplimiento = Column(String(50), nullable=True)
    tomadorCumplimiento = Column(String(100), nullable=True)
    aseguradoBeneficiarioCumplimiento = Column(String(100), nullable=True)
    fechaPolizaConforme = Column(String(50), nullable=True)
    valorAseguradoConforme = Column(String(50), nullable=True)
    
    # Información de póliza de RCE
    vigenciaAmparoRCE = Column(String(100), nullable=True)
    inicioVigenciaRCE = Column(String(50), nullable=True)
    finVigenciaRCE = Column(String(50), nullable=True)
    valorAseguradoRCE = Column(Float, default=0)
    valorAseguradoTextoRCE = Column(String(200), nullable=True)
    numeroPolizaRCE = Column(String(50), nullable=True)
    inicioAmparoRCE = Column(String(50), nullable=True)
    finAmparoRCE = Column(String(50), nullable=True)
    fechaExpedicionPolizaRCE = Column(String(50), nullable=True)
    tomadorRCE = Column(String(100), nullable=True)
    aseguradoBeneficiarioRCE = Column(String(100), nullable=True)
    fechaPolizaConformeRCE = Column(String(50), nullable=True)
    valorAseguradoConformeRCE = Column(String(50), nullable=True)
    
    # Metadatos
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String(50), nullable=True)
    updated_by = Column(String(50), nullable=True)
    
    audit_logs = relationship("AuditLog", back_populates="contract")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    username = Column(String(50))
    action = Column(String(20))  # CREATE, UPDATE, DELETE, VIEW
    entity_type = Column(String(50))
    entity_id = Column(Integer)
    details = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="audit_logs")
    contract = relationship("Contract", back_populates="audit_logs")