from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional
import uvicorn
from models import Contract, AuditLog, User, Base
from database import SessionLocal, engine
from schemas import ContractCreate, ContractUpdate, ContractResponse, AuditLogResponse, UserCreate, Token
from auth import create_access_token, get_current_user, get_password_hash, verify_password
from datetime import timedelta

# Crear tablas en la base de datos
Base.metadata.create_all(bind=engine)

app = FastAPI(title="API de Gestión de Contratos PRST")

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # En producción, especificar los orígenes permitidos
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependencia para obtener la sesión de la base de datos
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Rutas para autenticación
@app.post("/token", response_model=Token)
def login_for_access_token(username: str, password: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == username).first()
    if not user or not verify_password(password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=30)
    access_token = create_access_token(
        data={"sub": user.username, "role": user.role}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

# Rutas para contratos
@app.get("/contracts", response_model=List[ContractResponse])
def get_contracts(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    contracts = db.query(Contract).all()
    return contracts

@app.get("/contracts/{contract_id}", response_model=ContractResponse)
def get_contract(contract_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    contract = db.query(Contract).filter(Contract.id == contract_id).first()
    if contract is None:
        raise HTTPException(status_code=404, detail="Contrato no encontrado")
    
    # Registrar en el log de auditoría
    audit_log = AuditLog(
        user_id=current_user.id,
        username=current_user.username,
        action="VIEW",
        entity_type="Contract",
        entity_id=contract_id,
        details="Visualización de detalles de contrato"
    )
    db.add(audit_log)
    db.commit()
    
    return contract

@app.post("/contracts", response_model=ContractResponse)
def create_contract(contract: ContractCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    db_contract = Contract(**contract.dict(), created_by=current_user.username)
    db.add(db_contract)
    db.commit()
    db.refresh(db_contract)
    
    # Registrar en el log de auditoría
    audit_log = AuditLog(
        user_id=current_user.id,
        username=current_user.username,
        action="CREATE",
        entity_type="Contract",
        entity_id=db_contract.id,
        details="Creación de nuevo contrato"
    )
    db.add(audit_log)
    db.commit()
    
    return db_contract

@app.put("/contracts/{contract_id}", response_model=ContractResponse)
def update_contract(contract_id: int, contract: ContractUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    db_contract = db.query(Contract).filter(Contract.id == contract_id).first()
    if db_contract is None:
        raise HTTPException(status_code=404, detail="Contrato no encontrado")
    
    # Actualizar campos
    for key, value in contract.dict(exclude_unset=True).items():
        setattr(db_contract, key, value)
    
    db_contract.updated_by = current_user.username
    db.commit()
    db.refresh(db_contract)
    
    # Registrar en el log de auditoría
    audit_log = AuditLog(
        user_id=current_user.id,
        username=current_user.username,
        action="UPDATE",
        entity_type="Contract",
        entity_id=contract_id,
        details="Actualización de contrato"
    )
    db.add(audit_log)
    db.commit()
    
    return db_contract

@app.delete("/contracts/{contract_id}", response_model=dict)
def delete_contract(contract_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="No tiene permisos para eliminar contratos")
    
    db_contract = db.query(Contract).filter(Contract.id == contract_id).first()
    if db_contract is None:
        raise HTTPException(status_code=404, detail="Contrato no encontrado")
    
    db.delete(db_contract)
    db.commit()
    
    # Registrar en el log de auditoría
    audit_log = AuditLog(
        user_id=current_user.id,
        username=current_user.username,
        action="DELETE",
        entity_type="Contract",
        entity_id=contract_id,
        details="Eliminación de contrato"
    )
    db.add(audit_log)
    db.commit()
    
    return {"message": "Contrato eliminado correctamente"}

# Rutas para logs de auditoría
@app.get("/audit-logs", response_model=List[AuditLogResponse])
def get_audit_logs(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="No tiene permisos para ver logs de auditoría")
    
    audit_logs = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).all()
    return audit_logs

# Iniciar el servidor si se ejecuta directamente
if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)