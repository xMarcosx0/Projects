// Datos de ejemplo para simular una API
const mockContracts = [
  {
    id: 1,
    nombrePRST: "AIRTEK CARRIER SERVICES S.A.S.",
    nombreCorto: "AIRTEK CARRIER SERVICES",
    responsable: "Maria Isabel Jimenez Beleño",
    clasificacion: "Tipo 1: Anterior al 07 de Julio",
    arreglo: "Arreglo 1",
    estado: "Contratado",
    ultimoContrato: true,
    enviadoDigitalmente: true,
    enviadoFisicamente: true,
    fisicamenteEnOficina: true,
    fechaPreLiquidacion: "2023-06-15",
    fechaRadFactura: "15",

    // Información de infraestructura - Cable
    cable8M: 0,
    cable10M: 93,
    cable12M: 653,
    cable14M: 0,
    cable15M: 0,
    cable16M: 0,
    cable20M: 0,

    // Información de infraestructura - Caja de Empalme
    cajaEmpalme8M: 0,
    cajaEmpalme10M: 0,
    cajaEmpalme12M: 0,
    cajaEmpalme14M: 0,
    cajaEmpalme15M: 0,
    cajaEmpalme16M: 0,
    cajaEmpalme20M: 0,

    // Información de infraestructura - Reserva
    reserva8M: 0,
    reserva10M: 0,
    reserva12M: 0,
    reserva14M: 0,
    reserva15M: 0,
    reserva16M: 0,
    reserva20M: 0,

    // Información de infraestructura - NAP
    nap8M: 0,
    nap10M: 0,
    nap12M: 0,
    nap14M: 0,
    nap15M: 0,
    nap16M: 0,
    nap20M: 0,

    // Información contractual
    valorContrato: 54482843,
    duracionAnios: 2,
    inicioVigencia: "2023-03-31",
    finVigencia: "2025-03-31",
    estadoContrato: "Vigente",
    proximoVencer: true,
    garantiasRequeridas: "Poliza de Cumplimiento",

    // Información de póliza de cumplimiento
    vigenciaAmparoCumplimiento: "Igual a Duración de Contrato + 6 Meses",
    inicioVigenciaCumplimiento: "2023-03-31",
    finVigenciaCumplimiento: "2025-09-30",
    valorAseguradoCumplimiento: 10896569,
    valorAseguradoTextoCumplimiento: "Diez millones ochocientos noventa y seis mil quinientos sesenta y nueve pesos",
    numeroPolizaCumplimiento: "3018203",
    inicioAmparoCumplimiento: "2023-05-19",
    finAmparoCumplimiento: "2025-11-19",
    fechaExpedicionPolizaCumplimiento: "2023-07-05",
    tomadorCumplimiento: "AIRTEK CARRIER SERVICES S.A.S.",
    aseguradoBeneficiarioCumplimiento: "AIR-E S.A.S. E.S.P.",
    fechaPolizaConforme: "Correcto",
    valorAseguradoConforme: "Correcto",

    // Información de póliza de RCE
    vigenciaAmparoRCE: "Igual a Duración de Contrato + 12 Meses",
    inicioVigenciaRCE: "2023-03-31",
    finVigenciaRCE: "2026-03-31",
    valorAseguradoRCE: 216000000,
    valorAseguradoTextoRCE: "Doscientos dieciséis millones de pesos",
    numeroPolizaRCE: "1013289",
    inicioAmparoRCE: "2023-05-19",
    finAmparoRCE: "2026-05-19",
    fechaExpedicionPolizaRCE: "2023-07-19",
    tomadorRCE: "AIRTEK CARRIER SERVICES S.A.S.",
    aseguradoBeneficiarioRCE: "Terceros Afectados",
    fechaPolizaConformeRCE: "Correcto",
    valorAseguradoConformeRCE: "Correcto",
  },
  {
    id: 2,
    nombrePRST: "ALIADOS EN COMUNICACION NET",
    nombreCorto: "TOTAL CONEXION",
    responsable: "Maria Jose Blanco Ochoa",
    clasificacion: "Tipo 2: Posterior al 07 de Julio - Ufinet",
    arreglo: "Arreglo 2",
    estado: "En Renovación",
    ultimoContrato: true,
    enviadoDigitalmente: true,
    enviadoFisicamente: true,
    fisicamenteEnOficina: true,
    fechaPreLiquidacion: "2024-01-20",
    fechaRadFactura: "20-25",

    // Información de infraestructura - Cable
    cable8M: 0,
    cable10M: 405,
    cable12M: 689,
    cable14M: 5,
    cable15M: 0,
    cable16M: 0,
    cable20M: 0,

    // Información de infraestructura - Caja de Empalme
    cajaEmpalme8M: 0,
    cajaEmpalme10M: 44,
    cajaEmpalme12M: 88,
    cajaEmpalme14M: 4,
    cajaEmpalme15M: 0,
    cajaEmpalme16M: 0,
    cajaEmpalme20M: 0,

    // Información de infraestructura - Reserva
    reserva8M: 0,
    reserva10M: 101,
    reserva12M: 113,
    reserva14M: 2,
    reserva15M: 0,
    reserva16M: 0,
    reserva20M: 0,

    // Información de infraestructura - NAP
    nap8M: 0,
    nap10M: 61,
    nap12M: 48,
    nap14M: 0,
    nap15M: 0,
    nap16M: 0,
    nap20M: 0,

    // Información contractual
    valorContrato: 132928487,
    duracionAnios: 2,
    inicioVigencia: "2024-02-11",
    finVigencia: "2026-02-11",
    estadoContrato: "Vigente",
    proximoVencer: false,
    garantiasRequeridas: "Poliza de RCE",

    // Información de póliza de cumplimiento
    vigenciaAmparoCumplimiento: "Igual a Duración de Contrato + 2 Meses",
    inicioVigenciaCumplimiento: "2024-02-11",
    finVigenciaCumplimiento: "2027-02-11",
    valorAseguradoCumplimiento: 26585697,
    valorAseguradoTextoCumplimiento:
      "Veintiséis millones quinientos ochenta y cinco mil seiscientos noventa y siete pesos",
    numeroPolizaCumplimiento: "4025789",
    inicioAmparoCumplimiento: "2024-02-15",
    finAmparoCumplimiento: "2027-02-15",
    fechaExpedicionPolizaCumplimiento: "2024-02-20",
    tomadorCumplimiento: "ALIADOS EN COMUNICACION NET",
    aseguradoBeneficiarioCumplimiento: "AIR-E S.A.S. E.S.P.",
    fechaPolizaConforme: "Correcto",
    valorAseguradoConforme: "Correcto",

    // Información de póliza de RCE
    vigenciaAmparoRCE: "Igual a Duración de Contrato + 2 Meses",
    inicioVigenciaRCE: "2024-02-11",
    finVigenciaRCE: "2027-02-11",
    valorAseguradoRCE: 390000000,
    valorAseguradoTextoRCE: "Trescientos noventa millones de pesos",
    numeroPolizaRCE: "5036987",
    inicioAmparoRCE: "2024-02-15",
    finAmparoRCE: "2027-02-15",
    fechaExpedicionPolizaRCE: "2024-02-20",
    tomadorRCE: "ALIADOS EN COMUNICACION NET",
    aseguradoBeneficiarioRCE: "Terceros Afectados",
    fechaPolizaConformeRCE: "Correcto",
    valorAseguradoConformeRCE: "Correcto",
  },
  {
    id: 3,
    nombrePRST: "COMUNICACION CELULAR COMCEL S.A",
    nombreCorto: "CLARO",
    responsable: "Claudia Patricia Villegas Duque",
    clasificacion: "Tipo 3: Posterior al 07 de Julio - Air-e",
    arreglo: "Arreglo 3",
    estado: "Contratado",
    ultimoContrato: true,
    enviadoDigitalmente: true,
    enviadoFisicamente: true,
    fisicamenteEnOficina: true,
    fechaPreLiquidacion: "2023-10-10",
    fechaRadFactura: "10-15",

    // Información de infraestructura - Cable
    cable8M: 7129,
    cable10M: 21700,
    cable12M: 63690,
    cable14M: 1682,
    cable15M: 0,
    cable16M: 42,
    cable20M: 0,

    // Información de infraestructura - Caja de Empalme
    cajaEmpalme8M: 0,
    cajaEmpalme10M: 0,
    cajaEmpalme12M: 0,
    cajaEmpalme14M: 0,
    cajaEmpalme15M: 0,
    cajaEmpalme16M: 0,
    cajaEmpalme20M: 0,

    // Información de infraestructura - Reserva
    reserva8M: 0,
    reserva10M: 0,
    reserva12M: 0,
    reserva14M: 0,
    reserva15M: 0,
    reserva16M: 0,
    reserva20M: 0,

    // Información de infraestructura - NAP
    nap8M: 0,
    nap10M: 0,
    nap12M: 0,
    nap14M: 0,
    nap15M: 0,
    nap16M: 0,
    nap20M: 0,

    // Información contractual
    valorContrato: 15839242632,
    duracionAnios: 5,
    inicioVigencia: "2023-10-19",
    finVigencia: "2028-10-19",
    estadoContrato: "Vigente",
    proximoVencer: false,
    garantiasRequeridas: "Poliza de Cumplimiento",

    // Información de póliza de cumplimiento
    vigenciaAmparoCumplimiento: "Igual a Duración de Contrato + 2 Meses",
    inicioVigenciaCumplimiento: "2023-10-19",
    finVigenciaCumplimiento: "2028-12-19",
    valorAseguradoCumplimiento: 3167848526,
    valorAseguradoTextoCumplimiento:
      "Tres mil ciento sesenta y siete millones ochocientos cuarenta y ocho mil quinientos veintiséis pesos",
    numeroPolizaCumplimiento: "1000602836801",
    inicioAmparoCumplimiento: "2023-11-23",
    finAmparoCumplimiento: "2029-01-23",
    fechaExpedicionPolizaCumplimiento: "2023-11-28",
    tomadorCumplimiento: "COMUNICACION CELULAR COMCEL S.A",
    aseguradoBeneficiarioCumplimiento: "AIR-E S.A.S. E.S.P.",
    fechaPolizaConforme: "Correcto",
    valorAseguradoConforme: "Correcto",

    // Información de póliza de RCE
    vigenciaAmparoRCE: "Igual a Duración de Contrato + 2 Meses",
    inicioVigenciaRCE: "2023-10-19",
    finVigenciaRCE: "2028-12-19",
    valorAseguradoRCE: 348000000,
    valorAseguradoTextoRCE: "Trescientos cuarenta y ocho millones de pesos",
    numeroPolizaRCE: "1000101194101",
    inicioAmparoRCE: "2023-11-23",
    finAmparoRCE: "2029-01-23",
    fechaExpedicionPolizaRCE: "2023-11-28",
    tomadorRCE: "COMUNICACION CELULAR COMCEL S.A",
    aseguradoBeneficiarioRCE: "Terceros Afectados",
    fechaPolizaConformeRCE: "Correcto",
    valorAseguradoConformeRCE: "Correcto",
  },
]

// Datos de ejemplo para logs de auditoría
const mockAuditLogs = [
  {
    id: 1,
    userId: 1,
    username: "admin",
    action: "UPDATE",
    entityType: "Contract",
    entityId: 1,
    details: "Actualización de estado de contrato",
    timestamp: "2024-03-15T14:30:00Z",
  },
  {
    id: 2,
    userId: 2,
    username: "usuario",
    action: "VIEW",
    entityType: "Contract",
    entityId: 1,
    details: "Visualización de detalles de contrato",
    timestamp: "2024-03-16T10:15:00Z",
  },
  {
    id: 3,
    userId: 1,
    username: "admin",
    action: "CREATE",
    entityType: "Contract",
    entityId: 3,
    details: "Creación de nuevo contrato",
    timestamp: "2024-03-14T09:45:00Z",
  },
  {
    id: 4,
    userId: 1,
    username: "admin",
    action: "DELETE",
    entityType: "Contract",
    entityId: 4,
    details: "Eliminación de contrato",
    timestamp: "2024-03-13T16:20:00Z",
  },
]

// Función para simular la obtención del nombre de usuario (reemplazar con la lógica real)
function getUserName() {
  // Aquí deberías tener la lógica para obtener el nombre de usuario real
  // Por ejemplo, desde una cookie, localStorage, o un contexto de autenticación
  return "admin" // Valor por defecto para simular
}

// Función para obtener todos los contratos
function fetchContracts() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([...mockContracts])
    }, 800)
  })
}

// Función para obtener un contrato por ID
function fetchContractById(id) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const contract = mockContracts.find((c) => c.id === id)
      if (contract) {
        resolve({ ...contract })
      } else {
        reject(new Error("Contrato no encontrado"))
      }
    }, 500)
  })
}

// Función para actualizar un contrato
function updateContract(id, updatedContract, username) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const index = mockContracts.findIndex((c) => c.id === id)
      if (index !== -1) {
        // Actualizar el contrato
        const contract = {
          ...updatedContract,
          modificadoPor: username,
          fechaModificacion: new Date().toISOString(),
        }
        mockContracts[index] = contract

        // Registrar en el log de auditoría
        const auditLog = {
          id: mockAuditLogs.length + 1,
          userId: getUserName() === "admin" ? 1 : 2,
          username: username,
          action: "UPDATE",
          entityType: "Contract",
          entityId: id,
          details: "Actualización de contrato",
          timestamp: new Date().toISOString(),
        }
        mockAuditLogs.push(auditLog)

        resolve({ ...contract })
      }
    }, 800)
  })
}

// Función para eliminar un contrato
function deleteContract(id, username) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const index = mockContracts.findIndex((c) => c.id === id)
      if (index !== -1) {
        // Eliminar el contrato
        mockContracts.splice(index, 1)

        // Registrar en el log de auditoría
        const auditLog = {
          id: mockAuditLogs.length + 1,
          userId: getUserName() === "admin" ? 1 : 2,
          username: username,
          action: "DELETE",
          entityType: "Contract",
          entityId: id,
          details: "Eliminación de contrato",
          timestamp: new Date().toISOString(),
        }
        mockAuditLogs.push(auditLog)

        resolve(true)
      }
    }, 800)
  })
}

// Función para crear un nuevo contrato
function createContract(newContract, username) {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Generar un ID aleatorio
      const id = Math.floor(Math.random() * 1000) + 10

      // Crear el contrato
      const contract = {
        ...newContract,
        id: id,
        creadoPor: username,
        fechaCreacion: new Date().toISOString(),
      }
      mockContracts.push(contract)

      // Registrar en el log de auditoría
      const auditLog = {
        id: mockAuditLogs.length + 1,
        userId: getUserName() === "admin" ? 1 : 2,
        username: username,
        action: "CREATE",
        entityType: "Contract",
        entityId: id,
        details: "Creación de nuevo contrato",
        timestamp: new Date().toISOString(),
      }
      mockAuditLogs.push(auditLog)

      resolve({ ...contract })
    }, 800)
  })
}

// Función para obtener logs de auditoría
function fetchAuditLogs(contractId) {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (contractId) {
        resolve(mockAuditLogs.filter((log) => log.entityId === contractId))
      } else {
        resolve([...mockAuditLogs])
      }
    }, 800)
  })
}

