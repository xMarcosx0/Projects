document.addEventListener("DOMContentLoaded", () => {
  // Import necessary functions (replace with your actual import paths)
  // For example:
  // import { checkAdminAuth, getUserName, getUserRole, logout, fetchAuditLogs } from './auth-utils.js';
  // Or, if these functions are defined in a separate script included in the HTML:
  // (No import statement needed, just ensure the script is loaded before this one)

  // Dummy implementations (replace with your actual implementations or imports)
  const checkAdminAuth = () => true // Replace with actual authentication check
  const getUserName = () => "Admin User" // Replace with actual user name retrieval
  const getUserRole = () => "admin" // Replace with actual user role retrieval
  const logout = () => {
    alert("Logout function called (replace with actual logout logic)")
  } // Replace with actual logout logic
  const fetchAuditLogs = () => {
    // Replace with actual API call
    return new Promise((resolve) => {
      setTimeout(() => {
        const mockData = [
          {
            id: 1,
            username: "user1",
            action: "CREATE",
            entityType: "Product",
            entityId: "123",
            details: "Created new product",
            timestamp: new Date(),
          },
          {
            id: 2,
            username: "user2",
            action: "UPDATE",
            entityType: "Order",
            entityId: "456",
            details: "Updated order status",
            timestamp: new Date(),
          },
          {
            id: 3,
            username: "user1",
            action: "DELETE",
            entityType: "Product",
            entityId: "123",
            details: "Deleted product",
            timestamp: new Date(),
          },
          {
            id: 4,
            username: "user3",
            action: "VIEW",
            entityType: "Dashboard",
            entityId: "N/A",
            details: "Viewed dashboard",
            timestamp: new Date(),
          },
        ]
        resolve(mockData)
      }, 500)
    })
  }

  // Verificar autenticación de administrador
  if (!checkAdminAuth()) return

  // Referencias a elementos del DOM
  const userNameElement = document.getElementById("user-name")
  const userRoleElement = document.getElementById("user-role")
  const logoutBtn = document.getElementById("logout-btn")
  const searchInput = document.getElementById("search-input")
  const loadingIndicator = document.getElementById("loading-indicator")
  const auditLogsTableContainer = document.getElementById("audit-logs-table-container")
  const auditLogsTableBody = document.getElementById("audit-logs-table-body")
  const noResultsMessage = document.getElementById("no-results-message")

  // Variables globales
  let auditLogs = []

  // Mostrar información del usuario
  userNameElement.textContent = getUserName()
  userRoleElement.textContent = getUserRole() === "admin" ? "Administrador" : "Usuario"

  // Event Listeners
  logoutBtn.addEventListener("click", logout)
  searchInput.addEventListener("input", filterAuditLogs)

  // Cargar logs de auditoría
  loadAuditLogs()

  // Función para cargar logs de auditoría
  function loadAuditLogs() {
    loadingIndicator.classList.remove("d-none")
    auditLogsTableContainer.classList.add("d-none")
    noResultsMessage.classList.add("d-none")

    fetchAuditLogs()
      .then((data) => {
        auditLogs = data
        renderAuditLogs(auditLogs)
        loadingIndicator.classList.add("d-none")

        if (auditLogs.length > 0) {
          auditLogsTableContainer.classList.remove("d-none")
        } else {
          noResultsMessage.classList.remove("d-none")
        }
      })
      .catch((error) => {
        console.error("Error al cargar logs de auditoría:", error)
        loadingIndicator.classList.add("d-none")
        alert("Error al cargar los registros de auditoría. Por favor intente nuevamente.")
      })
  }

  // Función para renderizar logs de auditoría en la tabla
  function renderAuditLogs(logsToRender) {
    auditLogsTableBody.innerHTML = ""

    if (logsToRender.length === 0) {
      auditLogsTableContainer.classList.add("d-none")
      noResultsMessage.classList.remove("d-none")
      return
    }

    auditLogsTableContainer.classList.remove("d-none")
    noResultsMessage.classList.add("d-none")

    logsToRender.forEach((log) => {
      const row = document.createElement("tr")

      // Determinar la clase de badge según la acción
      let badgeClass = ""
      switch (log.action) {
        case "CREATE":
          badgeClass = "badge-create"
          break
        case "UPDATE":
          badgeClass = "badge-update"
          break
        case "DELETE":
          badgeClass = "badge-delete"
          break
        case "VIEW":
          badgeClass = "badge-view"
          break
        default:
          badgeClass = "bg-secondary"
      }

      // Formatear fecha
      const timestamp = new Date(log.timestamp).toLocaleString()

      row.innerHTML = `
        <td>${log.id}</td>
        <td>${log.username}</td>
        <td><span class="badge ${badgeClass}">${log.action}</span></td>
        <td>${log.entityType}</td>
        <td>${log.entityId}</td>
        <td>${log.details}</td>
        <td>${timestamp}</td>
      `

      auditLogsTableBody.appendChild(row)
    })
  }

  // Función para filtrar logs de auditoría
  function filterAuditLogs() {
    const searchTerm = searchInput.value.toLowerCase()

    if (searchTerm === "") {
      renderAuditLogs(auditLogs)
      return
    }

    const filteredLogs = auditLogs.filter(
      (log) =>
        log.username.toLowerCase().includes(searchTerm) ||
        log.action.toLowerCase().includes(searchTerm) ||
        log.entityType.toLowerCase().includes(searchTerm) ||
        log.details.toLowerCase().includes(searchTerm),
    )

    renderAuditLogs(filteredLogs)
  }
})

