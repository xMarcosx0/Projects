// Import necessary functions and variables
import { isAuthenticated, API_BASE_URL, getToken } from "./utils.js"

// Funcionalidad para el formulario de contratos
document.addEventListener("DOMContentLoaded", () => {
  // Verificar autenticación
  if (!isAuthenticated()) {
    window.location.href = "index.html"
    return
  }

  // Referencias a elementos del DOM
  const contractForm = document.getElementById("contract-form")
  const saveButton = document.getElementById("save-contract")
  const cancelButton = document.getElementById("cancel-contract")
  const tabButtons = document.querySelectorAll(".tab-button")
  const tabContents = document.querySelectorAll(".tab-content")

  // Inicializar selectores
  initializeSelectors()

  // Configurar navegación por pestañas
  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      // Remover clase activa de todos los botones y contenidos
      tabButtons.forEach((btn) => btn.classList.remove("active"))
      tabContents.forEach((content) => content.classList.remove("active"))

      // Agregar clase activa al botón clickeado y su contenido correspondiente
      button.classList.add("active")
      const tabId = button.getAttribute("data-tab")
      document.getElementById(tabId).classList.add("active")
    })
  })

  // Evento para guardar contrato
  if (saveButton) {
    saveButton.addEventListener("click", saveContract)
  }

  // Evento para cancelar
  if (cancelButton) {
    cancelButton.addEventListener("click", () => {
      window.location.href = "dashboard.html"
    })
  }

  // Configurar cálculos automáticos
  setupCalculations()

  // Cargar datos si estamos editando un contrato existente
  const urlParams = new URLSearchParams(window.location.search)
  const contractId = urlParams.get("id")

  if (contractId) {
    loadContractData(contractId)
  }
})

// Inicializar selectores con opciones
function initializeSelectors() {
  // Ejemplo: Llenar selector de tipo de contrato
  const tipoContratoSelect = document.getElementById("tipo_contrato")
  if (tipoContratoSelect) {
    const tiposContrato = [
      "Obra",
      "Consultoría",
      "Interventoría",
      "Prestación de Servicios",
      "Suministro",
      "Compraventa",
      "Arrendamiento",
      "Otro",
    ]

    tiposContrato.forEach((tipo) => {
      const option = document.createElement("option")
      option.value = tipo
      option.textContent = tipo
      tipoContratoSelect.appendChild(option)
    })
  }

  // Otros selectores...
}

// Configurar cálculos automáticos basados en fórmulas
function setupCalculations() {
  // Ejemplo: Calcular valor total
  const valorInicialInput = document.getElementById("valor_inicial")
  const valorAdicionesInput = document.getElementById("valor_adiciones")
  const valorTotalInput = document.getElementById("valor_total")

  if (valorInicialInput && valorAdicionesInput && valorTotalInput) {
    const calcularValorTotal = () => {
      const valorInicial = Number.parseFloat(valorInicialInput.value) || 0
      const valorAdiciones = Number.parseFloat(valorAdicionesInput.value) || 0
      valorTotalInput.value = (valorInicial + valorAdiciones).toFixed(2)
    }

    valorInicialInput.addEventListener("input", calcularValorTotal)
    valorAdicionesInput.addEventListener("input", calcularValorTotal)
  }

  // Ejemplo: Calcular porcentaje de ejecución
  const valorEjecutadoInput = document.getElementById("valor_ejecutado")
  const porcentajeEjecucionInput = document.getElementById("porcentaje_ejecucion")

  if (valorEjecutadoInput && valorTotalInput && porcentajeEjecucionInput) {
    const calcularPorcentaje = () => {
      const valorTotal = Number.parseFloat(valorTotalInput.value) || 0
      const valorEjecutado = Number.parseFloat(valorEjecutadoInput.value) || 0

      if (valorTotal > 0) {
        porcentajeEjecucionInput.value = ((valorEjecutado / valorTotal) * 100).toFixed(2)
      } else {
        porcentajeEjecucionInput.value = "0.00"
      }
    }

    valorEjecutadoInput.addEventListener("input", calcularPorcentaje)
    valorTotalInput.addEventListener("input", calcularPorcentaje)
  }

  // Configurar otros cálculos según las fórmulas especificadas
}

// Guardar contrato
function saveContract() {
  // Recopilar datos del formulario
  const formData = new FormData(document.getElementById("contract-form"))
  const contractData = {}

  for (const [key, value] of formData.entries()) {
    contractData[key] = value
  }

  // Obtener ID si estamos editando
  const urlParams = new URLSearchParams(window.location.search)
  const contractId = urlParams.get("id")

  // Determinar si es creación o actualización
  const method = contractId ? "PUT" : "POST"
  const url = contractId ? `${API_BASE_URL}/contracts/${contractId}` : `${API_BASE_URL}/contracts`

  // Enviar datos al servidor
  fetch(url, {
    method: method,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
    },
    body: JSON.stringify(contractData),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Error al guardar el contrato")
      }
      return response.json()
    })
    .then((data) => {
      showNotification("Contrato guardado exitosamente", "success")
      setTimeout(() => {
        window.location.href = "dashboard.html"
      }, 1500)
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("Error al guardar el contrato", "error")
    })
}

// Cargar datos de un contrato existente
function loadContractData(contractId) {
  fetch(`${API_BASE_URL}/contracts/${contractId}`, {
    headers: {
      Authorization: `Bearer ${getToken()}`,
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Error al cargar los datos del contrato")
      }
      return response.json()
    })
    .then((data) => {
      // Llenar el formulario con los datos del contrato
      Object.keys(data).forEach((key) => {
        const input = document.getElementById(key)
        if (input) {
          input.value = data[key]
        }
      })

      // Activar cálculos automáticos para actualizar campos calculados
      const event = new Event("input", { bubbles: true })
      document.getElementById("valor_inicial").dispatchEvent(event)
      document.getElementById("valor_ejecutado").dispatchEvent(event)
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("Error al cargar los datos del contrato", "error")
    })
}

// Mostrar notificación
function showNotification(message, type) {
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.textContent = message

  document.body.appendChild(notification)

  setTimeout(() => {
    notification.classList.add("show")
  }, 10)

  setTimeout(() => {
    notification.classList.remove("show")
    setTimeout(() => {
      document.body.removeChild(notification)
    }, 300)
  }, 3000)
}

