document.addEventListener("DOMContentLoaded", () => {
  // Mock functions for demonstration purposes.  Replace with actual implementations.
  const checkAuth = () => true // Replace with actual authentication check
  const getUserName = () => "John Doe" // Replace with actual user name retrieval
  const getUserRole = () => "admin" // Replace with actual user role retrieval
  const logout = () => {
    alert("Logging out...")
    // Redirect to login page or perform other logout actions
  }
  const fetchContracts = () => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const mockContracts = [
          {
            id: 1,
            nombrePRST: "PRST Uno",
            nombreCorto: "Corto 1",
            responsable: "Responsable 1",
            estado: "Contratado",
            valorContrato: 1000000,
            inicioVigencia: "2023-01-01",
            finVigencia: "2023-12-31",
            clasificacion: "Clasificación A",
            arreglo: "Arreglo X",
            ultimoContrato: true,
            enviadoDigitalmente: true,
            enviadoFisicamente: false,
            fisicamenteEnOficina: true,
            fechaPreLiquidacion: "2023-11-01",
            fechaRadFactura: "2023-01-15",
            duracionAnios: 1,
            estadoContrato: "Vigente",
            proximoVencer: false,
            garantiasRequeridas: "Sí",
            cable8M: 10,
            cable10M: 5,
            cable12M: 8,
            cable14M: 2,
            cable15M: 7,
            cable16M: 3,
            cable20M: 12,
            cajaEmpalme8M: 2,
            cajaEmpalme10M: 1,
            cajaEmpalme12M: 3,
            cajaEmpalme14M: 0,
            cajaEmpalme15M: 2,
            cajaEmpalme16M: 1,
            cajaEmpalme20M: 4,
            reserva8M: 5,
            reserva10M: 2,
            reserva12M: 1,
            reserva14M: 3,
            reserva15M: 0,
            reserva16M: 2,
            reserva20M: 1,
            nap8M: 1,
            nap10M: 0,
            nap12M: 2,
            nap14M: 1,
            nap15M: 3,
            nap16M: 0,
            nap20M: 2,
            vigenciaAmparoCumplimiento: "1 año",
            inicioVigenciaCumplimiento: "2023-01-05",
            finVigenciaCumplimiento: "2024-01-05",
            valorAseguradoCumplimiento: 500000,
            valorAseguradoTextoCumplimiento: "Quinientos mil pesos",
            numeroPolizaCumplimiento: "PC123",
            inicioAmparoCumplimiento: "2023-01-10",
            finAmparoCumplimiento: "2024-01-10",
            fechaExpedicionPolizaCumplimiento: "2023-01-05",
            tomadorCumplimiento: "Tomador Uno",
            aseguradoBeneficiarioCumplimiento: "Beneficiario Uno",
            fechaPolizaConforme: "2023-01-12",
            valorAseguradoConforme: "500000",
            vigenciaAmparoRCE: "1 año",
            inicioVigenciaRCE: "2023-01-05",
            finVigenciaRCE: "2024-01-05",
            valorAseguradoRCE: 250000,
            valorAseguradoTextoRCE: "Doscientos cincuenta mil pesos",
            numeroPolizaRCE: "RCE456",
            inicioAmparoRCE: "2023-01-10",
            finAmparoRCE: "2024-01-10",
            fechaExpedicionPolizaRCE: "2023-01-05",
            tomadorRCE: "Tomador Dos",
            aseguradoBeneficiarioRCE: "Beneficiario Dos",
            fechaPolizaConformeRCE: "2023-01-12",
            valorAseguradoConformeRCE: "250000",
          },
          {
            id: 2,
            nombrePRST: "PRST Dos",
            nombreCorto: "Corto 2",
            responsable: "Responsable 2",
            estado: "En Renovación",
            valorContrato: 2000000,
            inicioVigencia: "2022-06-01",
            finVigencia: "2024-05-31",
            clasificacion: "Clasificación B",
            arreglo: "Arreglo Y",
            ultimoContrato: false,
            enviadoDigitalmente: false,
            enviadoFisicamente: true,
            fisicamenteEnOficina: false,
            fechaPreLiquidacion: "2024-04-01",
            fechaRadFactura: "2022-06-15",
            duracionAnios: 2,
            estadoContrato: "Por Renovar",
            proximoVencer: true,
            garantiasRequeridas: "No",
            cable8M: 5,
            cable10M: 2,
            cable12M: 3,
            cable14M: 1,
            cable15M: 4,
            cable16M: 0,
            cable20M: 6,
            cajaEmpalme8M: 1,
            cajaEmpalme10M: 0,
            cajaEmpalme12M: 1,
            cajaEmpalme14M: 0,
            cajaEmpalme15M: 1,
            cajaEmpalme16M: 0,
            cajaEmpalme20M: 2,
            reserva8M: 2,
            reserva10M: 1,
            reserva12M: 0,
            reserva14M: 2,
            reserva15M: 0,
            reserva16M: 1,
            reserva20M: 0,
            nap8M: 0,
            nap10M: 1,
            nap12M: 0,
            nap14M: 0,
            nap15M: 2,
            nap16M: 0,
            nap20M: 1,
            vigenciaAmparoCumplimiento: "2 años",
            inicioVigenciaCumplimiento: "2022-06-05",
            finVigenciaCumplimiento: "2024-06-05",
            valorAseguradoCumplimiento: 750000,
            valorAseguradoTextoCumplimiento: "Setecientos cincuenta mil pesos",
            numeroPolizaCumplimiento: "PC789",
            inicioAmparoCumplimiento: "2022-06-10",
            finAmparoCumplimiento: "2024-06-10",
            fechaExpedicionPolizaCumplimiento: "2022-06-05",
            tomadorCumplimiento: "Tomador Tres",
            aseguradoBeneficiarioCumplimiento: "Beneficiario Tres",
            fechaPolizaConforme: "2022-06-12",
            valorAseguradoConforme: "750000",
            vigenciaAmparoRCE: "2 años",
            inicioVigenciaRCE: "2022-06-05",
            finVigenciaRCE: "2024-06-05",
            valorAseguradoRCE: 375000,
            valorAseguradoTextoRCE: "Trescientos setenta y cinco mil pesos",
            numeroPolizaRCE: "RCE012",
            inicioAmparoRCE: "2022-06-10",
            finAmparoRCE: "2024-06-10",
            fechaExpedicionPolizaRCE: "2022-06-05",
            tomadorRCE: "Tomador Cuatro",
            aseguradoBeneficiarioRCE: "Beneficiario Cuatro",
            fechaPolizaConformeRCE: "2022-06-12",
            valorAseguradoConformeRCE: "375000",
          },
        ]
        resolve(mockContracts)
      }, 500)
    })
  }
  const updateContract = (id, updatedContract, username) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        // Simulate updating the contract
        resolve(updatedContract)
      }, 500)
    })
  }
  const deleteContract = (id, username) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate deleting the contract
        resolve(true)
      }, 500)
    })
  }
  const createContract = (newContract, username) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        // Simulate creating a new contract
        newContract.id = Math.floor(Math.random() * 100) + 3 // Mock ID
        resolve(newContract)
      }, 500)
    })
  }

  const mockAuditLogs = []

  // Verificar autenticación
  if (!checkAuth()) return

  // Referencias a elementos del DOM
  const userNameElement = document.getElementById("user-name")
  const userRoleElement = document.getElementById("user-role")
  const logoutBtn = document.getElementById("logout-btn")
  const searchInput = document.getElementById("search-input")
  const loadingIndicator = document.getElementById("loading-indicator")
  const contractsTableContainer = document.getElementById("contracts-table-container")
  const contractsTableBody = document.getElementById("contracts-table-body")
  const noResultsMessage = document.getElementById("no-results-message")
  const addContractBtn = document.getElementById("add-contract-btn")
  const auditLogsBtn = document.getElementById("audit-logs-btn")

  // Modales
  const viewContractModal = new bootstrap.Modal(document.getElementById("view-contract-modal"))
  const editContractModal = new bootstrap.Modal(document.getElementById("edit-contract-modal"))
  const deleteContractModal = new bootstrap.Modal(document.getElementById("delete-contract-modal"))
  const addContractModal = new bootstrap.Modal(document.getElementById("add-contract-modal"))

  // Botones de acción
  const saveEditContractBtn = document.getElementById("save-edit-contract-btn")
  const confirmDeleteBtn = document.getElementById("confirm-delete-btn")
  const saveAddContractBtn = document.getElementById("save-add-contract-btn")

  // Variables globales
  let contracts = []
  let selectedContractId = null

  // Mostrar información del usuario
  userNameElement.textContent = getUserName()
  userRoleElement.textContent = getUserRole() === "admin" ? "Administrador" : "Usuario"

  // Mostrar/ocultar elementos según el rol
  if (getUserRole() === "admin") {
    document.querySelectorAll(".admin-only").forEach((el) => el.classList.remove("d-none"))
  }

  // Cargar contratos
  loadContracts()

  // Event Listeners
  logoutBtn.addEventListener("click", logout)
  searchInput.addEventListener("input", filterContracts)
  addContractBtn.addEventListener("click", showAddContractModal)
  saveEditContractBtn.addEventListener("click", saveEditContract)
  confirmDeleteBtn.addEventListener("click", confirmDeleteContract)
  saveAddContractBtn.addEventListener("click", saveAddContract)

  // Función para cargar contratos
  function loadContracts() {
    loadingIndicator.classList.remove("d-none")
    contractsTableContainer.classList.add("d-none")
    noResultsMessage.classList.add("d-none")

    fetchContracts()
      .then((data) => {
        contracts = data
        renderContracts(contracts)
        loadingIndicator.classList.add("d-none")

        if (contracts.length > 0) {
          contractsTableContainer.classList.remove("d-none")
        } else {
          noResultsMessage.classList.remove("d-none")
        }
      })
      .catch((error) => {
        console.error("Error al cargar contratos:", error)
        loadingIndicator.classList.add("d-none")
        alert("Error al cargar los contratos. Por favor intente nuevamente.")
      })
  }

  // Función para renderizar contratos en la tabla
  function renderContracts(contractsToRender) {
    contractsTableBody.innerHTML = ""

    if (contractsToRender.length === 0) {
      contractsTableContainer.classList.add("d-none")
      noResultsMessage.classList.remove("d-none")
      return
    }

    contractsTableContainer.classList.remove("d-none")
    noResultsMessage.classList.add("d-none")

    contractsToRender.forEach((contract, index) => {
      const row = document.createElement("tr")

      // Determinar la clase de badge según el estado
      let badgeClass = ""
      switch (contract.estado) {
        case "Contratado":
          badgeClass = "badge-contratado"
          break
        case "Finalizado":
          badgeClass = "badge-finalizado"
          break
        case "En Renovación":
        case "En Renovación - Firma PRST":
        case "En Renovación - Firma AIR-E":
          badgeClass = "badge-renovacion"
          break
        case "En Gestión":
          badgeClass = "badge-gestion"
          break
        default:
          badgeClass = "bg-secondary"
      }

      // Formatear valor del contrato
      const formattedValue = new Intl.NumberFormat("es-CO", {
        style: "currency",
        currency: "COP",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(contract.valorContrato)

      // Formatear fechas
      const inicioVigencia = new Date(contract.inicioVigencia).toLocaleDateString()
      const finVigencia = new Date(contract.finVigencia).toLocaleDateString()

      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${contract.nombrePRST}</td>
        <td>${contract.nombreCorto}</td>
        <td>${contract.responsable}</td>
        <td><span class="badge ${badgeClass}">${contract.estado}</span></td>
        <td>${formattedValue}</td>
        <td>${inicioVigencia} - ${finVigencia}</td>
        <td class="text-end">
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Acciones
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item view-contract" href="#" data-id="${contract.id}"><i class="bi bi-eye me-2"></i> Ver detalles</a></li>
                    <li><a class="dropdown-item edit-contract" href="#" data-id="${contract.id}"><i class="bi bi-pencil me-2"></i> Editar</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger delete-contract" href="#" data-id="${contract.id}"><i class="bi bi-trash me-2"></i> Eliminar</a></li>
                </ul>
            </div>
        </td>
      `

      contractsTableBody.appendChild(row)
    })

    // Agregar event listeners a los botones de acción
    document.querySelectorAll(".view-contract").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.preventDefault()
        const id = Number.parseInt(this.getAttribute("data-id"))
        viewContract(id)
      })
    })

    document.querySelectorAll(".edit-contract").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.preventDefault()
        const id = Number.parseInt(this.getAttribute("data-id"))
        editContract(id)
      })
    })

    document.querySelectorAll(".delete-contract").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.preventDefault()
        const id = Number.parseInt(this.getAttribute("data-id"))
        deleteContractModalShow(id)
      })
    })
  }

  // Función para filtrar contratos
  function filterContracts() {
    const searchTerm = searchInput.value.toLowerCase()

    if (searchTerm === "") {
      renderContracts(contracts)
      return
    }

    const filteredContracts = contracts.filter(
      (contract) =>
        contract.nombrePRST.toLowerCase().includes(searchTerm) ||
        contract.nombreCorto.toLowerCase().includes(searchTerm) ||
        contract.responsable.toLowerCase().includes(searchTerm),
    )

    renderContracts(filteredContracts)
  }

  // Función para ver detalles de un contrato
  function viewContract(id) {
    const contract = contracts.find((c) => c.id === id)
    if (!contract) return

    const viewContractContent = document.getElementById("view-contract-content")

    // Formatear valor del contrato
    const formattedValue = new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(contract.valorContrato)

    // Formatear fechas
    const inicioVigencia = new Date(contract.inicioVigencia).toLocaleDateString()
    const finVigencia = new Date(contract.finVigencia).toLocaleDateString()

    // Construir HTML para los detalles del contrato
    const html = `
      <div class="accordion" id="contractDetailsAccordion">
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#generalInfoCollapse" aria-expanded="true" aria-controls="generalInfoCollapse">
              Información Principal
            </button>
          </h2>
          <div id="generalInfoCollapse" class="accordion-collapse collapse show" data-bs-parent="#contractDetailsAccordion">
            <div class="accordion-body">
              <div class="row">
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Nombre del PRST</div>
                  <div class="contract-detail-value">${contract.nombrePRST}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Nombre Corto</div>
                  <div class="contract-detail-value">${contract.nombreCorto}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Responsable</div>
                  <div class="contract-detail-value">${contract.responsable}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Clasificación</div>
                  <div class="contract-detail-value">${contract.clasificacion}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Arreglo</div>
                  <div class="contract-detail-value">${contract.arreglo || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Estado</div>
                  <div class="contract-detail-value">
                    <span class="badge ${getStatusBadgeClass(contract.estado)}">${contract.estado}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#adminInfoCollapse" aria-expanded="false" aria-controls="adminInfoCollapse">
              Información Administrativa
            </button>
          </h2>
          <div id="adminInfoCollapse" class="accordion-collapse collapse" data-bs-parent="#contractDetailsAccordion">
            <div class="accordion-body">
              <div class="row">
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">¿Último Contrato?</div>
                  <div class="contract-detail-value">${contract.ultimoContrato ? "Sí" : "No"}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">¿Enviado Digitalmente?</div>
                  <div class="contract-detail-value">${contract.enviadoDigitalmente ? "Sí" : "No"}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">¿Enviado Físicamente?</div>
                  <div class="contract-detail-value">${contract.enviadoFisicamente ? "Sí" : "No"}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">¿Físicamente En Oficina?</div>
                  <div class="contract-detail-value">${contract.fisicamenteEnOficina ? "Sí" : "No"}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Fecha de Pre-Liquidación</div>
                  <div class="contract-detail-value">${contract.fechaPreLiquidacion ? new Date(contract.fechaPreLiquidacion).toLocaleDateString() : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Fecha de Rad. De Factura</div>
                  <div class="contract-detail-value">${contract.fechaRadFactura || "N/A"}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#contractInfoCollapse" aria-expanded="false" aria-controls="contractInfoCollapse">
              Información de Contrato
            </button>
          </h2>
          <div id="contractInfoCollapse" class="accordion-collapse collapse" data-bs-parent="#contractDetailsAccordion">
            <div class="accordion-body">
              <div class="row">
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Valor del Contrato</div>
                  <div class="contract-detail-value">${formattedValue}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Duración (Años)</div>
                  <div class="contract-detail-value">${contract.duracionAnios}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Inicio de Vigencia</div>
                  <div class="contract-detail-value">${inicioVigencia}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Fin de Vigencia</div>
                  <div class="contract-detail-value">${finVigencia}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Estado de Contrato</div>
                  <div class="contract-detail-value">${contract.estadoContrato}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">¿Próximo a Vencer?</div>
                  <div class="contract-detail-value">${contract.proximoVencer ? "Sí" : "No"}</div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="contract-detail-label">Garantías requeridas</div>
                  <div class="contract-detail-value">${contract.garantiasRequeridas || "N/A"}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#infrastructureCollapse" aria-expanded="false" aria-controls="infrastructureCollapse">
              Infraestructura
            </button>
          </h2>
          <div id="infrastructureCollapse" class="accordion-collapse collapse" data-bs-parent="#contractDetailsAccordion">
            <div class="accordion-body">
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead class="table-light">
                    <tr>
                      <th>Tipo</th>
                      <th>8 M</th>
                      <th>10 M</th>
                      <th>12 M</th>
                      <th>14 M</th>
                      <th>15 M</th>
                      <th>16 M</th>
                      <th>20 M</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="fw-medium">Cable</td>
                      <td>${contract.cable8M}</td>
                      <td>${contract.cable10M}</td>
                      <td>${contract.cable12M}</td>
                      <td>${contract.cable14M}</td>
                      <td>${contract.cable15M}</td>
                      <td>${contract.cable16M}</td>
                      <td>${contract.cable20M}</td>
                    </tr>
                    <tr>
                      <td class="fw-medium">Caja de Empalme</td>
                      <td>${contract.cajaEmpalme8M}</td>
                      <td>${contract.cajaEmpalme10M}</td>
                      <td>${contract.cajaEmpalme12M}</td>
                      <td>${contract.cajaEmpalme14M}</td>
                      <td>${contract.cajaEmpalme15M}</td>
                      <td>${contract.cajaEmpalme16M}</td>
                      <td>${contract.cajaEmpalme20M}</td>
                    </tr>
                    <tr>
                      <td class="fw-medium">Reserva</td>
                      <td>${contract.reserva8M}</td>
                      <td>${contract.reserva10M}</td>
                      <td>${contract.reserva12M}</td>
                      <td>${contract.reserva14M}</td>
                      <td>${contract.reserva15M}</td>
                      <td>${contract.reserva16M}</td>
                      <td>${contract.reserva20M}</td>
                    </tr>
                    <tr>
                      <td class="fw-medium">NAP</td>
                      <td>${contract.nap8M}</td>
                      <td>${contract.nap10M}</td>
                      <td>${contract.nap12M}</td>
                      <td>${contract.nap14M}</td>
                      <td>${contract.nap15M}</td>
                      <td>${contract.nap16M}</td>
                      <td>${contract.nap20M}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#policiesCollapse" aria-expanded="false" aria-controls="policiesCollapse">
              Información de Pólizas
            </button>
          </h2>
          <div id="policiesCollapse" class="accordion-collapse collapse" data-bs-parent="#contractDetailsAccordion">
            <div class="accordion-body">
              <h5 class="mb-3">Póliza de Cumplimiento</h5>
              <div class="row mb-4">
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Vigencia de amparo</div>
                  <div class="contract-detail-value">${contract.vigenciaAmparoCumplimiento || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Inicio de Vigencia</div>
                  <div class="contract-detail-value">${contract.inicioVigenciaCumplimiento ? new Date(contract.inicioVigenciaCumplimiento).toLocaleDateString() : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Fin de Vigencia</div>
                  <div class="contract-detail-value">${contract.finVigenciaCumplimiento ? new Date(contract.finVigenciaCumplimiento).toLocaleDateString() : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Valor Asegurado</div>
                  <div class="contract-detail-value">${contract.valorAseguradoCumplimiento ? new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(contract.valorAseguradoCumplimiento) : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Valor Asegurado (Texto)</div>
                  <div class="contract-detail-value">${contract.valorAseguradoTextoCumplimiento || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Número de Póliza</div>
                  <div class="contract-detail-value">${contract.numeroPolizaCumplimiento || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Fecha de expedición</div>
                  <div class="contract-detail-value">${contract.fechaExpedicionPolizaCumplimiento ? new Date(contract.fechaExpedicionPolizaCumplimiento).toLocaleDateString() : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Fecha de Póliza Conforme</div>
                  <div class="contract-detail-value">${contract.fechaPolizaConforme || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Valor asegurado Conforme</div>
                  <div class="contract-detail-value">${contract.valorAseguradoConforme || "N/A"}</div>
                </div>
              </div>
              
              <h5 class="mb-3">Póliza de RCE</h5>
              <div class="row">
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Vigencia de amparo</div>
                  <div class="contract-detail-value">${contract.vigenciaAmparoRCE || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Inicio de Vigencia</div>
                  <div class="contract-detail-value">${contract.inicioVigenciaRCE ? new Date(contract.inicioVigenciaRCE).toLocaleDateString() : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Fin de Vigencia</div>
                  <div class="contract-detail-value">${contract.finVigenciaRCE ? new Date(contract.finVigenciaRCE).toLocaleDateString() : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Valor Asegurado</div>
                  <div class="contract-detail-value">${contract.valorAseguradoRCE ? new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(contract.valorAseguradoRCE) : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Valor Asegurado (Texto)</div>
                  <div class="contract-detail-value">${contract.valorAseguradoTextoRCE || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Número de Póliza</div>
                  <div class="contract-detail-value">${contract.numeroPolizaRCE || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Fecha de expedición</div>
                  <div class="contract-detail-value">${contract.fechaExpedicionPolizaRCE ? new Date(contract.fechaExpedicionPolizaRCE).toLocaleDateString() : "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Fecha de Póliza Conforme</div>
                  <div class="contract-detail-value">${contract.fechaPolizaConformeRCE || "N/A"}</div>
                </div>
                <div class="col-md-6 mb-2">
                  <div class="contract-detail-label">Valor asegurado Conforme</div>
                  <div class="contract-detail-value">${contract.valorAseguradoConformeRCE || "N/A"}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `

    viewContractContent.innerHTML = html
    viewContractModal.show()

    // Registrar en el log de auditoría
    const auditLog = {
      id: mockAuditLogs.length + 1,
      userId: getUserName() === "admin" ? 1 : 2,
      username: getUserName(),
      action: "VIEW",
      entityType: "Contract",
      entityId: id,
      details: "Visualización de detalles de contrato",
      timestamp: new Date().toISOString(),
    }
    mockAuditLogs.push(auditLog)
  }

  // Función para editar un contrato
  function editContract(id) {
    const contract = contracts.find((c) => c.id === id)
    if (!contract) return

    selectedContractId = id

    // Llenar el formulario con los datos del contrato
    document.getElementById("edit-contract-id").value = contract.id
    document.getElementById("edit-nombre-prst").value = contract.nombrePRST
    document.getElementById("edit-nombre-corto").value = contract.nombreCorto
    document.getElementById("edit-responsable").value = contract.responsable
    document.getElementById("edit-clasificacion").value = contract.clasificacion
    document.getElementById("edit-arreglo").value = contract.arreglo || ""
    document.getElementById("edit-estado").value = contract.estado

    // Información administrativa
    document.getElementById("edit-ultimo-contrato").checked = contract.ultimoContrato
    document.getElementById("edit-enviado-digitalmente").checked = contract.enviadoDigitalmente
    document.getElementById("edit-enviado-fisicamente").checked = contract.enviadoFisicamente
    document.getElementById("edit-fisicamente-en-oficina").checked = contract.fisicamenteEnOficina
    document.getElementById("edit-fecha-pre-liquidacion").value = contract.fechaPreLiquidacion || ""
    document.getElementById("edit-fecha-rad-factura").value = contract.fechaRadFactura || ""

    // Información contractual
    document.getElementById("edit-valor-contrato").value = contract.valorContrato
    document.getElementById("edit-duracion-anios").value = contract.duracionAnios
    document.getElementById("edit-inicio-vigencia").value = contract.inicioVigencia
      ? new Date(contract.inicioVigencia).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-vigencia").value = contract.finVigencia
      ? new Date(contract.finVigencia).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-estado-contrato").value = contract.estadoContrato
    document.getElementById("edit-proximo-vencer").value = contract.proximoVencer ? "Sí" : "No"
    document.getElementById("edit-garantias-requeridas").value = contract.garantiasRequeridas || "N/A"

    // Infraestructura - Cable
    document.getElementById("edit-cable-8m").value = contract.cable8M
    document.getElementById("edit-cable-10m").value = contract.cable10M
    document.getElementById("edit-cable-12m").value = contract.cable12M
    document.getElementById("edit-cable-14m").value = contract.cable14M
    document.getElementById("edit-cable-15m").value = contract.cable15M
    document.getElementById("edit-cable-16m").value = contract.cable16M
    document.getElementById("edit-cable-20m").value = contract.cable20M

    // Infraestructura - Caja de Empalme
    document.getElementById("edit-caja-empalme-8m").value = contract.cajaEmpalme8M
    document.getElementById("edit-caja-empalme-10m").value = contract.cajaEmpalme10M
    document.getElementById("edit-caja-empalme-12m").value = contract.cajaEmpalme12M
    document.getElementById("edit-caja-empalme-14m").value = contract.cajaEmpalme14M
    document.getElementById("edit-caja-empalme-15m").value = contract.cajaEmpalme15M
    document.getElementById("edit-caja-empalme-16m").value = contract.cajaEmpalme16M
    document.getElementById("edit-caja-empalme-20m").value = contract.cajaEmpalme20M

    // Infraestructura - Reserva
    document.getElementById("edit-reserva-8m").value = contract.reserva8M
    document.getElementById("edit-reserva-10m").value = contract.reserva10M
    document.getElementById("edit-reserva-12m").value = contract.reserva12M
    document.getElementById("edit-reserva-14m").value = contract.reserva14M
    document.getElementById("edit-reserva-15m").value = contract.reserva15M
    document.getElementById("edit-reserva-16m").value = contract.reserva16M
    document.getElementById("edit-reserva-20m").value = contract.reserva20M

    // Infraestructura - NAP
    document.getElementById("edit-nap-8m").value = contract.nap8M
    document.getElementById("edit-nap-10m").value = contract.nap10M
    document.getElementById("edit-nap-12m").value = contract.nap12M
    document.getElementById("edit-nap-14m").value = contract.nap14M
    document.getElementById("edit-nap-15m").value = contract.nap15M
    document.getElementById("edit-nap-16m").value = contract.nap16M
    document.getElementById("edit-nap-20m").value = contract.nap20M

    // Póliza de Cumplimiento
    document.getElementById("edit-vigencia-amparo-cumplimiento").value = contract.vigenciaAmparoCumplimiento || ""
    document.getElementById("edit-inicio-vigencia-cumplimiento").value = contract.inicioVigenciaCumplimiento
      ? new Date(contract.inicioVigenciaCumplimiento).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-vigencia-cumplimiento").value = contract.finVigenciaCumplimiento
      ? new Date(contract.finVigenciaCumplimiento).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-valor-asegurado-cumplimiento").value = contract.valorAseguradoCumplimiento || ""
    document.getElementById("edit-valor-asegurado-texto-cumplimiento").value =
      contract.valorAseguradoTextoCumplimiento || ""
    document.getElementById("edit-numero-poliza-cumplimiento").value = contract.numeroPolizaCumplimiento || ""
    document.getElementById("edit-inicio-amparo-cumplimiento").value = contract.inicioAmparoCumplimiento
      ? new Date(contract.inicioAmparoCumplimiento).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-amparo-cumplimiento").value = contract.finAmparoCumplimiento
      ? new Date(contract.finAmparoCumplimiento).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fecha-expedicion-poliza-cumplimiento").value =
      contract.fechaExpedicionPolizaCumplimiento
        ? new Date(contract.fechaExpedicionPolizaCumplimiento).toISOString().split("T")[0]
        : ""
    document.getElementById("edit-tomador-cumplimiento").value = contract.tomadorCumplimiento || ""
    document.getElementById("edit-asegurado-beneficiario-cumplimiento").value =
      contract.aseguradoBeneficiarioCumplimiento || ""
    document.getElementById("edit-fecha-poliza-conforme").value = contract.fechaPolizaConforme || ""
    document.getElementById("edit-valor-asegurado-conforme").value = contract.valorAseguradoConforme || ""

    // Póliza de RCE
    document.getElementById("edit-vigencia-amparo-rce").value = contract.vigenciaAmparoRCE || ""
    document.getElementById("edit-inicio-vigencia-rce").value = contract.inicioVigenciaRCE
      ? new Date(contract.inicioVigenciaRCE).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-vigencia-rce").value = contract.finVigenciaRCE
      ? new Date(contract.finVigenciaRCE).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-valor-asegurado-rce").value = contract.valorAseguradoRCE || ""
    document.getElementById("edit-valor-asegurado-texto-rce").value = contract.valorAseguradoTextoRCE || ""
    document.getElementById("edit-numero-poliza-rce").value = contract.numeroPolizaRCE || ""
    document.getElementById("edit-inicio-amparo-rce").value = contract.inicioAmparoRCE
      ? new Date(contract.inicioAmparoRCE).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-amparo-rce").value = contract.finAmparoRCE
      ? new Date(contract.finAmparoRCE).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fecha-expedicion-poliza-rce").value = contract.fechaExpedicionPolizaRCE
      ? new Date(contract.fechaExpedicionPolizaRCE).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-tomador-rce").value = contract.tomadorRCE || ""
    document.getElementById("edit-asegurado-beneficiario-rce").value = contract.aseguradoBeneficiarioRCE || ""
    document.getElementById("edit-fecha-poliza-conforme-rce").value = contract.fechaPolizaConformeRCE || ""
    document.getElementById("edit-valor-asegurado-conforme-rce").value = contract.valorAseguradoConformeRCE || ""

    editContractModal.show()
  }

  // Función para guardar cambios en un contrato
  function saveEditContract() {
    const form = document.getElementById("edit-contract-form")
    if (!form.checkValidity()) {
      form.reportValidity()
      return
    }

    const id = Number.parseInt(document.getElementById("edit-contract-id").value)

    // Recopilar datos del formulario
    const updatedContract = {
      id: id,
      nombrePRST: document.getElementById("edit-nombre-prst").value,
      nombreCorto: document.getElementById("edit-nombre-corto").value,
      responsable: document.getElementById("edit-responsable").value,
      clasificacion: document.getElementById("edit-clasificacion").value,
      arreglo: document.getElementById("edit-arreglo").value,
      estado: document.getElementById("edit-estado").value,

      // Información administrativa
      ultimoContrato: document.getElementById("edit-ultimo-contrato").checked,
      enviadoDigitalmente: document.getElementById("edit-enviado-digitalmente").checked,
      enviadoFisicamente: document.getElementById("edit-enviado-fisicamente").checked,
      fisicamenteEnOficina: document.getElementById("edit-fisicamente-en-oficina").checked,
      fechaPreLiquidacion: document.getElementById("edit-fecha-pre-liquidacion").value,
      fechaRadFactura: document.getElementById("edit-fecha-rad-factura").value,

      // Información contractual
      valorContrato: Number.parseFloat(document.getElementById("edit-valor-contrato").value),
      duracionAnios: Number.parseInt(document.getElementById("edit-duracion-anios").value),
      inicioVigencia: document.getElementById("edit-inicio-vigencia").value,
      finVigencia: document.getElementById("edit-fin-vigencia").value,
      estadoContrato: document.getElementById("edit-estado-contrato").value,
      proximoVencer: document.getElementById("edit-proximo-vencer").value === "Sí",
      garantiasRequeridas: document.getElementById("edit-garantias-requeridas").value,

      // Infraestructura - Cable
      cable8M: Number.parseInt(document.getElementById("edit-cable-8m").value) || 0,
      cable10M: Number.parseInt(document.getElementById("edit-cable-10m").value) || 0,
      cable12M: Number.parseInt(document.getElementById("edit-cable-12m").value) || 0,
      cable14M: Number.parseInt(document.getElementById("edit-cable-14m").value) || 0,
      cable15M: Number.parseInt(document.getElementById("edit-cable-15m").value) || 0,
      cable16M: Number.parseInt(document.getElementById("edit-cable-16m").value) || 0,
      cable20M: Number.parseInt(document.getElementById("edit-cable-20m").value) || 0,

      // Infraestructura - Caja de Empalme
      cajaEmpalme8M: Number.parseInt(document.getElementById("edit-caja-empalme-8m").value) || 0,
      cajaEmpalme10M: Number.parseInt(document.getElementById("edit-caja-empalme-10m").value) || 0,
      cajaEmpalme12M: Number.parseInt(document.getElementById("edit-caja-empalme-12m").value) || 0,
      cajaEmpalme14M: Number.parseInt(document.getElementById("edit-caja-empalme-14m").value) || 0,
      cajaEmpalme15M: Number.parseInt(document.getElementById("edit-caja-empalme-15m").value) || 0,
      cajaEmpalme16M: Number.parseInt(document.getElementById("edit-caja-empalme-16m").value) || 0,
      cajaEmpalme20M: Number.parseInt(document.getElementById("edit-caja-empalme-20m").value) || 0,

      // Infraestructura - Reserva
      reserva8M: Number.parseInt(document.getElementById("edit-reserva-8m").value) || 0,
      reserva10M: Number.parseInt(document.getElementById("edit-reserva-10m").value) || 0,
      reserva12M: Number.parseInt(document.getElementById("edit-reserva-12m").value) || 0,
      reserva14M: Number.parseInt(document.getElementById("edit-reserva-14m").value) || 0,
      reserva15M: Number.parseInt(document.getElementById("edit-reserva-15m").value) || 0,
      reserva16M: Number.parseInt(document.getElementById("edit-reserva-16m").value) || 0,
      reserva20M: Number.parseInt(document.getElementById("edit-reserva-20m").value) || 0,

      // Infraestructura - NAP
      nap8M: Number.parseInt(document.getElementById("edit-nap-8m").value) || 0,
      nap10M: Number.parseInt(document.getElementById("edit-nap-10m").value) || 0,
      nap12M: Number.parseInt(document.getElementById("edit-nap-12m").value) || 0,
      nap14M: Number.parseInt(document.getElementById("edit-nap-14m").value) || 0,
      nap15M: Number.parseInt(document.getElementById("edit-nap-15m").value) || 0,
      nap16M: Number.parseInt(document.getElementById("edit-nap-16m").value) || 0,
      nap20M: Number.parseInt(document.getElementById("edit-nap-20m").value) || 0,

      // Póliza de Cumplimiento
      vigenciaAmparoCumplimiento: document.getElementById("edit-vigencia-amparo-cumplimiento").value,
      inicioVigenciaCumplimiento: document.getElementById("edit-inicio-vigencia-cumplimiento").value,
      finVigenciaCumplimiento: document.getElementById("edit-fin-vigencia-cumplimiento").value,
      valorAseguradoCumplimiento:
        Number.parseFloat(document.getElementById("edit-valor-asegurado-cumplimiento").value) || 0,
      valorAseguradoTextoCumplimiento: document.getElementById("edit-valor-asegurado-texto-cumplimiento").value,
      numeroPolizaCumplimiento: document.getElementById("edit-numero-poliza-cumplimiento").value,
      inicioAmparoCumplimiento: document.getElementById("edit-inicio-amparo-cumplimiento").value,
      finAmparoCumplimiento: document.getElementById("edit-fin-amparo-cumplimiento").value,
      fechaExpedicionPolizaCumplimiento: document.getElementById("edit-fecha-expedicion-poliza-cumplimiento").value,
      tomadorCumplimiento: document.getElementById("edit-tomador-cumplimiento").value,
      aseguradoBeneficiarioCumplimiento: document.getElementById("edit-asegurado-beneficiario-cumplimiento").value,
      fechaPolizaConforme: document.getElementById("edit-fecha-poliza-conforme").value,
      valorAseguradoConforme: document.getElementById("edit-valor-asegurado-conforme").value,

      // Póliza de RCE
      vigenciaAmparoRCE: document.getElementById("edit-vigencia-amparo-rce").value,
      inicioVigenciaRCE: document.getElementById("edit-inicio-vigencia-rce").value,
      finVigenciaRCE: document.getElementById("edit-fin-vigencia-rce").value,
      valorAseguradoRCE: Number.parseFloat(document.getElementById("edit-valor-asegurado-rce").value) || 0,
      valorAseguradoTextoRCE: document.getElementById("edit-valor-asegurado-texto-rce").value,
      numeroPolizaRCE: document.getElementById("edit-numero-poliza-rce").value,
      inicioAmparoRCE: document.getElementById("edit-inicio-amparo-rce").value,
      finAmparoRCE: document.getElementById("edit-fin-amparo-rce").value,
      fechaExpedicionPolizaRCE: document.getElementById("edit-fecha-expedicion-poliza-rce").value,
      tomadorRCE: document.getElementById("edit-tomador-rce").value,
      aseguradoBeneficiarioRCE: document.getElementById("edit-asegurado-beneficiario-rce").value,
      fechaPolizaConformeRCE: document.getElementById("edit-fecha-poliza-conforme-rce").value,
      valorAseguradoConformeRCE: document.getElementById("edit-valor-asegurado-conforme-rce").value,
    }

    // Guardar cambios
    saveEditContractBtn.disabled = true
    saveEditContractBtn.innerHTML =
      '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Guardando...'

    updateContract(id, updatedContract, getUserName())
      .then((updatedContract) => {
        // Actualizar la lista de contratos
        const index = contracts.findIndex((c) => c.id === id)
        if (index !== -1) {
          contracts[index] = updatedContract
        }

        // Cerrar modal y mostrar mensaje
        editContractModal.hide()
        alert("Contrato actualizado correctamente")

        // Renderizar contratos actualizados
        renderContracts(contracts)
      })
      .catch((error) => {
        console.error("Error al actualizar contrato:", error)
        alert("Error al actualizar el contrato. Por favor intente nuevamente.")
      })
      .finally(() => {
        saveEditContractBtn.disabled = false
        saveEditContractBtn.innerHTML = "Guardar Cambios"
      })
  }

  // Función para mostrar modal de eliminación
  function deleteContractModalShow(id) {
    const contract = contracts.find((c) => c.id === id)
    if (!contract) return

    selectedContractId = id
    document.getElementById("delete-contract-name").textContent = contract.nombrePRST
    document.getElementById("delete-password").value = ""
    document.getElementById("delete-error").classList.add("d-none")

    deleteContractModal.show()
  }

  // Función para confirmar eliminación
  function confirmDeleteContract() {
    const deletePassword = document.getElementById("delete-password").value
    const deleteError = document.getElementById("delete-error")

    if (deletePassword !== "EliminarDato") {
      deleteError.textContent = "Contraseña incorrecta. Por favor intente nuevamente."
      deleteError.classList.remove("d-none")
      return
    }

    // Eliminar contrato
    confirmDeleteBtn.disabled = true
    confirmDeleteBtn.innerHTML =
      '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Eliminando...'

    deleteContract(selectedContractId, getUserName())
      .then((success) => {
        if (success) {
          // Actualizar la lista de contratos
          contracts = contracts.filter((c) => c.id !== selectedContractId)

          // Cerrar modal y mostrar mensaje
          deleteContractModal.hide()
          alert("Contrato eliminado correctamente")

          // Renderizar contratos actualizados
          renderContracts(contracts)
        }
      })
      .catch((error) => {
        console.error("Error al eliminar contrato:", error)
        deleteError.textContent = "Error al eliminar el contrato. Por favor intente nuevamente."
        deleteError.classList.remove("d-none")
      })
      .finally(() => {
        confirmDeleteBtn.disabled = false
        confirmDeleteBtn.innerHTML = "Eliminar"
      })
  }

  // Función para mostrar modal de agregar contrato
  function showAddContractModal() {
    // Limpiar formulario
    document.getElementById("add-contract-form").reset()

    // Establecer valores por defecto
    document.getElementById("add-estado").value = "En Gestión"

    addContractModal.show()
  }

  // Función para guardar nuevo contrato
  function saveAddContract() {
    const form = document.getElementById("add-contract-form")
    if (!form.checkValidity()) {
      form.reportValidity()
      return
    }

    // Recopilar datos del formulario
    const newContract = {
      nombrePRST: document.getElementById("add-nombre-prst").value,
      nombreCorto: document.getElementById("add-nombre-corto").value,
      responsable: document.getElementById("add-responsable").value,
      clasificacion: document.getElementById("add-clasificacion").value,
      arreglo: document.getElementById("add-arreglo").value,
      estado: document.getElementById("add-estado").value,

      // Valores por defecto para el resto de campos
      ultimoContrato: false,
      enviadoDigitalmente: false,
      enviadoFisicamente: false,
      fisicamenteEnOficina: false,
      fechaPreLiquidacion: "",
      fechaRadFactura: "N/A",

      // Información contractual
      valorContrato: 0,
      duracionAnios: 1,
      inicioVigencia: new Date().toISOString().split("T")[0],
      finVigencia: "",
      estadoContrato: "Vigente",
      proximoVencer: false,
      garantiasRequeridas: "N/A",

      // Infraestructura
      cable8M: 0,
      cable10M: 0,
      cable12M: 0,
      cable14M: 0,
      cable15M: 0,
      cable16M: 0,
      cable20M: 0,
      cajaEmpalme8M: 0,
      cajaEmpalme10M: 0,
      cajaEmpalme12M: 0,
      cajaEmpalme14M: 0,
      cajaEmpalme15M: 0,
      cajaEmpalme16M: 0,
      cajaEmpalme20M: 0,
      reserva8M: 0,
      reserva10M: 0,
      reserva12M: 0,
      reserva14M: 0,
      reserva15M: 0,
      reserva16M: 0,
      reserva20M: 0,
      nap8M: 0,
      nap10M: 0,
      nap12M: 0,
      nap14M: 0,
      nap15M: 0,
      nap16M: 0,
      nap20M: 0,

      // Pólizas
      vigenciaAmparoCumplimiento: "",
      inicioVigenciaCumplimiento: "",
      finVigenciaCumplimiento: "",
      valorAseguradoCumplimiento: 0,
      valorAseguradoTextoCumplimiento: "",
      numeroPolizaCumplimiento: "",
      inicioAmparoCumplimiento: "",
      finAmparoCumplimiento: "",
      fechaExpedicionPolizaCumplimiento: "",
      tomadorCumplimiento: "",
      aseguradoBeneficiarioCumplimiento: "N/A",
      fechaPolizaConforme: "SIN POLIZA",
      valorAseguradoConforme: "SIN POLIZA",

      vigenciaAmparoRCE: "",
      inicioVigenciaRCE: "",
      finVigenciaRCE: "",
      valorAseguradoRCE: 0,
      valorAseguradoTextoRCE: "",
      numeroPolizaRCE: "",
      inicioAmparoRCE: "",
      finAmparoRCE: "",
      fechaExpedicionPolizaRCE: "",
      tomadorRCE: "",
      aseguradoBeneficiarioRCE: "N/A",
      fechaPolizaConformeRCE: "SIN POLIZA",
      valorAseguradoConformeRCE: "SIN POLIZA",
    }

    // Guardar nuevo contrato
    saveAddContractBtn.disabled = true
    saveAddContractBtn.innerHTML =
      '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Guardando...'

    createContract(newContract, getUserName())
      .then((createdContract) => {
        // Agregar a la lista de contratos
        contracts.push(createdContract)

        // Cerrar modal y mostrar mensaje
        addContractModal.hide()
        alert("Contrato creado correctamente")

        // Renderizar contratos actualizados
        renderContracts(contracts)
      })
      .catch((error) => {
        console.error("Error al crear contrato:", error)
        alert("Error al crear el contrato. Por favor intente nuevamente.")
      })
      .finally(() => {
        saveAddContractBtn.disabled = false
        saveAddContractBtn.innerHTML = "Guardar"
      })
  }

  // Función para obtener la clase de badge según el estado
  function getStatusBadgeClass(status) {
    switch (status) {
      case "Contratado":
        return "badge-contratado"
      case "Finalizado":
        return "badge-finalizado"
      case "En Renovación":
      case "En Renovación - Firma PRST":
      case "En Renovación - Firma AIR-E":
        return "badge-renovacion"
      case "En Gestión":
        return "badge-gestion"
      default:
        return "bg-secondary"
    }
  }

  const bootstrap = window.bootstrap
})

