// Usuarios de ejemplo (en una aplicación real, esto estaría en una base de datos)
const users = [
  { id: 1, username: "admin", password: "admin123", role: "admin" },
  { id: 2, username: "usuario", password: "usuario123", role: "user" },
]

// Función para iniciar sesión
function login(username, password) {
  // Buscar el usuario
  const user = users.find((u) => u.username === username && u.password === password)

  if (user) {
    // Crear sesión
    const session = {
      userId: user.id,
      username: user.username,
      role: user.role,
      expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 horas
    }

    // Guardar en localStorage
    localStorage.setItem("user_session", JSON.stringify(session))
    return true
  }

  return false
}

// Función para cerrar sesión
function logout() {
  localStorage.removeItem("user_session")
  window.location.href = "index.html"
}

// Función para obtener la sesión actual
function getSession() {
  const sessionData = localStorage.getItem("user_session")
  if (sessionData) {
    const session = JSON.parse(sessionData)

    // Verificar si la sesión ha expirado
    if (session.expiresAt > Date.now()) {
      return session
    } else {
      // Limpiar sesión expirada
      logout()
    }
  }
  return null
}

// Función para verificar si el usuario está autenticado
function isAuthenticated() {
  return getSession() !== null
}

// Función para obtener el rol del usuario
function getUserRole() {
  const session = getSession()
  return session ? session.role : null
}

// Función para obtener el nombre de usuario
function getUserName() {
  const session = getSession()
  return session ? session.username : null
}

// Función para verificar acceso a páginas protegidas
function checkAuth() {
  if (!isAuthenticated()) {
    window.location.href = "index.html"
    return false
  }
  return true
}

// Función para verificar acceso de administrador
function checkAdminAuth() {
  if (!isAuthenticated() || getUserRole() !== "admin") {
    window.location.href = "dashboard.html"
    return false
  }
  return true
}

