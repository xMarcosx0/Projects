document.addEventListener("DOMContentLoaded", () => {
  // Declarar variables no declaradas
  const checkAuth = () => true // Reemplazar con la lógica de autenticación real
  const getUserName = () => "Usuario de Prueba" // Reemplazar con la lógica para obtener el nombre del usuario
  const getUserRole = () => "admin" // Reemplazar con la lógica para obtener el rol del usuario
  const logout = () => {
    console.log("Cerrando sesión")
  } // Reemplazar con la lógica de cierre de sesión
  const fetchContracts = () => {
    return Promise.resolve(mockContracts)
  } // Reemplazar con la lógica para obtener los contratos
  const updateContract = (id, updatedContract, userName) => {
    return Promise.resolve(updatedContract)
  } // Reemplazar con la lógica para actualizar el contrato
  const deleteContractApi = (id, userName) => {
    return Promise.resolve(true)
  } // Reemplazar con la lógica para eliminar el contrato
  const createContract = (newContract, userName) => {
    return Promise.resolve({ ...newContract, id: mockContracts.length + 1 })
  } // Reemplazar con la lógica para crear el contrato

  // Datos de prueba (mock)
  const mockContracts = [
    {
      id: 1,
      nombrePRST: "Proveedor A",
      nombreCorto: "PRST A",
      responsable: "Juan Pérez",
      clasificacion: "Clasificación 1",
      estado: "Contratado",
      ultimoContrato: true,
      valorContrato: 100000000,
      duracionAnios: 2,
      inicioVigencia: "2023-01-01",
      finVigencia: "2024-12-31",
      estadoContrato: "Vigente",
      proximoVencer: false,
      cable8M: 10,
      cable10M: 5,
      cable12M: 8,
      cable14M: 2,
      cable15M: 0,
      cable16M: 0,
      cable20M: 0,
      cajaEmpalme8M: 15,
      cajaEmpalme10M: 7,
      cajaEmpalme12M: 10,
      cajaEmpalme14M: 3,
      cajaEmpalme15M: 0,
      cajaEmpalme16M: 0,
      cajaEmpalme20M: 0,
      reserva8M: 20,
      reserva10M: 10,
      reserva12M: 12,
      reserva14M: 4,
      reserva15M: 0,
      reserva16M: 0,
      reserva20M: 0,
      nap8M: 25,
      nap10M: 12,
      nap12M: 15,
      nap14M: 5,
      nap15M: 0,
      nap16M: 0,
      nap20M: 0,
      vigenciaAmparoCumplimiento: "12 meses",
      inicioVigenciaCumplimiento: "2023-01-15",
      finVigenciaCumplimiento: "2024-01-15",
      valorAseguradoCumplimiento: 50000000,
      numeroPolizaCumplimiento: "POL-001",
      fechaExpedicionPolizaCumplimiento: "2023-01-05",
      vigenciaAmparoRCE: "12 meses",
      inicioVigenciaRCE: "2023-01-15",
      finVigenciaRCE: "2024-01-15",
      valorAseguradoRCE: 25000000,
      numeroPolizaRCE: "POL-002",
      fechaExpedicionPolizaRCE: "2023-01-05",
    },
    {
      id: 2,
      nombrePRST: "Proveedor B",
      nombreCorto: "PRST B",
      responsable: "María López",
      clasificacion: "Clasificación 2",
      estado: "En Gestión",
      ultimoContrato: false,
      valorContrato: 75000000,
      duracionAnios: 1,
      inicioVigencia: "2023-06-01",
      finVigencia: "2023-12-31",
      estadoContrato: "Vigente",
      proximoVencer: true,
      cable8M: 5,
      cable10M: 3,
      cable12M: 6,
      cable14M: 1,
      cable15M: 0,
      cable16M: 0,
      cable20M: 0,
      cajaEmpalme8M: 10,
      cajaEmpalme10M: 5,
      cajaEmpalme12M: 8,
      cajaEmpalme14M: 2,
      cajaEmpalme15M: 0,
      cajaEmpalme16M: 0,
      cajaEmpalme20M: 0,
      reserva8M: 15,
      reserva10M: 8,
      reserva12M: 10,
      reserva14M: 3,
      reserva15M: 0,
      reserva16M: 0,
      reserva20M: 0,
      nap8M: 20,
      nap10M: 10,
      nap12M: 12,
      nap14M: 4,
      nap15M: 0,
      nap16M: 0,
      nap20M: 0,
      vigenciaAmparoCumplimiento: "6 meses",
      inicioVigenciaCumplimiento: "2023-06-15",
      finVigenciaCumplimiento: "2023-12-15",
      valorAseguradoCumplimiento: 30000000,
      numeroPolizaCumplimiento: "POL-003",
      fechaExpedicionPolizaCumplimiento: "2023-06-05",
      vigenciaAmparoRCE: "6 meses",
      inicioVigenciaRCE: "2023-06-15",
      finVigenciaRCE: "2023-12-15",
      valorAseguradoRCE: 15000000,
      numeroPolizaRCE: "POL-004",
      fechaExpedicionPolizaRCE: "2023-06-05",
    },
  ]

  const mockAuditLogs = []

  // Verificar autenticación
  if (!checkAuth()) return

  // Referencias a elementos del DOM
  const userNameElement = document.getElementById("user-name")
  const userRoleElement = document.getElementById("user-role")
  const logoutBtn = document.getElementById("logout-btn")
  const searchInput = document.getElementById("search-input")
  const loadingIndicator = document.getElementById("loading-indicator")
  const contractsTableContainer = document.getElementById("contracts-table-container")
  const contractsTableBody = document.getElementById("contracts-table-body")
  const noResultsMessage = document.getElementById("no-results-message")
  const addContractBtn = document.getElementById("add-contract-btn")
  const auditLogsBtn = document.getElementById("audit-logs-btn")

  // Modales
  const viewContractModal = new bootstrap.Modal(document.getElementById("view-contract-modal"))
  const editContractModal = new bootstrap.Modal(document.getElementById("edit-contract-modal"))
  const deleteContractModal = new bootstrap.Modal(document.getElementById("delete-contract-modal"))
  const addContractModal = new bootstrap.Modal(document.getElementById("add-contract-modal"))

  // Botones de acción
  const saveEditContractBtn = document.getElementById("save-edit-contract-btn")
  const confirmDeleteBtn = document.getElementById("confirm-delete-btn")
  const saveAddContractBtn = document.getElementById("save-add-contract-btn")

  // Variables globales
  let contracts = []
  let selectedContractId = null

  // Mostrar información del usuario
  userNameElement.textContent = getUserName()
  userRoleElement.textContent = getUserRole() === "admin" ? "Administrador" : "Usuario"

  // Mostrar/ocultar elementos según el rol
  if (getUserRole() === "admin") {
    document.querySelectorAll(".admin-only").forEach((el) => el.classList.remove("d-none"))
  }

  // Cargar contratos
  loadContracts()

  // Event Listeners
  logoutBtn.addEventListener("click", logout)
  searchInput.addEventListener("input", filterContracts)
  addContractBtn.addEventListener("click", showAddContractModal)
  saveEditContractBtn.addEventListener("click", saveEditContract)
  confirmDeleteBtn.addEventListener("click", confirmDeleteContract)
  saveAddContractBtn.addEventListener("click", saveAddContract)

  // Función para cargar contratos
  function loadContracts() {
    loadingIndicator.classList.remove("d-none")
    contractsTableContainer.classList.add("d-none")
    noResultsMessage.classList.add("d-none")

    fetchContracts()
      .then((data) => {
        contracts = data
        renderContracts(contracts)
        loadingIndicator.classList.add("d-none")

        if (contracts.length > 0) {
          contractsTableContainer.classList.remove("d-none")
        } else {
          noResultsMessage.classList.remove("d-none")
        }
      })
      .catch((error) => {
        console.error("Error al cargar contratos:", error)
        loadingIndicator.classList.add("d-none")
        alert("Error al cargar los contratos. Por favor intente nuevamente.")
      })
  }

  // Función para renderizar contratos en la tabla
  function renderContracts(contractsToRender) {
    contractsTableBody.innerHTML = ""

    if (contractsToRender.length === 0) {
      contractsTableContainer.classList.add("d-none")
      noResultsMessage.classList.remove("d-none")
      return
    }

    contractsTableContainer.classList.remove("d-none")
    noResultsMessage.classList.add("d-none")

    contractsToRender.forEach((contract, index) => {
      const row = document.createElement("tr")

      // Determinar la clase de badge según el estado
      let badgeClass = ""
      switch (contract.estado) {
        case "Contratado":
          badgeClass = "badge-contratado"
          break
        case "Finalizado":
          badgeClass = "badge-finalizado"
          break
        case "En Renovación":
        case "En Renovación - Firma PRST":
        case "En Renovación - Firma AIR-E":
          badgeClass = "badge-renovacion"
          break
        case "En Gestión":
          badgeClass = "badge-gestion"
          break
        default:
          badgeClass = "bg-secondary"
      }

      // Formatear valor del contrato
      const formattedValue = new Intl.NumberFormat("es-CO", {
        style: "currency",
        currency: "COP",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(contract.valorContrato)

      // Formatear fechas
      const inicioVigencia = new Date(contract.inicioVigencia).toLocaleDateString()
      const finVigencia = new Date(contract.finVigencia).toLocaleDateString()

      row.innerHTML = `
                <td>${index + 1}</td>
                <td>${contract.nombrePRST}</td>
                <td>${contract.nombreCorto}</td>
                <td>${contract.responsable}</td>
                <td><span class="badge ${badgeClass}">${contract.estado}</span></td>
                <td>${formattedValue}</td>
                <td>${inicioVigencia} - ${finVigencia}</td>
                <td class="text-end">
                    <div class="dropdown">
                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Acciones
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item view-contract" href="#" data-id="${contract.id}"><i class="bi bi-eye me-2"></i> Ver detalles</a></li>
                            <li><a class="dropdown-item edit-contract" href="#" data-id="${contract.id}"><i class="bi bi-pencil me-2"></i> Editar</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger delete-contract" href="#" data-id="${contract.id}"><i class="bi bi-trash me-2"></i> Eliminar</a></li>
                        </ul>
                    </div>
                </td>
            `

      contractsTableBody.appendChild(row)
    })

    // Agregar event listeners a los botones de acción
    document.querySelectorAll(".view-contract").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.preventDefault()
        const id = Number.parseInt(this.getAttribute("data-id"))
        viewContract(id)
      })
    })

    document.querySelectorAll(".edit-contract").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.preventDefault()
        const id = Number.parseInt(this.getAttribute("data-id"))
        editContract(id)
      })
    })

    document.querySelectorAll(".delete-contract").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.preventDefault()
        const id = Number.parseInt(this.getAttribute("data-id"))
        deleteContractModalShow(id)
      })
    })
  }

  // Función para filtrar contratos
  function filterContracts() {
    const searchTerm = searchInput.value.toLowerCase()

    if (searchTerm === "") {
      renderContracts(contracts)
      return
    }

    const filteredContracts = contracts.filter(
      (contract) =>
        contract.nombrePRST.toLowerCase().includes(searchTerm) ||
        contract.nombreCorto.toLowerCase().includes(searchTerm) ||
        contract.responsable.toLowerCase().includes(searchTerm),
    )

    renderContracts(filteredContracts)
  }

  // Función para ver detalles de un contrato
  function viewContract(id) {
    const contract = contracts.find((c) => c.id === id)
    if (!contract) return

    const viewContractContent = document.getElementById("view-contract-content")

    // Formatear valor del contrato
    const formattedValue = new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(contract.valorContrato)

    // Formatear fechas
    const inicioVigencia = new Date(contract.inicioVigencia).toLocaleDateString()
    const finVigencia = new Date(contract.finVigencia).toLocaleDateString()

    // Construir HTML para los detalles del contrato
    const html = `
            <div class="row mb-4">
                <div class="col-md-6 mb-3">
                    <div class="contract-detail-label">Nombre del PRST</div>
                    <div class="contract-detail-value">${contract.nombrePRST}</div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="contract-detail-label">Nombre Corto</div>
                    <div class="contract-detail-value">${contract.nombreCorto}</div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="contract-detail-label">Responsable</div>
                    <div class="contract-detail-value">${contract.responsable}</div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="contract-detail-label">Clasificación</div>
                    <div class="contract-detail-value">${contract.clasificacion}</div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="contract-detail-label">Estado</div>
                    <div class="contract-detail-value">
                        <span class="badge ${getStatusBadgeClass(contract.estado)}">${contract.estado}</span>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="contract-detail-label">¿Último Contrato?</div>
                    <div class="contract-detail-value">${contract.ultimoContrato ? "Sí" : "No"}</div>
                </div>
            </div>
            
            <div class="accordion" id="contractDetailsAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#contractInfoCollapse" aria-expanded="true" aria-controls="contractInfoCollapse">
                            Información Contractual
                        </button>
                    </h2>
                    <div id="contractInfoCollapse" class="accordion-collapse collapse show" data-bs-parent="#contractDetailsAccordion">
                        <div class="accordion-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <div class="contract-detail-label">Valor del Contrato</div>
                                    <div class="contract-detail-value">${formattedValue}</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="contract-detail-label">Duración (Años)</div>
                                    <div class="contract-detail-value">${contract.duracionAnios}</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="contract-detail-label">Inicio de Vigencia</div>
                                    <div class="contract-detail-value">${inicioVigencia}</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="contract-detail-label">Fin de Vigencia</div>
                                    <div class="contract-detail-value">${finVigencia}</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="contract-detail-label">Estado de Contrato</div>
                                    <div class="contract-detail-value">${contract.estadoContrato}</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="contract-detail-label">¿Próximo a Vencer?</div>
                                    <div class="contract-detail-value">${contract.proximoVencer ? "Sí" : "No"}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#infrastructureCollapse" aria-expanded="false" aria-controls="infrastructureCollapse">
                            Información de Infraestructura
                        </button>
                    </h2>
                    <div id="infrastructureCollapse" class="accordion-collapse collapse" data-bs-parent="#contractDetailsAccordion">
                        <div class="accordion-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Tipo</th>
                                            <th>8 M</th>
                                            <th>10 M</th>
                                            <th>12 M</th>
                                            <th>14 M</th>
                                            <th>15 M</th>
                                            <th>16 M</th>
                                            <th>20 M</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="fw-medium">Cable</td>
                                            <td>${contract.cable8M}</td>
                                            <td>${contract.cable10M}</td>
                                            <td>${contract.cable12M}</td>
                                            <td>${contract.cable14M}</td>
                                            <td>${contract.cable15M}</td>
                                            <td>${contract.cable16M}</td>
                                            <td>${contract.cable20M}</td>
                                        </tr>
                                        <tr>
                                            <td class="fw-medium">Caja de Empalme</td>
                                            <td>${contract.cajaEmpalme8M}</td>
                                            <td>${contract.cajaEmpalme10M}</td>
                                            <td>${contract.cajaEmpalme12M}</td>
                                            <td>${contract.cajaEmpalme14M}</td>
                                            <td>${contract.cajaEmpalme15M}</td>
                                            <td>${contract.cajaEmpalme16M}</td>
                                            <td>${contract.cajaEmpalme20M}</td>
                                        </tr>
                                        <tr>
                                            <td class="fw-medium">Reserva</td>
                                            <td>${contract.reserva8M}</td>
                                            <td>${contract.reserva10M}</td>
                                            <td>${contract.reserva12M}</td>
                                            <td>${contract.reserva14M}</td>
                                            <td>${contract.reserva15M}</td>
                                            <td>${contract.reserva16M}</td>
                                            <td>${contract.reserva20M}</td>
                                        </tr>
                                        <tr>
                                            <td class="fw-medium">NAP</td>
                                            <td>${contract.nap8M}</td>
                                            <td>${contract.nap10M}</td>
                                            <td>${contract.nap12M}</td>
                                            <td>${contract.nap14M}</td>
                                            <td>${contract.nap15M}</td>
                                            <td>${contract.nap16M}</td>
                                            <td>${contract.nap20M}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#policiesCollapse" aria-expanded="false" aria-controls="policiesCollapse">
                            Información de Pólizas
                        </button>
                    </h2>
                    <div id="policiesCollapse" class="accordion-collapse collapse" data-bs-parent="#contractDetailsAccordion">
                        <div class="accordion-body">
                            <h5 class="mb-3">Póliza de Cumplimiento</h5>
                            <div class="row mb-4">
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Vigencia de amparo</div>
                                    <div class="contract-detail-value">${contract.vigenciaAmparoCumplimiento || "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Inicio de Vigencia</div>
                                    <div class="contract-detail-value">${contract.inicioVigenciaCumplimiento ? new Date(contract.inicioVigenciaCumplimiento).toLocaleDateString() : "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Fin de Vigencia</div>
                                    <div class="contract-detail-value">${contract.finVigenciaCumplimiento ? new Date(contract.finVigenciaCumplimiento).toLocaleDateString() : "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Valor Asegurado</div>
                                    <div class="contract-detail-value">${contract.valorAseguradoCumplimiento ? new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(contract.valorAseguradoCumplimiento) : "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Número de Póliza</div>
                                    <div class="contract-detail-value">${contract.numeroPolizaCumplimiento || "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Fecha de expedición</div>
                                    <div class="contract-detail-value">${contract.fechaExpedicionPolizaCumplimiento ? new Date(contract.fechaExpedicionPolizaCumplimiento).toLocaleDateString() : "N/A"}</div>
                                </div>
                            </div>
                            
                            <h5 class="mb-3">Póliza de RCE</h5>
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Vigencia de amparo</div>
                                    <div class="contract-detail-value">${contract.vigenciaAmparoRCE || "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Inicio de Vigencia</div>
                                    <div class="contract-detail-value">${contract.inicioVigenciaRCE ? new Date(contract.inicioVigenciaRCE).toLocaleDateString() : "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Fin de Vigencia</div>
                                    <div class="contract-detail-value">${contract.finVigenciaRCE ? new Date(contract.finVigenciaRCE).toLocaleDateString() : "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Valor Asegurado</div>
                                    <div class="contract-detail-value">${contract.valorAseguradoRCE ? new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(contract.valorAseguradoRCE) : "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Número de Póliza</div>
                                    <div class="contract-detail-value">${contract.numeroPolizaRCE || "N/A"}</div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="contract-detail-label">Fecha de expedición</div>
                                    <div class="contract-detail-value">${contract.fechaExpedicionPolizaRCE ? new Date(contract.fechaExpedicionPolizaRCE).toLocaleDateString() : "N/A"}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `

    viewContractContent.innerHTML = html
    viewContractModal.show()

    // Registrar en el log de auditoría
    const auditLog = {
      id: mockAuditLogs.length + 1,
      userId: getUserName() === "admin" ? 1 : 2,
      username: getUserName(),
      action: "VIEW",
      entityType: "Contract",
      entityId: id,
      details: "Visualización de detalles de contrato",
      timestamp: new Date().toISOString(),
    }
    mockAuditLogs.push(auditLog)
  }

  // Función para editar un contrato
  function editContract(id) {
    const contract = contracts.find((c) => c.id === id)
    if (!contract) return

    selectedContractId = id

    // Llenar el formulario con los datos del contrato
    document.getElementById("edit-contract-id").value = contract.id
    document.getElementById("edit-nombre-prst").value = contract.nombrePRST
    document.getElementById("edit-nombre-corto").value = contract.nombreCorto
    document.getElementById("edit-responsable").value = contract.responsable
    document.getElementById("edit-clasificacion").value = contract.clasificacion
    document.getElementById("edit-estado").value = contract.estado
    document.getElementById("edit-ultimo-contrato").value = contract.ultimoContrato.toString()
    document.getElementById("edit-valor-contrato").value = contract.valorContrato
    document.getElementById("edit-duracion-anios").value = contract.duracionAnios
    document.getElementById("edit-inicio-vigencia").value = contract.inicioVigencia
      ? new Date(contract.inicioVigencia).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-vigencia").value = contract.finVigencia
      ? new Date(contract.finVigencia).toISOString().split("T")[0]
      : ""

    // Infraestructura - Cable
    document.getElementById("edit-cable-8m").value = contract.cable8M
    document.getElementById("edit-cable-10m").value = contract.cable10M
    document.getElementById("edit-cable-12m").value = contract.cable12M
    document.getElementById("edit-cable-14m").value = contract.cable14M

    // Infraestructura - Caja de Empalme
    document.getElementById("edit-caja-empalme-8m").value = contract.cajaEmpalme8M
    document.getElementById("edit-caja-empalme-10m").value = contract.cajaEmpalme10M
    document.getElementById("edit-caja-empalme-12m").value = contract.cajaEmpalme12M
    document.getElementById("edit-caja-empalme-14m").value = contract.cajaEmpalme14M

    // Infraestructura - Reserva
    document.getElementById("edit-reserva-8m").value = contract.reserva8M
    document.getElementById("edit-reserva-10m").value = contract.reserva10M
    document.getElementById("edit-reserva-12m").value = contract.reserva12M
    document.getElementById("edit-reserva-14m").value = contract.reserva14M

    // Infraestructura - NAP
    document.getElementById("edit-nap-8m").value = contract.nap8M
    document.getElementById("edit-nap-10m").value = contract.nap10M
    document.getElementById("edit-nap-12m").value = contract.nap12M
    document.getElementById("edit-nap-14m").value = contract.nap14M

    // Póliza de Cumplimiento
    document.getElementById("edit-vigencia-amparo-cumplimiento").value = contract.vigenciaAmparoCumplimiento || ""
    document.getElementById("edit-inicio-vigencia-cumplimiento").value = contract.inicioVigenciaCumplimiento
      ? new Date(contract.inicioVigenciaCumplimiento).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-vigencia-cumplimiento").value = contract.finVigenciaCumplimiento
      ? new Date(contract.finVigenciaCumplimiento).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-valor-asegurado-cumplimiento").value = contract.valorAseguradoCumplimiento || ""
    document.getElementById("edit-numero-poliza-cumplimiento").value = contract.numeroPolizaCumplimiento || ""
    document.getElementById("edit-fecha-expedicion-poliza-cumplimiento").value =
      contract.fechaExpedicionPolizaCumplimiento
        ? new Date(contract.fechaExpedicionPolizaCumplimiento).toISOString().split("T")[0]
        : ""

    // Póliza de RCE
    document.getElementById("edit-vigencia-amparo-rce").value = contract.vigenciaAmparoRCE || ""
    document.getElementById("edit-inicio-vigencia-rce").value = contract.inicioVigenciaRCE
      ? new Date(contract.inicioVigenciaRCE).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-fin-vigencia-rce").value = contract.finVigenciaRCE
      ? new Date(contract.finVigenciaRCE).toISOString().split("T")[0]
      : ""
    document.getElementById("edit-valor-asegurado-rce").value = contract.valorAseguradoRCE || ""
    document.getElementById("edit-numero-poliza-rce").value = contract.numeroPolizaRCE || ""
    document.getElementById("edit-fecha-expedicion-poliza-rce").value = contract.fechaExpedicionPolizaRCE
      ? new Date(contract.fechaExpedicionPolizaRCE).toISOString().split("T")[0]
      : ""

    editContractModal.show()
  }

  // Función para guardar cambios en un contrato
  function saveEditContract() {
    const form = document.getElementById("edit-contract-form")
    if (!form.checkValidity()) {
      form.reportValidity()
      return
    }

    const id = Number.parseInt(document.getElementById("edit-contract-id").value)

    // Recopilar datos del formulario
    const updatedContract = {
      id: id,
      nombrePRST: document.getElementById("edit-nombre-prst").value,
      nombreCorto: document.getElementById("edit-nombre-corto").value,
      responsable: document.getElementById("edit-responsable").value,
      clasificacion: document.getElementById("edit-clasificacion").value,
      estado: document.getElementById("edit-estado").value,
      ultimoContrato: document.getElementById("edit-ultimo-contrato").value === "true",

      // Información contractual
      valorContrato: Number.parseFloat(document.getElementById("edit-valor-contrato").value),
      duracionAnios: Number.parseInt(document.getElementById("edit-duracion-anios").value),
      inicioVigencia: document.getElementById("edit-inicio-vigencia").value,
      finVigencia: document.getElementById("edit-fin-vigencia").value,
      estadoContrato: "Vigente", // Valor por defecto
      proximoVencer: false, // Valor por defecto

      // Infraestructura - Cable
      cable8M: Number.parseInt(document.getElementById("edit-cable-8m").value) || 0,
      cable10M: Number.parseInt(document.getElementById("edit-cable-10m").value) || 0,
      cable12M: Number.parseInt(document.getElementById("edit-cable-12m").value) || 0,
      cable14M: Number.parseInt(document.getElementById("edit-cable-14m").value) || 0,
      cable15M: 0, // Valor por defecto
      cable16M: 0, // Valor por defecto
      cable20M: 0, // Valor por defecto

      // Infraestructura - Caja de Empalme
      cajaEmpalme8M: Number.parseInt(document.getElementById("edit-caja-empalme-8m").value) || 0,
      cajaEmpalme10M: Number.parseInt(document.getElementById("edit-caja-empalme-10m").value) || 0,
      cajaEmpalme12M: Number.parseInt(document.getElementById("edit-caja-empalme-12m").value) || 0,
      cajaEmpalme14M: Number.parseInt(document.getElementById("edit-caja-empalme-14m").value) || 0,
      cajaEmpalme15M: 0, // Valor por defecto
      cajaEmpalme16M: 0, // Valor por defecto
      cajaEmpalme20M: 0, // Valor por defecto

      // Infraestructura - Reserva
      reserva8M: Number.parseInt(document.getElementById("edit-reserva-8m").value) || 0,
      reserva10M: Number.parseInt(document.getElementById("edit-reserva-10m").value) || 0,
      reserva12M: Number.parseInt(document.getElementById("edit-reserva-12m").value) || 0,
      reserva14M: Number.parseInt(document.getElementById("edit-reserva-14m").value) || 0,
      reserva15M: 0, // Valor por defecto
      reserva16M: 0, // Valor por defecto
      reserva20M: 0, // Valor por defecto

      // Infraestructura - NAP
      nap8M: Number.parseInt(document.getElementById("edit-nap-8m").value) || 0,
      nap10M: Number.parseInt(document.getElementById("edit-nap-10m").value) || 0,
      nap12M: Number.parseInt(document.getElementById("edit-nap-12m").value) || 0,
      nap14M: Number.parseInt(document.getElementById("edit-nap-14m").value) || 0,
      nap15M: 0, // Valor por defecto
      nap16M: 0, // Valor por defecto
      nap20M: 0, // Valor por defecto

      // Póliza de Cumplimiento
      vigenciaAmparoCumplimiento: document.getElementById("edit-vigencia-amparo-cumplimiento").value,
      inicioVigenciaCumplimiento: document.getElementById("edit-inicio-vigencia-cumplimiento").value,
      finVigenciaCumplimiento: document.getElementById("edit-fin-vigencia-cumplimiento").value,
      valorAseguradoCumplimiento:
        Number.parseFloat(document.getElementById("edit-valor-asegurado-cumplimiento").value) || 0,
      numeroPolizaCumplimiento: document.getElementById("edit-numero-poliza-cumplimiento").value,
      fechaExpedicionPolizaCumplimiento: document.getElementById("edit-fecha-expedicion-poliza-cumplimiento").value,

      // Póliza de RCE
      vigenciaAmparoRCE: document.getElementById("edit-vigencia-amparo-rce").value,
      inicioVigenciaRCE: document.getElementById("edit-inicio-vigencia-rce").value,
      finVigenciaRCE: document.getElementById("edit-fin-vigencia-rce").value,
      valorAseguradoRCE: Number.parseFloat(document.getElementById("edit-valor-asegurado-rce").value) || 0,
      numeroPolizaRCE: document.getElementById("edit-numero-poliza-rce").value,
      fechaExpedicionPolizaRCE: document.getElementById("edit-fecha-expedicion-poliza-rce").value,
    }

    // Guardar cambios
    saveEditContractBtn.disabled = true
    saveEditContractBtn.innerHTML =
      '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Guardando...'

    updateContract(id, updatedContract, getUserName())
      .then((updatedContract) => {
        // Actualizar la lista de contratos
        const index = contracts.findIndex((c) => c.id === id)
        if (index !== -1) {
          contracts[index] = updatedContract
        }

        // Cerrar modal y mostrar mensaje
        editContractModal.hide()
        alert("Contrato actualizado correctamente")

        // Renderizar contratos actualizados
        renderContracts(contracts)
      })
      .catch((error) => {
        console.error("Error al actualizar contrato:", error)
        alert("Error al actualizar el contrato. Por favor intente nuevamente.")
      })
      .finally(() => {
        saveEditContractBtn.disabled = false
        saveEditContractBtn.innerHTML = "Guardar Cambios"
      })
  }

  // Función para mostrar modal de eliminación
  function deleteContractModalShow(id) {
    const contract = contracts.find((c) => c.id === id)
    if (!contract) return

    selectedContractId = id
    document.getElementById("delete-contract-name").textContent = contract.nombrePRST
    document.getElementById("delete-password").value = ""
    document.getElementById("delete-error").classList.add("d-none")

    deleteContractModal.show()
  }

  // Función para confirmar eliminación
  function confirmDeleteContract() {
    const deletePassword = document.getElementById("delete-password").value
    const deleteError = document.getElementById("delete-error")

    if (deletePassword !== "EliminarDato") {
      deleteError.textContent = "Contraseña incorrecta. Por favor intente nuevamente."
      deleteError.classList.remove("d-none")
      return
    }

    // Eliminar contrato
    confirmDeleteBtn.disabled = true
    confirmDeleteBtn.innerHTML =
      '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Eliminando...'

    deleteContractApi(selectedContractId, getUserName())
      .then((success) => {
        if (success) {
          // Actualizar la lista de contratos
          contracts = contracts.filter((c) => c.id !== selectedContractId)

          // Cerrar modal y mostrar mensaje
          deleteContractModal.hide()
          alert("Contrato eliminado correctamente")

          // Renderizar contratos actualizados
          renderContracts(contracts)
        }
      })
      .catch((error) => {
        console.error("Error al eliminar contrato:", error)
        deleteError.textContent = "Error al eliminar el contrato. Por favor intente nuevamente."
        deleteError.classList.remove("d-none")
      })
      .finally(() => {
        confirmDeleteBtn.disabled = false
        confirmDeleteBtn.innerHTML = "Eliminar"
      })
  }

  // Función para mostrar modal de agregar contrato
  function showAddContractModal() {
    // Limpiar formulario
    document.getElementById("add-contract-form").reset()

    // Establecer valores por defecto
    document.getElementById("add-ultimo-contrato").value = "true"
    document.getElementById("add-cable-8m").value = "0"
    document.getElementById("add-cable-10m").value = "0"
    document.getElementById("add-cable-12m").value = "0"
    document.getElementById("add-cable-14m").value = "0"

    addContractModal.show()
  }

  // Función para guardar nuevo contrato
  function saveAddContract() {
    const form = document.getElementById("add-contract-form")
    if (!form.checkValidity()) {
      form.reportValidity()
      return
    }

    // Recopilar datos del formulario
    const newContract = {
      nombrePRST: document.getElementById("add-nombre-prst").value,
      nombreCorto: document.getElementById("add-nombre-corto").value,
      responsable: document.getElementById("add-responsable").value,
      clasificacion: document.getElementById("add-clasificacion").value,
      estado: document.getElementById("add-estado").value,
      ultimoContrato: document.getElementById("add-ultimo-contrato").value === "true",

      // Información contractual
      valorContrato: Number.parseFloat(document.getElementById("add-valor-contrato").value),
      duracionAnios: Number.parseInt(document.getElementById("add-duracion-anios").value),
      inicioVigencia: document.getElementById("add-inicio-vigencia").value,
      finVigencia: document.getElementById("add-fin-vigencia").value,
      estadoContrato: "Vigente", // Valor por defecto
      proximoVencer: false, // Valor por defecto

      // Infraestructura - Cable
      cable8M: Number.parseInt(document.getElementById("add-cable-8m").value) || 0,
      cable10M: Number.parseInt(document.getElementById("add-cable-10m").value) || 0,
      cable12M: Number.parseInt(document.getElementById("add-cable-12m").value) || 0,
      cable14M: Number.parseInt(document.getElementById("add-cable-14m").value) || 0,
      cable15M: 0, // Valor por defecto
      cable16M: 0, // Valor por defecto
      cable20M: 0, // Valor por defecto

      // Infraestructura - Caja de Empalme
      cajaEmpalme8M: Number.parseInt(document.getElementById("add-caja-empalme-8m").value) || 0,
      cajaEmpalme10M: Number.parseInt(document.getElementById("add-caja-empalme-10m").value) || 0,
      cajaEmpalme12M: Number.parseInt(document.getElementById("add-caja-empalme-12m").value) || 0,
      cajaEmpalme14M: Number.parseInt(document.getElementById("add-caja-empalme-14m").value) || 0,
      cajaEmpalme15M: 0, // Valor por defecto
      cajaEmpalme16M: 0, // Valor por defecto
      cajaEmpalme20M: 0, // Valor por defecto

      // Infraestructura - Reserva
      reserva8M: Number.parseInt(document.getElementById("add-reserva-8m").value) || 0,
      reserva10M: Number.parseInt(document.getElementById("add-reserva-10m").value) || 0,
      reserva12M: Number.parseInt(document.getElementById("add-reserva-12m").value) || 0,
      reserva14M: Number.parseInt(document.getElementById("add-reserva-14m").value) || 0,
      reserva15M: 0, // Valor por defecto
      reserva16M: 0, // Valor por defecto
      reserva20M: 0, // Valor por defecto

      // Infraestructura - NAP
      nap8M: Number.parseInt(document.getElementById("add-nap-8m").value) || 0,
      nap10M: Number.parseInt(document.getElementById("add-nap-10m").value) || 0,
      nap12M: Number.parseInt(document.getElementById("add-nap-12m").value) || 0,
      nap14M: Number.parseInt(document.getElementById("add-nap-14m").value) || 0,
      nap15M: 0, // Valor por defecto
      nap16M: 0, // Valor por defecto
      nap20M: 0, // Valor por defecto

      // Póliza de Cumplimiento
      vigenciaAmparoCumplimiento: document.getElementById("add-vigencia-amparo-cumplimiento").value,
      inicioVigenciaCumplimiento: document.getElementById("add-inicio-vigencia-cumplimiento").value,
      finVigenciaCumplimiento: document.getElementById("add-fin-vigencia-cumplimiento").value,
      valorAseguradoCumplimiento:
        Number.parseFloat(document.getElementById("add-valor-asegurado-cumplimiento").value) || 0,
      numeroPolizaCumplimiento: document.getElementById("add-numero-poliza-cumplimiento").value,
      fechaExpedicionPolizaCumplimiento: document.getElementById("add-fecha-expedicion-poliza-cumplimiento").value,

      // Póliza de RCE
      vigenciaAmparoRCE: document.getElementById("add-vigencia-amparo-rce").value,
      inicioVigenciaRCE: document.getElementById("add-inicio-vigencia-rce").value,
      finVigenciaRCE: document.getElementById("add-fin-vigencia-rce").value,
      valorAseguradoRCE: Number.parseFloat(document.getElementById("add-valor-asegurado-rce").value) || 0,
      numeroPolizaRCE: document.getElementById("add-numero-poliza-rce").value,
      fechaExpedicionPolizaRCE: document.getElementById("add-fecha-expedicion-poliza-rce").value,
    }

    // Guardar nuevo contrato
    saveAddContractBtn.disabled = true
    saveAddContractBtn.innerHTML =
      '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Guardando...'

    createContract(newContract, getUserName())
      .then((createdContract) => {
        // Agregar a la lista de contratos
        contracts.push(createdContract)

        // Cerrar modal y mostrar mensaje
        addContractModal.hide()
        alert("Contrato creado correctamente")

        // Renderizar contratos actualizados
        renderContracts(contracts)
      })
      .catch((error) => {
        console.error("Error al crear contrato:", error)
        alert("Error al crear el contrato. Por favor intente nuevamente.")
      })
      .finally(() => {
        saveAddContractBtn.disabled = false
        saveAddContractBtn.innerHTML = "Guardar"
      })
  }

  // Función para obtener la clase de badge según el estado
  function getStatusBadgeClass(status) {
    switch (status) {
      case "Contratado":
        return "badge-contratado"
      case "Finalizado":
        return "badge-finalizado"
      case "En Renovación":
      case "En Renovación - Firma PRST":
      case "En Renovación - Firma AIR-E":
        return "badge-renovacion"
      case "En Gestión":
        return "badge-gestion"
      default:
        return "bg-secondary"
    }
  }
})

