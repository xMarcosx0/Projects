document.addEventListener("DOMContentLoaded", () => {
  // Declarar las funciones isAuthenticated y login (simuladas para este ejemplo)
  function isAuthenticated() {
    // Aquí iría la lógica real para verificar si el usuario está autenticado
    // Por ahora, siempre devuelve falso para que se muestre el formulario de inicio de sesión
    return false
  }

  function login(username, password) {
    // Aquí iría la lógica real para autenticar al usuario
    // Por ahora, simula el inicio de sesión exitoso si el usuario y la contraseña no están vacíos
    return username !== "" && password !== ""
  }

  // Redirigir si ya está autenticado
  if (isAuthenticated()) {
    window.location.href = "dashboard.html"
    return
  }

  // Manejar el envío del formulario de inicio de sesión
  const loginForm = document.getElementById("login-form")
  const loginError = document.getElementById("login-error")

  loginForm.addEventListener("submit", (event) => {
    event.preventDefault()

    const username = document.getElementById("username").value
    const password = document.getElementById("password").value

    // Intentar iniciar sesión
    const success = login(username, password)

    if (success) {
      window.location.href = "dashboard.html"
    } else {
      loginError.classList.remove("d-none")
      // Ocultar el mensaje de error después de 3 segundos
      setTimeout(() => {
        loginError.classList.add("d-none")
      }, 3000)
    }
  })
})

