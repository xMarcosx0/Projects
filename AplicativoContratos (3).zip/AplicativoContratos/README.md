# Sistema de Gestión de Contratos

Este proyecto es un sistema de gestión de contratos desarrollado con HTML, CSS y JavaScript para el frontend, y Python con Flask para el backend.

## Estructura del Proyecto

